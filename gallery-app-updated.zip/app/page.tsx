import { prisma } from '@/lib/db';
import Link from 'next/link';
import type { Metadata } from 'next';
import Pagination from './components/Pagination';
import AlbumCard from './components/AlbumCard';
import { getPageParams, getTotalPages } from '@/lib/pagination';
import { getCategoryTree, findCategoryContext, categoryIdsForFilter } from '@/lib/categories';
import { getTagCounts } from '@/lib/tags';
import { tagBadgeStyle } from '@/lib/tag-color';

// 首页标签云只挑热度最高的一批，全部标签太多会把页头下面这块区域撑得很长，
// 想看完整列表引导去 /tags（那边是按热度做字号的完整标签云）
const HOME_TAG_LIMIT = 24;

export const revalidate = 3600; // 每小时重新生成一次

type SearchParams = Promise<{ [key: string]: string | string[] | undefined }>;

export async function generateMetadata({ searchParams }: { searchParams: SearchParams }): Promise<Metadata> {
  const params = await searchParams;
  const { page } = getPageParams(params);

  // 第 2 页及以后内容跟第 1 页高度重复（只是翻页），搜索引擎索引这些页面价值很低，
  // 加 noindex 避免"薄内容"拖累整站质量分；follow 保留，链接权重照样往后传递
  if (page > 1) {
    return { robots: { index: false, follow: true } };
  }
  return {};
}

export default async function HomePage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const params = await searchParams;
  const categorySlug = typeof params.category === 'string' ? params.category : undefined;
  const { page, skip, take } = getPageParams(params);

  const tree = await getCategoryTree();
  const context = categorySlug ? findCategoryContext(tree, categorySlug) : null;

  const where = {
    status: 'PUBLISHED' as const,
    ...(context ? { categoryId: { in: categoryIdsForFilter(context.current) } } : {}),
  };

  const [albums, totalCount, tagCounts] = await Promise.all([
    prisma.album.findMany({
      where,
      orderBy: { publishedAt: 'desc' },
      skip,
      take,
      select: {
        title: true,
        slug: true,
        coverKey: true,
        coverBlurDataURL: true,
        visibility: true,
        tags: { select: { name: true } },
      },
    }),
    prisma.album.count({ where }),
    getTagCounts(true),
  ]);

  const albumCards = albums.map((a) => ({ ...a, tags: a.tags.map((t) => t.name) }));
  const totalPages = getTotalPages(totalCount);
  const topTags = tagCounts.slice(0, HOME_TAG_LIMIT);

  return (
    <div>
      {(context || topTags.length > 0) && (
        <div className="space-y-2 px-4 py-4">
          {/* 分类筛选已经挪到页头导航菜单里去了（导航项可以直接关联分类，见后台"导航菜单"管理）。
              这里不再重复渲染一遍分类列表，只在真的通过分类链接进来时提示一下当前筛选状态，
              把这块地方让给标签——比分类列表更适合放在首页，点了就能直接跳转看图。 */}
          {context && (
            <div className="flex flex-wrap items-center gap-2 text-sm text-[var(--fg-60)]">
              <span>
                当前分类：
                <span className="text-[var(--text-color)]">
                  {context.top.name}
                  {context.current.id !== context.top.id ? ` / ${context.current.name}` : ''}
                </span>
              </span>
              <Link href="/" className="text-xs underline hover:text-[var(--text-color)]">
                清除筛选
              </Link>
            </div>
          )}

          {topTags.length > 0 && (
            <div className="flex flex-wrap gap-2 text-xs">
              {topTags.map(({ tag }) => (
                <Link
                  key={tag}
                  href={`/${encodeURIComponent(tag)}`}
                  style={tagBadgeStyle(tag)}
                  className="rounded-full px-3 py-1.5 transition hover:opacity-80"
                >
                  {tag}
                </Link>
              ))}
              <Link
                href="/tags"
                className="flex items-center rounded-full px-3 py-1.5 text-[var(--fg-50)] hover:text-[var(--text-color)]"
              >
                全部标签 →
              </Link>
            </div>
          )}
        </div>
      )}

      <div className="grid grid-cols-2 gap-x-1 gap-y-3 p-1 sm:grid-cols-3 md:grid-cols-4">
        {albumCards.map((album, index) => (
          <AlbumCard key={album.slug} album={album} priority={index === 0} />
        ))}
        {albumCards.length === 0 && (
          <p className="col-span-full p-8 text-center text-[var(--fg-50)]">
            {categorySlug ? '这个分类下暂无图集' : '还没有发布任何图集'}
          </p>
        )}
      </div>

      <Pagination currentPage={page} totalPages={totalPages} basePath="/" extraParams={{ category: categorySlug }} />
    </div>
  );
}
