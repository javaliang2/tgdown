import { prisma } from '@/lib/db';
import ViewTrendChart from './ViewTrendChart';

export const dynamic = 'force-dynamic'; // 后台不缓存，实时看最新数据

const TREND_DAYS = 30;
const TOP_ALBUMS_LIMIT = 10;

function formatDateKey(d: Date): string {
  return d.toISOString().slice(0, 10);
}

export default async function StatsPage() {
  const rangeStart = new Date();
  rangeStart.setUTCDate(rangeStart.getUTCDate() - (TREND_DAYS - 1));
  const rangeStartKey = formatDateKey(rangeStart);

  const [albumGroups, photoCount, viewAgg, topAlbums, dailyStats] = await Promise.all([
    prisma.album.groupBy({ by: ['status', 'visibility'], _count: { _all: true } }),
    prisma.photo.count(),
    prisma.album.aggregate({ _sum: { viewCount: true } }),
    prisma.album.findMany({
      orderBy: { viewCount: 'desc' },
      take: TOP_ALBUMS_LIMIT,
      select: { id: true, title: true, slug: true, viewCount: true, status: true },
    }),
    prisma.dailyViewStat.findMany({
      where: { date: { gte: new Date(rangeStartKey) } },
      orderBy: { date: 'asc' },
    }),
  ]);

  const totalAlbums = albumGroups.reduce((sum, g) => sum + g._count._all, 0);
  const publishedCount = albumGroups
    .filter((g) => g.status === 'PUBLISHED')
    .reduce((sum, g) => sum + g._count._all, 0);
  const draftCount = totalAlbums - publishedCount;
  const privateCount = albumGroups
    .filter((g) => g.visibility === 'PRIVATE')
    .reduce((sum, g) => sum + g._count._all, 0);
  const totalViews = viewAgg._sum.viewCount ?? 0;

  // 把没有数据的日期补成 0，图表横轴才是连续的 30 天，而不是"只有被访问过的那几天"
  const statsByDate = new Map(dailyStats.map((s) => [formatDateKey(s.date), s.count]));
  const trend: { date: string; count: number }[] = [];
  for (let i = 0; i < TREND_DAYS; i++) {
    const d = new Date(rangeStart);
    d.setUTCDate(d.getUTCDate() + i);
    const key = formatDateKey(d);
    trend.push({ date: key, count: statsByDate.get(key) ?? 0 });
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <h1 className="mb-6 text-xl">统计</h1>

      <div className="mb-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard label="图集总数" value={totalAlbums} sub={`${publishedCount} 已发布 · ${draftCount} 草稿`} />
        <StatCard label="图片总数" value={photoCount} />
        <StatCard label="累计浏览量" value={totalViews} />
        <StatCard label="私密相册" value={privateCount} />
      </div>

      <section className="mb-8">
        <h2 className="mb-3 text-sm text-[var(--fg-60)]">近 {TREND_DAYS} 天浏览量趋势</h2>
        <ViewTrendChart data={trend} />
        {dailyStats.length === 0 && (
          <p className="mt-2 text-xs text-[var(--fg-40)]">
            这张图从今天开始积累数据，之前的浏览记录只体现在下面的累计浏览量里
          </p>
        )}
      </section>

      <section>
        <h2 className="mb-3 text-sm text-[var(--fg-60)]">热门图集 Top {TOP_ALBUMS_LIMIT}</h2>
        <ol className="space-y-2">
          {topAlbums.map((album, i) => (
            <li
              key={album.id}
              className="flex items-center justify-between gap-3 rounded border border-[var(--fg-10)] px-4 py-2.5 text-sm"
            >
              <div className="flex min-w-0 items-center gap-3">
                <span className="w-5 shrink-0 text-[var(--fg-40)]">{i + 1}</span>
                {album.status === 'PUBLISHED' ? (
                  <a
                    href={`/${album.slug}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="truncate hover:underline"
                  >
                    {album.title}
                  </a>
                ) : (
                  <span className="truncate text-[var(--fg-60)]">{album.title}（草稿）</span>
                )}
              </div>
              <span className="shrink-0 text-[var(--fg-50)]">{album.viewCount} 次浏览</span>
            </li>
          ))}
          {topAlbums.length === 0 && <p className="text-sm text-[var(--fg-50)]">还没有浏览数据</p>}
        </ol>
      </section>
    </div>
  );
}

function StatCard({ label, value, sub }: { label: string; value: number; sub?: string }) {
  return (
    <div className="rounded border border-[var(--fg-10)] p-4">
      <p className="text-xs text-[var(--fg-50)]">{label}</p>
      <p className="mt-1 text-2xl">{value.toLocaleString('zh-CN')}</p>
      {sub && <p className="mt-1 text-xs text-[var(--fg-40)]">{sub}</p>}
    </div>
  );
}
