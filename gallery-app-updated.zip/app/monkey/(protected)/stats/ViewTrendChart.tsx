// 纯 SVG 画柱状图，不依赖任何图表库——个人后台仪表盘用不上 recharts/chart.js 这种量级的东西，
// 服务端直接渲染出 SVG，没有交互也不需要 'use client'。
export default function ViewTrendChart({ data }: { data: { date: string; count: number }[] }) {
  const max = Math.max(1, ...data.map((d) => d.count));
  const barWidth = 100 / data.length;

  return (
    <div className="rounded border border-[var(--fg-10)] p-4">
      <svg
        viewBox="0 0 100 40"
        preserveAspectRatio="none"
        className="h-32 w-full"
        role="img"
        aria-label={`近 ${data.length} 天每日浏览量趋势图`}
      >
        {data.map((d, i) => {
          const height = (d.count / max) * 36;
          return (
            <rect
              key={d.date}
              x={i * barWidth + barWidth * 0.15}
              y={40 - height}
              width={Math.max(barWidth * 0.7, 0.3)}
              height={Math.max(height, 0.5)}
              fill="var(--accent-color)"
              opacity={d.count === 0 ? 0.15 : 0.85}
            >
              <title>{`${d.date}：${d.count} 次浏览`}</title>
            </rect>
          );
        })}
      </svg>
      <div className="mt-2 flex justify-between text-[10px] text-[var(--fg-40)]">
        <span>{data[0]?.date}</span>
        <span>{data[data.length - 1]?.date}</span>
      </div>
    </div>
  );
}
