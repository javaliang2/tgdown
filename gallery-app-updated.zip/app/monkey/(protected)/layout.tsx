import Link from 'next/link';
import LogoutButton from './LogoutButton';
import { requireAdminPage } from '@/lib/auth';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  // 第二道防线：proxy.ts 已经在网络边界拦过一次未登录访问，这里在渲染路径上再查一次
  // session，没有就直接 redirect 到登录页。就算 proxy.ts 那层因为改动/配置疏漏失效，
  // 这里也不会把任何后台数据渲染出去。详见 lib/auth.ts 里 requireAdminPage 的注释。
  await requireAdminPage();

  return (
    <div>
      <nav className="border-b border-[var(--fg-10)] bg-[var(--fg-5)]">
        <div className="mx-auto flex max-w-4xl flex-wrap items-center gap-x-1 gap-y-2 px-4 py-3 text-sm">
          <Link href="/monkey" className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]">
            图集管理
          </Link>
          <Link
            href="/monkey/stats"
            className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
          >
            统计
          </Link>
          <Link
            href="/monkey/categories"
            className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
          >
            分类管理
          </Link>
          <Link
            href="/monkey/tags"
            className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
          >
            标签管理
          </Link>
          <Link
            href="/monkey/users"
            className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
          >
            用户管理
          </Link>
          <Link
            href="/monkey/menu"
            className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
          >
            导航菜单
          </Link>
          <Link
            href="/monkey/settings"
            className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
          >
            外观设置
          </Link>

          <div className="ml-auto flex items-center gap-1">
            <a
              href="/"
              target="_blank"
              rel="noopener noreferrer"
              className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
            >
              查看前台 ↗
            </a>
            <LogoutButton />
          </div>
        </div>
      </nav>
      {children}
    </div>
  );
}
