'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { uploadPhoto } from '../../photo-upload';
import TagInput from '../../../TagInput';

type Category = { id: string; name: string; parentId: string | null };

type Photo = { id: string; thumbUrl: string; thumbKey: string; width: number; height: number };

type AlbumMeta = {
  id: string;
  title: string;
  description: string;
  tags: string[];
  status: 'DRAFT' | 'PUBLISHED';
  visibility: 'PUBLIC' | 'PRIVATE';
  categoryId: string;
  parentCategoryId: string;
  coverKey: string;
};

export default function EditAlbumForm({
  album,
  categories,
  initialPhotos,
}: {
  album: AlbumMeta;
  categories: Category[];
  initialPhotos: Photo[];
}) {
  const router = useRouter();

  const [title, setTitle] = useState(album.title);
  const [description, setDescription] = useState(album.description);
  const [tags, setTags] = useState(album.tags);
  const [status, setStatus] = useState(album.status);
  const [visibility, setVisibility] = useState(album.visibility);
  const [parentCategoryId, setParentCategoryId] = useState(album.parentCategoryId);
  const [categoryId, setCategoryId] = useState(album.categoryId);
  const [coverKey, setCoverKey] = useState(album.coverKey);
  const [photos, setPhotos] = useState(initialPhotos);

  const [savingMeta, setSavingMeta] = useState(false);
  const [metaMessage, setMetaMessage] = useState('');
  const [busyPhotoId, setBusyPhotoId] = useState<string | null>(null); // 正在删/排序哪张图，禁用对应按钮
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState('');

  // router.refresh() 之后服务端组件会重新查数据库、传新的 props 下来，这里同步一下本地状态
  useEffect(() => setPhotos(initialPhotos), [initialPhotos]);
  useEffect(() => setCoverKey(album.coverKey), [album.coverKey]);

  async function saveMeta(e: React.FormEvent) {
    e.preventDefault();
    setSavingMeta(true);
    setMetaMessage('');
    const res = await fetch(`/api/monkey/albums/${album.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title,
        description,
        tags,
        status,
        visibility,
        categoryId: categoryId || parentCategoryId || null,
      }),
    });
    setSavingMeta(false);
    if (res.ok) {
      setMetaMessage('已保存');
      router.refresh();
    } else {
      const data = await res.json();
      setMetaMessage(data.error || '保存失败');
    }
  }

  async function handleAddFiles(fileList: FileList | null) {
    const list = Array.from(fileList || []);
    if (list.length === 0) return;
    setUploading(true);
    try {
      const newPhotos = [];
      for (let i = 0; i < list.length; i++) {
        setUploadProgress(`正在上传第 ${i + 1} / ${list.length} 张…`);
        newPhotos.push(await uploadPhoto(list[i], title));
      }
      setUploadProgress('正在保存…');
      const res = await fetch(`/api/monkey/albums/${album.id}/photos`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ photos: newPhotos }),
      });
      if (!res.ok) {
        const data = await res.json();
        alert(data.error || '添加图片失败');
      } else {
        router.refresh();
      }
    } finally {
      setUploading(false);
      setUploadProgress('');
    }
  }

  async function handleDeletePhoto(photoId: string) {
    if (!confirm('删除这张图片？（R2 上的原图和缩略图也会一起删，不能撤销）')) return;
    setBusyPhotoId(photoId);
    const res = await fetch(`/api/monkey/albums/${album.id}/photos/${photoId}`, { method: 'DELETE' });
    setBusyPhotoId(null);
    if (res.ok) {
      router.refresh();
    } else {
      const data = await res.json();
      alert(data.error || '删除失败');
    }
  }

  async function handleSetCover(photo: Photo) {
    setBusyPhotoId(photo.id);
    const res = await fetch(`/api/monkey/albums/${album.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ coverKey: photo.thumbKey }),
    });
    setBusyPhotoId(null);
    if (res.ok) {
      setCoverKey(photo.thumbKey);
      router.refresh();
    } else {
      const data = await res.json();
      alert(data.error || '设置封面失败');
    }
  }

  async function handleReorder(index: number, direction: -1 | 1) {
    const target = index + direction;
    if (target < 0 || target >= photos.length) return;
    const next = [...photos];
    [next[index], next[target]] = [next[target], next[index]];
    setPhotos(next); // 先本地换个位置，手感跟得上，接口失败了再靠 router.refresh() 兜回来

    setBusyPhotoId(photos[index].id);
    const res = await fetch(`/api/monkey/albums/${album.id}/photos/reorder`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ order: next.map((p) => p.id) }),
    });
    setBusyPhotoId(null);
    if (res.ok) {
      router.refresh();
    } else {
      alert('排序保存失败，刷新页面重试');
      router.refresh();
    }
  }

  return (
    <div className="mx-auto max-w-xl px-4 py-8">
      <h1 className="mb-6 text-xl">编辑图集</h1>

      <form onSubmit={saveMeta} className="space-y-4">
        <input
          placeholder="标题"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        />
        <textarea
          placeholder="描述（可选）"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          rows={3}
        />
        <TagInput value={tags} onChange={setTags} />
        <div className="flex flex-col gap-2 sm:flex-row">
          <select
            value={parentCategoryId}
            onChange={(e) => {
              setParentCategoryId(e.target.value);
              setCategoryId('');
            }}
            className="flex-1 rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          >
            <option value="" className="bg-black">选择大类</option>
            {categories
              .filter((c) => !c.parentId)
              .map((c) => (
                <option key={c.id} value={c.id} className="bg-black">
                  {c.name}
                </option>
              ))}
          </select>
          <select
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value)}
            disabled={!parentCategoryId}
            className="flex-1 rounded border border-[var(--fg-20)] bg-transparent px-3 py-2 disabled:opacity-40"
          >
            <option value="" className="bg-black">
              {parentCategoryId ? '不选子分类（直接挂在大类下）' : '先选大类'}
            </option>
            {categories
              .filter((c) => c.parentId === parentCategoryId)
              .map((c) => (
                <option key={c.id} value={c.id} className="bg-black">
                  {c.name}
                </option>
              ))}
          </select>
        </div>
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value as 'DRAFT' | 'PUBLISHED')}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        >
          <option value="PUBLISHED" className="bg-black">已发布</option>
          <option value="DRAFT" className="bg-black">草稿（前台不可见）</option>
        </select>
        <select
          value={visibility}
          onChange={(e) => setVisibility(e.target.value as 'PUBLIC' | 'PRIVATE')}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        >
          <option value="PUBLIC" className="bg-black">
            公开（所有人可见）
          </option>
          <option value="PRIVATE" className="bg-black">
            私密（封面正常展示，照片内容需要在"用户管理"里单独授权才能看）
          </option>
        </select>

        <div className="flex items-center gap-3">
          <button
            type="submit"
            disabled={savingMeta || !title}
            style={{ backgroundColor: 'var(--accent-color)' }}
            className="rounded px-4 py-2 text-sm text-[var(--accent-contrast)] disabled:opacity-50"
          >
            {savingMeta ? '保存中…' : '保存修改'}
          </button>
          {metaMessage && <span className="text-sm text-[var(--fg-50)]">{metaMessage}</span>}
        </div>
      </form>

      <div className="mt-10 border-t border-[var(--fg-10)] pt-6">
        <p className="mb-2 text-sm text-[var(--fg-50)]">
          点图片设为封面；用左右箭头调整顺序；每张图旁边可以单独删除。改动是立即生效的，不用点"保存修改"。
        </p>
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
          {photos.map((photo, i) => {
            const busy = busyPhotoId === photo.id;
            const isCover = photo.thumbKey === coverKey;
            return (
              <div key={photo.id} className="space-y-1">
                <button
                  type="button"
                  onClick={() => handleSetCover(photo)}
                  disabled={busy}
                  style={isCover ? { boxShadow: '0 0 0 2px var(--accent-color)' } : undefined}
                  className="relative block aspect-square w-full overflow-hidden rounded bg-[var(--fg-5)] disabled:opacity-50"
                  title="设为封面"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={photo.thumbUrl} alt="" className="h-full w-full object-cover" />
                  {isCover && (
                    <span className="absolute bottom-1 left-1 rounded bg-[var(--accent-color)] px-1.5 py-0.5 text-[10px] text-[var(--accent-contrast)]">
                      封面
                    </span>
                  )}
                </button>
                <div className="flex items-center justify-between text-xs text-[var(--fg-50)]">
                  <div className="flex gap-1">
                    <button
                      type="button"
                      onClick={() => handleReorder(i, -1)}
                      disabled={busy || i === 0}
                      className="rounded px-1.5 py-0.5 hover:bg-[var(--fg-10)] disabled:opacity-30"
                    >
                      ←
                    </button>
                    <button
                      type="button"
                      onClick={() => handleReorder(i, 1)}
                      disabled={busy || i === photos.length - 1}
                      className="rounded px-1.5 py-0.5 hover:bg-[var(--fg-10)] disabled:opacity-30"
                    >
                      →
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleDeletePhoto(photo.id)}
                    disabled={busy}
                    className="rounded px-1.5 py-0.5 text-red-400 hover:bg-[var(--fg-10)] disabled:opacity-30"
                  >
                    删除
                  </button>
                </div>
              </div>
            );
          })}
        </div>
        {photos.length === 0 && (
          <p className="py-6 text-center text-sm text-[var(--fg-30)]">这个图集还没有图片</p>
        )}

        <div className="mt-4">
          <input
            type="file"
            accept="image/*"
            multiple
            disabled={uploading}
            onChange={(e) => {
              handleAddFiles(e.target.files);
              e.target.value = ''; // 清空，方便再选同一批文件重新加
            }}
            className="w-full text-sm"
          />
          {uploading && <p className="mt-1 text-xs text-[var(--fg-50)]">{uploadProgress || '上传中…'}</p>}
        </div>
      </div>
    </div>
  );
}
