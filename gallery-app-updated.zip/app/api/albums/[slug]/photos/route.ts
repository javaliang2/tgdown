import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { publicUrl, createPrivatePhotoUrl } from '@/lib/storage';
import { getCurrentUser } from '@/lib/user-auth';

// 显式声明绝不缓存——这个接口的返回结果因人而异（取决于当前登录用户是否被授权），
// 不能有任何一层缓存把某个用户的授权结果套用到另一个用户身上。不依赖 Next.js
// Route Handler 默认是不是动态的，显式写出来更保险，也更清楚地表达"这里不能缓存"的意图。
export const dynamic = 'force-dynamic';

// 私密相册的照片数据故意不放进 /[slug] 页面本身的服务端渲染结果——那个页面是
// export const revalidate = 3600 的 ISR 静态页，同一份 HTML 会被所有访客共用，
// 如果照片 URL 直接写进页面源码/JSON-LD，就算前端"不显示"，任何人查看源码
// 都能看到，等于没锁。所以私密相册的照片单独放在这个接口后面，每次请求都
// 实时查数据库判断"这个登录用户到底有没有被授权"，权限判断永远不会被缓存。
export async function GET(req: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;

  const album = await prisma.album.findUnique({
    where: { slug, status: 'PUBLISHED' },
    select: {
      id: true,
      title: true,
      visibility: true,
      photos: {
        orderBy: { sortOrder: 'asc' },
        select: { id: true, r2Key: true, width: true, height: true, altText: true, blurDataURL: true },
      },
      allowedUsers: { select: { id: true } },
    },
  });

  if (!album) {
    return NextResponse.json({ error: '相册不存在' }, { status: 404 });
  }

  // 公开相册照理说不会走这个接口（前端直接从页面渲染拿），但万一有人直接调用，
  // 也没必要拒绝——反正本来就是公开内容
  if (album.visibility === 'PUBLIC') {
    return NextResponse.json({ photos: album.photos.map(toPhotoDto) });
  }

  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: '需要登录', code: 'UNAUTHENTICATED' }, { status: 401 });
  }

  const authorized = album.allowedUsers.some((u) => u.id === user.id);
  if (!authorized) {
    return NextResponse.json({ error: '没有访问权限', code: 'FORBIDDEN' }, { status: 403 });
  }

  // 私密相册通过验证后也不能直接给 publicUrl()——那是长期有效的公开地址，
  // URL 一旦被截图、转发、缓存在代理/浏览器历史里，就等于绕过了上面的权限校验。
  // 改成每张图单独签一个 30 分钟有效的临时地址，过期后存储端直接拒绝访问，
  // 权限时效跟着签名走，不依赖前端"记得"要不要展示。
  const photos = await Promise.all(album.photos.map(toPrivatePhotoDto));
  return NextResponse.json({ photos });
}

function toPhotoDto(photo: {
  id: string;
  r2Key: string;
  width: number;
  height: number;
  altText: string | null;
  blurDataURL: string | null;
}) {
  return {
    id: photo.id,
    url: publicUrl(photo.r2Key),
    width: photo.width,
    height: photo.height,
    alt: photo.altText || undefined,
    blurDataURL: photo.blurDataURL || undefined,
  };
}

async function toPrivatePhotoDto(photo: {
  id: string;
  r2Key: string;
  width: number;
  height: number;
  altText: string | null;
  blurDataURL: string | null;
}) {
  return {
    id: photo.id,
    url: await createPrivatePhotoUrl(photo.r2Key),
    width: photo.width,
    height: photo.height,
    alt: photo.altText || undefined,
    blurDataURL: photo.blurDataURL || undefined,
  };
}
