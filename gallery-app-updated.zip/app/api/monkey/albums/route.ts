import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { toSlug, RESERVED_SLUGS, findConflictingTag } from '@/lib/slug';
import { broadcastCacheInvalidation } from '@/lib/cache-broadcast';
import { requireAdminApi } from '@/lib/auth';

// GET: 后台图集列表（含草稿）
export async function GET() {
  const auth = await requireAdminApi();
  if ('response' in auth) return auth.response;

  const albums = await prisma.album.findMany({
    orderBy: { createdAt: 'desc' },
    include: { _count: { select: { photos: true } } },
  });
  return NextResponse.json(albums);
}

// POST: 创建图集
// body: { title, description, tags: string[], categoryId?: string, coverIndex?: number, photos: [{ r2Key, thumbKey, width, height, altText }] }
export async function POST(req: NextRequest) {
  const auth = await requireAdminApi();
  if ('response' in auth) return auth.response;

  const body = await req.json();
  const { title, description, tags = [], categoryId, coverIndex = 0, photos = [], visibility } = body;

  if (!title || photos.length === 0) {
    return NextResponse.json({ error: '标题和至少一张图片是必须的' }, { status: 400 });
  }

  const baseSlug = toSlug(title);
  let slug = baseSlug;
  let counter = 1;
  while (RESERVED_SLUGS.has(slug) || (await prisma.album.findUnique({ where: { slug } }))) {
    slug = `${baseSlug}-${counter++}`;
  }

  const tagConflict = await findConflictingTag(tags);
  if (tagConflict) {
    return NextResponse.json(
      { error: `标签名"${tagConflict}"和站点固定路径或已有图集地址重名，换一个名字` },
      { status: 400 },
    );
  }

  const cover = photos[coverIndex] || photos[0];

  const album = await prisma.album.create({
    data: {
      title,
      slug,
      description,
      tags: {
        connectOrCreate: Array.from(new Set(tags as string[])).map((name) => ({
          where: { name },
          create: { name },
        })),
      },
      categoryId: categoryId || null,
      coverKey: cover?.thumbKey,
      coverBlurDataURL: cover?.blurDataURL || null,
      status: 'PUBLISHED',
      visibility: visibility === 'PRIVATE' ? 'PRIVATE' : 'PUBLIC',
      publishedAt: new Date(),
      photos: {
        create: photos.map((p: any, i: number) => ({
          r2Key: p.r2Key,
          thumbKey: p.thumbKey,
          width: p.width,
          height: p.height,
          altText: p.altText || '',
          blurDataURL: p.blurDataURL || null,
          sortOrder: i,
        })),
      },
    },
  });

  // 重新生成首页和图集详情页的静态缓存（图集详情页是扁平路径 /slug，不是 /albums/slug）
  revalidatePath('/');
  revalidatePath(`/${slug}`);
  await broadcastCacheInvalidation([{ path: '/' }, { path: `/${slug}` }]);

  return NextResponse.json(album, { status: 201 });
}
