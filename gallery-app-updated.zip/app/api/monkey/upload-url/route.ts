import { NextRequest, NextResponse } from 'next/server';
import { createUploadUrl } from '@/lib/storage';
import { randomUUID } from 'crypto';
import { requireAdminApi } from '@/lib/auth';

// 请求体: { filename: string, contentType: string, kind: 'original' | 'thumb' | 'logo', fileSize: number }

// 只允许图片类型，避免后台账号一旦被盗，R2 公开域名被当成任意文件的免费文件床用
const ALLOWED_CONTENT_TYPES: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/gif': 'gif',
  'image/avif': 'avif',
};

// 不同 kind 的文件体积上限。之前预签名 URL 没有任何大小限制，理论上可以直传任意大的文件，
// 占用存储和 R2 出站流量；加上限之后，客户端上传时声明的 fileSize 既要过这道上限校验，
// 也会被签进预签名 URL 本身（见 lib/storage.ts 的 createUploadUrl），S3/R2 会要求实际
// PUT 请求的 Content-Length 跟签名里的值完全一致，"先报一个很小的值骗过这里的校验、
// 实际上传一个大文件"这种绕过方式也一并被存储端拒绝掉。
//
// thumb/logo 走的是前端 canvas 压缩产出的小图（缩略图固定压到 600px webp，logo 同理），
// 正常情况下几百 KB 以内；original 是有效的原图，5MB 阈值以内不会被前端二次压缩，
// 现代手机拍出来的高清照片轻松超过这个数，给到 30MB 留足够余量。
const MAX_BYTES: Record<string, number> = {
  original: 30 * 1024 * 1024,
  thumb: 5 * 1024 * 1024,
  logo: 5 * 1024 * 1024,
};

export async function POST(req: NextRequest) {
  const auth = await requireAdminApi();
  if ('response' in auth) return auth.response;

  const { filename, contentType, kind, fileSize } = await req.json();

  if (!filename || !contentType) {
    return NextResponse.json({ error: '缺少 filename 或 contentType' }, { status: 400 });
  }

  const safeExt = ALLOWED_CONTENT_TYPES[contentType];
  if (!safeExt) {
    return NextResponse.json(
      { error: `不支持的文件类型：${contentType}，仅支持 ${Object.keys(ALLOWED_CONTENT_TYPES).join(', ')}` },
      { status: 400 },
    );
  }

  const maxBytes = MAX_BYTES[kind] ?? MAX_BYTES.original;
  if (typeof fileSize !== 'number' || !Number.isFinite(fileSize) || fileSize <= 0) {
    return NextResponse.json({ error: '缺少有效的 fileSize' }, { status: 400 });
  }
  if (fileSize > maxBytes) {
    return NextResponse.json(
      { error: `文件太大（${(fileSize / 1024 / 1024).toFixed(1)}MB），上限是 ${maxBytes / 1024 / 1024}MB` },
      { status: 400 },
    );
  }

  // 后缀名从白名单里根据 contentType 反查出来，不再信任前端传来的原始文件名后缀，
  // 避免有人传 contentType: image/png 但文件名是 .html 之类的绕过方式
  const prefix = kind === 'thumb' ? 'thumbs' : kind === 'logo' ? 'logos' : 'photos';
  const key = `${prefix}/${new Date().getFullYear()}/${randomUUID()}.${safeExt}`;

  const uploadUrl = await createUploadUrl(key, contentType, 300, fileSize);

  return NextResponse.json({ uploadUrl, key });
}
