import { prisma } from '@/lib/db';

export type TagCount = { tag: string; count: number };

// 标签现在是真正的 Tag 表 + 隐式多对多关系（见 prisma/schema.prisma），
// 不再需要 unnest() 原生 SQL：直接用 Prisma 的关系计数（_count）统计每个标签下有多少图集。
//
// onlyPublished=true（前台用）只统计已发布图集下的标签，没有已发布图集的标签也不会出现；
// false（后台管理用）统计全部图集（含草稿），不然草稿上打的标签在后台管理页面里看不到、也没法重命名/删除。
export async function getTagCounts(onlyPublished: boolean): Promise<TagCount[]> {
  const tags = await prisma.tag.findMany({
    select: {
      name: true,
      _count: {
        select: {
          albums: onlyPublished ? { where: { status: 'PUBLISHED' } } : true,
        },
      },
    },
  });

  const counts = tags
    .map((t) => ({ tag: t.name, count: t._count.albums }))
    .filter((t) => !onlyPublished || t.count > 0);

  if (onlyPublished) {
    counts.sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag));
  } else {
    counts.sort((a, b) => a.tag.localeCompare(b.tag));
  }

  return counts;
}
