-- 后台仪表盘"近 N 天浏览量趋势"用的每日聚合表，见 schema.prisma 里的注释。
-- date 直接当主键，flush 浏览量攒批时 upsert 累加，不需要额外的自增 id。
CREATE TABLE "DailyViewStat" (
    "date" DATE NOT NULL,
    "count" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "DailyViewStat_pkey" PRIMARY KEY ("date")
);
