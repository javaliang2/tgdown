#!/bin/bash
# 从备份恢复数据库
# 用法：
#   ./scripts/restore.sh                        进入交互菜单选择
#   ./scripts/restore.sh backups/xxx.sql.gz      直接指定文件（跳过菜单，方便脚本调用）
set -e

cd "$(dirname "$0")/.."

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}!${NC} $1"; }
err()  { echo -e "${RED}✗${NC} $1"; }

BACKUP_FILE="$1"

# ---- 没直接给文件路径的话，进交互菜单 ----
if [ -z "$BACKUP_FILE" ]; then
  echo -e "${BLUE}== 选择要恢复的备份 ==${NC}"
  echo

  mkdir -p backups
  mapfile -t LOCAL_FILES < <(ls -t backups/backup-*.sql.gz 2>/dev/null)

  if [ ${#LOCAL_FILES[@]} -eq 0 ]; then
    warn "本地 backups/ 目录下还没有备份文件"
  else
    echo "本地备份："
    for i in "${!LOCAL_FILES[@]}"; do
      f="${LOCAL_FILES[$i]}"
      SIZE=$(du -h "$f" | cut -f1)
      MTIME=$(date -r "$f" "+%Y-%m-%d %H:%M" 2>/dev/null || stat -c '%y' "$f" | cut -d'.' -f1)
      printf "  %2d) %s  (%s, %s)\n" "$((i + 1))" "$(basename "$f")" "$SIZE" "$MTIME"
    done
  fi

  # 顺手看一眼 R2 上有没有更多远端备份可以选
  REMOTE_AVAILABLE=false
  if [ -f .env ]; then
    # shellcheck disable=SC1091
    set -a; source .env; set +a
  fi
  if command -v aws &> /dev/null && [ -n "$R2_ENDPOINT" ] && [ -n "$R2_BUCKET" ]; then
    export AWS_ACCESS_KEY_ID="$R2_ACCESS_KEY_ID"
    export AWS_SECRET_ACCESS_KEY="$R2_SECRET_ACCESS_KEY"
    export AWS_DEFAULT_REGION="auto"  # R2 不看这个值，但 aws-cli 要求必须传一个，不传部分版本会连不上
    mapfile -t REMOTE_FILES < <(aws s3 ls "s3://${R2_BUCKET}/db-backups/" --endpoint-url "$R2_ENDPOINT" 2>/dev/null | awk '{print $4}' | grep '\.sql\.gz$' | sort -r)
    if [ ${#REMOTE_FILES[@]} -gt 0 ]; then
      REMOTE_AVAILABLE=true
      echo
      echo "R2 异地备份（本地没有，选了会先下载）："
      for i in "${!REMOTE_FILES[@]}"; do
        printf "  r%d) %s\n" "$((i + 1))" "${REMOTE_FILES[$i]}"
      done
    fi
  fi

  if [ ${#LOCAL_FILES[@]} -eq 0 ] && [ "$REMOTE_AVAILABLE" = false ]; then
    err "本地和 R2 都没有找到可用的备份"
    exit 1
  fi

  echo
  read -rp "输入序号（本地填数字，远端填 r1/r2 这种）: " CHOICE

  if [[ "$CHOICE" =~ ^r([0-9]+)$ ]]; then
    IDX=$((${BASH_REMATCH[1]} - 1))
    REMOTE_NAME="${REMOTE_FILES[$IDX]}"
    if [ -z "$REMOTE_NAME" ]; then
      err "序号不对"
      exit 1
    fi
    echo "下载 ${REMOTE_NAME} 到本地…"
    aws s3 cp "s3://${R2_BUCKET}/db-backups/${REMOTE_NAME}" "backups/${REMOTE_NAME}" \
      --endpoint-url "$R2_ENDPOINT" --only-show-errors
    BACKUP_FILE="backups/${REMOTE_NAME}"
    ok "下载完成"
  elif [[ "$CHOICE" =~ ^[0-9]+$ ]]; then
    IDX=$((CHOICE - 1))
    BACKUP_FILE="${LOCAL_FILES[$IDX]}"
    if [ -z "$BACKUP_FILE" ]; then
      err "序号不对"
      exit 1
    fi
  else
    err "没看懂这个输入，退出了"
    exit 1
  fi
fi

if [ ! -f "$BACKUP_FILE" ]; then
  err "文件不存在: $BACKUP_FILE"
  exit 1
fi

# ---- 恢复前确认 ----
echo
warn "即将用 ${BACKUP_FILE} 覆盖当前数据库，这个操作不可撤销"
read -rp "确认要继续吗？输入 yes 确认: " CONFIRM
if [ "$CONFIRM" != "yes" ]; then
  echo "已取消"
  exit 0
fi

# 数据库现在是远程共享库（pg-redis-shared.sh 部署），直接用 DATABASE_URL 连过去，
# 不再走 docker compose exec 到本地容器。
if [ -f .env ]; then
  # shellcheck disable=SC1091
  set -a; source .env; set +a
fi

if [ -z "$DATABASE_URL" ]; then
  err ".env 里没有 DATABASE_URL，检查一下配置"
  exit 1
fi

if ! command -v pg_dump &> /dev/null || ! command -v psql &> /dev/null; then
  err "本机没装 pg_dump/psql，装一下 PostgreSQL 客户端工具再试："
  echo "    sudo apt install -y postgresql-client"
  exit 1
fi

# 恢复前先把当前数据库也存一份，万一发现选错了文件还能再退回来
echo "恢复前先给当前数据库留一份快照…"
mkdir -p backups
SAFETY_FILE="backups/before-restore-$(date +%Y%m%d-%H%M%S).sql.gz"
pg_dump "$DATABASE_URL" --clean --if-exists | gzip > "$SAFETY_FILE" 2>/dev/null \
  && ok "已保存到 ${SAFETY_FILE}，恢复完发现不对可以用它再退回来" \
  || warn "快照失败（可能是当前共享库还没连通），继续恢复"

echo "恢复中…"
if gunzip -c "$BACKUP_FILE" | psql "$DATABASE_URL" -v ON_ERROR_STOP=1; then
  ok "恢复完成，重启一下应用让缓存生效："
  echo "  docker compose restart web"
else
  err "恢复过程中出错了，数据库现在可能处于不一致状态"
  echo "  可以用刚才保存的快照再退回来： ./scripts/restore.sh ${SAFETY_FILE}"
  exit 1
fi
