-- AlterTable
ALTER TABLE "SiteSetting" ADD COLUMN     "logoKey" TEXT;
