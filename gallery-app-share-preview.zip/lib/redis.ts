import Redis from 'ioredis';

// 跟 lib/db.ts 一个套路：避免开发环境热重载重复创建连接。
// 连的是 pg-redis-shared.sh 部署在 WireGuard 内网的共享 Redis 实例。
const globalForRedis = globalThis as unknown as { redis?: Redis };

// 没配 REDIS_URL 时返回 null，调用方要自己 fallback（比如退回内存计数），
// 不强制要求 Redis 一定存在——单节点部署时不配 Redis 也能正常跑。
export const redis: Redis | null = (() => {
  if (!process.env.REDIS_URL) return null;
  if (globalForRedis.redis) return globalForRedis.redis;

  const client = new Redis(process.env.REDIS_URL, {
    // 多节点场景下网络抖动难免，失败重试而不是直接抛错让请求 500
    maxRetriesPerRequest: 2,
    retryStrategy: (times) => Math.min(times * 200, 2000),
    lazyConnect: false,
  });
  client.on('error', (err) => {
    // 打个日志就行，别让 Redis 连接问题打崩整个进程
    console.error('[redis] connection error:', err.message);
  });

  if (process.env.NODE_ENV !== 'production') globalForRedis.redis = client;
  return client;
})();
