import { PHASE_PRODUCTION_BUILD } from 'next/constants';

// 单独拆出来是因为 proxy.ts 跑在 Edge runtime 里，不能引入 next/headers 之类的 Node API，
// 但两边都要在启动时校验 AUTH_SECRET 是否配置好，且要算出同一把密钥。
//
// 没配 AUTH_SECRET 时，process.env.AUTH_SECRET! 会把字符串 "undefined" 当密钥用——
// 登录签发和 proxy.ts 校验用的是同一个错误的默认值，两边刚好能对上，看起来"正常工作"，
// 但实际上任何人只要知道这个默认值就能伪造管理员登录 cookie，所以必须尽早报错。
//
// 但「尽早」不能早到 `next build` 里去：build 阶段的 "Collecting page data" 步骤会
// import 到所有路由（包括 /api/admin/login），而 build 容器里通常没有运行时的 .env
// （.env 是 docker-compose 用 env_file 在启动容器时才挂进去的），如果这里照样抛错，
// 会直接把镜像构建打断。用 Next.js 内置的 NEXT_PHASE 判断出"现在是不是在 build"，
// build 阶段先放行，等真正 `next start` 跑起来（或者本地 `next dev`）时该报错还是照样报错。
const isBuildPhase = process.env.NEXT_PHASE === PHASE_PRODUCTION_BUILD;

let cachedSecret: Uint8Array | null = null;

export function getAuthSecretBytes(): Uint8Array {
  if (cachedSecret) return cachedSecret;

  const value = process.env.AUTH_SECRET;
  if (!value || value.length < 16) {
    if (isBuildPhase) {
      // build 阶段用不到真实密钥（没有请求进来），塞个占位值让 import 能过就行
      return new TextEncoder().encode('build-phase-placeholder');
    }
    throw new Error(
      'AUTH_SECRET 未设置或长度不足 16 位。请在 .env 中配置一个足够长的随机字符串（例如 openssl rand -base64 32）。',
    );
  }
  cachedSecret = new TextEncoder().encode(value);
  return cachedSecret;
}
