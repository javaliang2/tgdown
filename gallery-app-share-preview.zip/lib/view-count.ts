import { redis } from '@/lib/redis';
import { prisma } from '@/lib/db';

// 浏览量攒批写库。
//
// 背景（原来 app/api/albums/[slug]/view/route.ts 里的注释）：量级不大时每次上报
// 直接写库完全够用；量大了热门图集会被高频 UPDATE，行锁 + 写入量都跟着访问量线性增长。
//
// 这里把"高频小增量写"合并成"低频大增量写"：先把每个 slug 的待写入次数攒在 Redis 的
// 一个 Hash 里（HINCRBY），每分钟由定时器批量 flush 回 Postgres 一次。
// 没配 REDIS_URL 时保持原来的行为，直接写库，不强制要求 Redis 存在。

const PENDING_KEY = 'gallery:pendingviews';
const FLUSH_INTERVAL_MS = 60 * 1000;
const SHUTDOWN_FLUSH_TIMEOUT_MS = 3000;

const globalForViewFlush = globalThis as unknown as {
  galleryViewFlushTimer?: NodeJS.Timeout;
  galleryViewShutdownHooked?: boolean;
};

export async function recordAlbumView(slug: string): Promise<void> {
  if (!redis) {
    await prisma.album.update({ where: { slug }, data: { viewCount: { increment: 1 } } });
    return;
  }

  try {
    await redis.hincrby(PENDING_KEY, slug, 1);
  } catch (err) {
    // Redis 抖了，别丢这次浏览量，退回直接写库
    console.error('[view-count] redis hincrby failed, falling back to direct write:', err);
    await prisma.album.update({ where: { slug }, data: { viewCount: { increment: 1 } } });
  }
}

// 用 RENAME 把整个待写入 Hash "偷"过来再处理，而不是 HGETALL 完再挨个 HDEL：
// - RENAME 是原子操作。多节点部署时每个节点都在跑自己的定时器，谁先 RENAME 成功谁就
//   拿到这一批数据；别的节点这时候再 RENAME 同一个 key 会直接失败（源 key 已经不存在），
//   天然避免"两个节点各拿到一部分、重复计数或漏计数"，不需要额外加分布式锁。
// - RENAME 之后原来的 PENDING_KEY 立刻空出来接收新增量，flush 处理慢一点也不会丢
//   这期间进来的新浏览量。
export async function flushPendingViews(): Promise<void> {
  if (!redis) return;

  const claimedKey = `${PENDING_KEY}:flushing:${Date.now()}:${Math.random().toString(36).slice(2)}`;

  try {
    await redis.rename(PENDING_KEY, claimedKey);
  } catch {
    // 源 key 不存在：要么这一分钟没人访问，要么别的节点已经抢到这批数据了，都正常，直接跳过
    return;
  }

  try {
    const counts = await redis.hgetall(claimedKey);
    const entries = Object.entries(counts).filter(([, v]) => parseInt(v, 10) > 0);
    if (entries.length === 0) return;

    const results = await Promise.allSettled(
      entries.map(([slug, countStr]) =>
        prisma.album.update({
          where: { slug },
          data: { viewCount: { increment: parseInt(countStr, 10) } },
        }),
      ),
    );

    results.forEach((result, i) => {
      if (result.status === 'rejected') {
        // 通常是图集在攒批期间被删掉了，丢这一条计数就行，不影响其它图集写入
        console.error(`[view-count] failed to flush view count for "${entries[i][0]}":`, result.reason);
      }
    });
  } finally {
    await redis.del(claimedKey).catch(() => {});
  }
}

function startFlushLoop() {
  if (!redis) return;
  if (globalForViewFlush.galleryViewFlushTimer) return; // 避免开发环境热重载重复注册定时器

  const timer = setInterval(() => {
    flushPendingViews().catch((err) => console.error('[view-count] periodic flush failed:', err));
  }, FLUSH_INTERVAL_MS);
  timer.unref(); // 光靠这个定时器不该阻止进程正常退出

  globalForViewFlush.galleryViewFlushTimer = timer;
}

function withTimeout(promise: Promise<void>, ms: number): Promise<void> {
  return Promise.race([promise, new Promise<void>((resolve) => setTimeout(resolve, ms))]);
}

// 进程收到退出信号时（比如重新部署时 docker compose 发的 SIGTERM）尽量再 flush 一次，
// 缩小"最多丢失接近一分钟浏览量"的窗口。给了超时上限，flush 慢或者 Redis/DB 恰好不通的话
// 也不会拖着进程迟迟不退出。
function registerShutdownFlush() {
  if (globalForViewFlush.galleryViewShutdownHooked) return;
  globalForViewFlush.galleryViewShutdownHooked = true;

  const handler = () => {
    withTimeout(flushPendingViews().catch(() => {}), SHUTDOWN_FLUSH_TIMEOUT_MS).finally(() => process.exit(0));
  };
  process.once('SIGTERM', handler);
  process.once('SIGINT', handler);
}

startFlushLoop();
registerShutdownFlush();
