import { redis } from '@/lib/redis';

// 通用滑动窗口限流：优先走 Redis（多实例部署时跨实例共享计数），
// 没配 REDIS_URL 或 Redis 抖了则退化成单实例内存计数——足够挡住简单脚本，
// 但多实例场景下每个实例各自一份内存计数，互相看不到彼此的请求，真正生效还是得配 Redis。
// 具体取舍原因见 app/api/albums/[slug]/view/route.ts 里最早的实现，这里只是把它抽成通用版本。

const PRUNE_INTERVAL_MS = 10 * 60 * 1000; // 每 10 分钟清一次内存里过期的 key，避免无限增长
const memoryHits = new Map<string, { count: number; resetAt: number }>();
let lastPruneAt = 0;

function pruneExpiredHits(now: number) {
  if (now - lastPruneAt < PRUNE_INTERVAL_MS) return;
  lastPruneAt = now;
  for (const [key, entry] of memoryHits) {
    if (now > entry.resetAt) memoryHits.delete(key);
  }
}

function isRateLimitedInMemory(key: string, windowMs: number, max: number): boolean {
  const now = Date.now();
  pruneExpiredHits(now);

  const entry = memoryHits.get(key);
  if (!entry || now > entry.resetAt) {
    memoryHits.set(key, { count: 1, resetAt: now + windowMs });
    return false;
  }
  entry.count += 1;
  return entry.count > max;
}

async function isRateLimitedInRedis(key: string, windowSec: number, max: number): Promise<boolean> {
  try {
    // INCR 是原子操作，多个实例并发命中同一个 key 也不会漏计
    const count = await redis!.incr(key);
    if (count === 1) {
      // 只有第一次自增（key 刚创建）才设过期时间，避免每次请求都重置窗口
      await redis!.expire(key, windowSec);
    }
    return count > max;
  } catch (err) {
    // Redis 抖了也别让接口直接挂掉，退回内存限流兜底
    console.error(`[rate-limit] redis failed for key "${key}", falling back to memory:`, err);
    return isRateLimitedInMemory(key, windowSec * 1000, max);
  }
}

/**
 * 判断某个 identity（通常是 IP）在 namespace 命名空间下是否已超出限流阈值。
 * namespace 用来隔离不同场景的计数（比如 "viewratelimit" 和 "loginratelimit"），
 * 避免两边共用一个 key 互相影响。
 */
export function isRateLimited(
  namespace: string,
  identity: string,
  { windowMs, max }: { windowMs: number; max: number },
): Promise<boolean> | boolean {
  const key = `gallery:${namespace}:${identity}`;
  return redis ? isRateLimitedInRedis(key, windowMs / 1000, max) : isRateLimitedInMemory(key, windowMs, max);
}
