import { NextRequest, NextResponse } from 'next/server';
import { createUploadUrl } from '@/lib/r2';
import { randomUUID } from 'crypto';

// 请求体: { filename: string, contentType: string, kind: 'original' | 'thumb' }

// 只允许图片类型，避免后台账号一旦被盗，R2 公开域名被当成任意文件的免费文件床用
const ALLOWED_CONTENT_TYPES: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/gif': 'gif',
  'image/avif': 'avif',
};

export async function POST(req: NextRequest) {
  const { filename, contentType, kind } = await req.json();

  if (!filename || !contentType) {
    return NextResponse.json({ error: '缺少 filename 或 contentType' }, { status: 400 });
  }

  const safeExt = ALLOWED_CONTENT_TYPES[contentType];
  if (!safeExt) {
    return NextResponse.json(
      { error: `不支持的文件类型：${contentType}，仅支持 ${Object.keys(ALLOWED_CONTENT_TYPES).join(', ')}` },
      { status: 400 },
    );
  }

  // 后缀名从白名单里根据 contentType 反查出来，不再信任前端传来的原始文件名后缀，
  // 避免有人传 contentType: image/png 但文件名是 .html 之类的绕过方式
  const prefix = kind === 'thumb' ? 'thumbs' : kind === 'logo' ? 'logos' : 'photos';
  const key = `${prefix}/${new Date().getFullYear()}/${randomUUID()}.${safeExt}`;

  const uploadUrl = await createUploadUrl(key, contentType);

  return NextResponse.json({ uploadUrl, key });
}
