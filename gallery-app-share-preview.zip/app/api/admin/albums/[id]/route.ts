import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { deleteObject } from '@/lib/r2';
import { revalidatePath } from 'next/cache';
import { broadcastCacheInvalidation } from '@/lib/cache-broadcast';

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const album = await prisma.album.findUnique({
    where: { id },
    include: { photos: true },
  });
  if (!album) {
    return NextResponse.json({ error: '图集不存在' }, { status: 404 });
  }

  // 先删数据库记录（级联删除 photos），再清理 R2 上的文件。
  // 反过来做的话，一旦 R2 那一步中途失败，会出现"数据库还在、图片已经没了"的悬空图集，
  // 前台直接裂图；现在这个顺序最坏情况只是 R2 上留几个没清干净的孤儿文件，不影响线上展示。
  await prisma.album.delete({ where: { id } });

  const results = await Promise.allSettled(
    album.photos.flatMap((p) => [deleteObject(p.r2Key), deleteObject(p.thumbKey)])
  );
  const failedCount = results.filter((r) => r.status === 'rejected').length;
  if (failedCount > 0) {
    console.error(`删除图集 ${album.slug} 时，有 ${failedCount} 个 R2 文件清理失败，需要手动检查`);
  }

  revalidatePath('/');
  revalidatePath(`/albums/${album.slug}`);
  await broadcastCacheInvalidation([{ path: '/' }, { path: `/albums/${album.slug}` }]);

  return NextResponse.json({ ok: true, r2CleanupFailed: failedCount });
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json();

  // 手动切换封面时，客户端只传了 coverKey（也就是某张 Photo 的 thumbKey），
  // coverBlurDataURL 要跟着查出来一起存，不然封面模糊占位图会跟实际封面对不上。
  let coverBlurDataURL: string | null | undefined = undefined;
  if ('coverKey' in body) {
    if (body.coverKey) {
      const coverPhoto = await prisma.photo.findFirst({
        where: { albumId: id, thumbKey: body.coverKey },
        select: { blurDataURL: true },
      });
      coverBlurDataURL = coverPhoto?.blurDataURL ?? null;
    } else {
      coverBlurDataURL = null;
    }
  }

  const album = await prisma.album.update({
    where: { id },
    data: {
      title: body.title,
      description: body.description,
      tags: body.tags,
      status: body.status,
      categoryId: 'categoryId' in body ? body.categoryId : undefined,
      coverKey: 'coverKey' in body ? body.coverKey : undefined,
      coverBlurDataURL,
    },
  });

  revalidatePath('/');
  revalidatePath(`/albums/${album.slug}`);
  await broadcastCacheInvalidation([{ path: '/' }, { path: `/albums/${album.slug}` }]);

  return NextResponse.json(album);
}
