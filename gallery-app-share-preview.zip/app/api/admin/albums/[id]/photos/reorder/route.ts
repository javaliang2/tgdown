import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { broadcastCacheInvalidation } from '@/lib/cache-broadcast';

// PATCH: 按传入的 photo id 顺序重新赋值 sortOrder
// body: { order: string[] }
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { order } = await req.json();

  if (!Array.isArray(order) || order.length === 0) {
    return NextResponse.json({ error: '参数错误' }, { status: 400 });
  }

  // 只允许改属于这个图集的图片，不然传个别的图集的 photo id 进来也能被改
  const owned = await prisma.photo.findMany({ where: { albumId: id }, select: { id: true } });
  const ownedIds = new Set(owned.map((p) => p.id));
  if (!order.every((photoId: string) => ownedIds.has(photoId))) {
    return NextResponse.json({ error: '图片不属于这个图集' }, { status: 400 });
  }

  await prisma.$transaction(
    order.map((photoId: string, index: number) =>
      prisma.photo.update({ where: { id: photoId }, data: { sortOrder: index } }),
    ),
  );

  const album = await prisma.album.findUnique({ where: { id }, select: { slug: true } });
  if (album) {
    revalidatePath('/');
    revalidatePath(`/albums/${album.slug}`);
    await broadcastCacheInvalidation([{ path: '/' }, { path: `/albums/${album.slug}` }]);
  }

  return NextResponse.json({ ok: true });
}
