import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { isRateLimited } from '@/lib/rate-limit';
import { getClientIp } from '@/lib/client-ip';
import { recordAlbumView } from '@/lib/view-count';

// 浏览量现在走 Redis 攒批 + 定时 flush 回库，减少热门图集的高频写入，
// 具体实现和多节点场景下的取舍见 lib/view-count.ts。

const VIEWED_COOKIE = 'viewed_albums';
const VIEWED_COOKIE_MAX_AGE = 60 * 60 * 24; // 24 小时内同一浏览器对同一图集只计一次
const RATE_LIMIT_WINDOW_MS = 60 * 1000; // 每个 IP 每分钟最多这么多次上报（跨所有图集）
const RATE_LIMIT_MAX = 20;

function isSameOriginRequest(req: NextRequest): boolean {
  // 用请求自带的 Host 头做基准，而不是依赖 SITE_URL 有没有配置对——
  // 万一 SITE_URL 忘了配或者临时用 http://IP:端口 测试，用 SITE_URL 当基准会把正常请求也拦掉。
  const allowedHost = req.headers.get('host');
  if (!allowedHost) return false;

  const origin = req.headers.get('origin');
  const referer = req.headers.get('referer');

  // 埋点脚本是同源 fetch，正常请求一定带 Origin 或 Referer 中的一个，且 host 得和当前请求一致。
  // 没带这两个头的（比如脚本直接拿 curl 打）也一律当作非法请求拒绝。
  try {
    if (origin) return new URL(origin).host === allowedHost;
    if (referer) return new URL(referer).host === allowedHost;
  } catch {
    return false;
  }
  return false;
}

function parseViewedSlugs(raw: string | undefined): Set<string> {
  if (!raw) return new Set();
  try {
    const arr = JSON.parse(raw);
    return new Set(Array.isArray(arr) ? arr : []);
  } catch {
    return new Set();
  }
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;

  if (!isSameOriginRequest(req)) {
    return NextResponse.json({ ok: false, reason: 'forbidden' }, { status: 403 });
  }

  // 先查 cookie 去重，24 小时内已经计过的请求直接放行、不占用 IP 限流额度。
  // 这样同一个 IP 后面挂着很多人的场景（公司网络、学校、NAT）里，大家反复访问
  // 已经看过的图集不会互相占用限流名额；限流只用来挡"确实在持续制造新增计数"的刷量。
  const viewedSlugs = parseViewedSlugs(req.cookies.get(VIEWED_COOKIE)?.value);
  if (viewedSlugs.has(slug)) {
    return NextResponse.json({ ok: true, counted: false });
  }

  const ip = getClientIp(req);
  if (await isRateLimited('viewratelimit', ip, { windowMs: RATE_LIMIT_WINDOW_MS, max: RATE_LIMIT_MAX })) {
    return NextResponse.json({ ok: false, reason: 'rate_limited' }, { status: 429 });
  }

  try {
    // 之前直接 UPDATE 顺带验证了图集存在（不存在就抛错走 404）。改成攒批写入之后，
    // 这个校验得单独做一次：否则给一个不存在的 slug 刷上报，计数会一直攒在 Redis 里，
    // flush 的时候才发现图集不存在、白白报错，而且客户端也拿不到正确的 404。
    const album = await prisma.album.findUnique({ where: { slug }, select: { id: true } });
    if (!album) {
      return NextResponse.json({ ok: false }, { status: 404 });
    }

    await recordAlbumView(slug);

    viewedSlugs.add(slug);
    const res = NextResponse.json({ ok: true, counted: true });
    res.cookies.set(VIEWED_COOKIE, JSON.stringify([...viewedSlugs]), {
      httpOnly: true,
      sameSite: 'lax',
      path: '/',
      maxAge: VIEWED_COOKIE_MAX_AGE,
    });
    return res;
  } catch {
    return NextResponse.json({ ok: false }, { status: 404 });
  }
}
