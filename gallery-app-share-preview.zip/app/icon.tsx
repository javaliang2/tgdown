import { ImageResponse } from 'next/og';
import { getSiteSettings } from '@/lib/settings';
import { getContrastTextColor } from '@/lib/color';
import { getLogoDataUri } from '@/lib/site-asset';

// 需要查数据库拿站点设置，Prisma 不支持 Edge runtime，这里显式声明跑在 Node 上
export const runtime = 'nodejs';
export const revalidate = 3600; // 跟站点设置改动的生效速度比，浏览器请求 favicon 更频繁，缓存一下避免每次都查库

export const size = { width: 32, height: 32 };
export const contentType = 'image/png';

export default async function Icon() {
  const [settings, logoDataUri] = await Promise.all([getSiteSettings(), getLogoDataUri()]);

  if (logoDataUri) {
    try {
      return new ImageResponse(
        (
          <div
            style={{
              width: size.width,
              height: size.height,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={logoDataUri} width={size.width} height={size.height} style={{ objectFit: 'contain' }} />
          </div>
        ),
        { ...size },
      );
    } catch {
      // satori 渲染这张图失败了（比如图片格式它不认），别让整个 favicon 请求直接 500，退回文字版
    }
  }

  // 没设置 logo 时，退回到取站点标题首字的兜底方案
  const letter = (settings.siteTitle?.trim()?.[0] || '图').toUpperCase();
  const textColor = getContrastTextColor(settings.accentColor);

  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: settings.accentColor,
          color: textColor,
          fontSize: 20,
          fontWeight: 600,
          borderRadius: 6,
        }}
      >
        {letter}
      </div>
    ),
    { ...size },
  );
}
