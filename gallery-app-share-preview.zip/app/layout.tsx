import type { Metadata } from 'next';
import './globals.css';
import { getSiteSettings } from '@/lib/settings';
import { getContrastTextColor } from '@/lib/color';
import { getNavLinks } from '@/lib/navlinks';
import { publicUrl } from '@/lib/r2';
import SiteNav from './components/SiteNav';
import SearchButton from './components/SearchButton';
import ThemeToggle from './components/ThemeToggle';
import Footer from './components/Footer';
import { siteUrl } from '@/lib/site-url';

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getSiteSettings();
  return {
    metadataBase: new URL(siteUrl()),
    title: {
      default: settings.siteTitle,
      template: `%s`,
    },
    description: settings.siteDescription,
    // 这里的 openGraph / twitter 是全站默认值。子路由（比如图集详情页）如果自己
    // 在 generateMetadata 里定义了 openGraph，会整体覆盖掉这里的值；
    // 没有单独定义的页面（首页、关于、标签、搜索）就用这份默认值，
    // 分享图片则由 app/opengraph-image.tsx 自动兜底提供。
    openGraph: {
      type: 'website',
      siteName: settings.siteTitle,
      title: settings.siteTitle,
      description: settings.siteDescription,
      locale: 'zh_CN',
    },
    twitter: {
      card: 'summary_large_image',
      title: settings.siteTitle,
      description: settings.siteDescription,
    },
  };
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const [settings, navLinks] = await Promise.all([getSiteSettings(), getNavLinks()]);

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: settings.siteTitle,
    url: siteUrl(),
    potentialAction: {
      '@type': 'SearchAction',
      target: `${siteUrl()}/search?q={search_term_string}`,
      'query-input': 'required name=search_term_string',
    },
  };

  return (
    <html
      lang="zh-CN"
      style={
        {
          '--bg-color': settings.backgroundColor,
          '--text-color': settings.textColor,
          '--accent-color': settings.accentColor,
          '--accent-contrast': getContrastTextColor(settings.accentColor),
        } as React.CSSProperties
      }
    >
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, '\\u003c') }}
        />
        {/* 在 hydration 之前、首帧绘制之前就把暗色 class 加上去，避免"先亮一下再变暗"的闪烁。
            这段必须跟 ThemeToggle.tsx 里的 STORAGE_KEY（'gallery-theme'）保持一致。 */}
        <script
          dangerouslySetInnerHTML={{
            __html:
              "(function(){try{if(localStorage.getItem('gallery-theme')==='dark'){document.documentElement.classList.add('dark-mode');}}catch(e){}})();",
          }}
        />
      </head>
      <body>
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--fg-10)] px-6 py-4">
          <a href="/" className="flex items-center gap-2 text-lg tracking-wide">
            {settings.logoKey && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={publicUrl(settings.logoKey)} alt="" className="h-8 w-auto object-contain" />
            )}
            <span>{settings.siteTitle}</span>
          </a>
          <div className="flex items-center gap-1">
            <SearchButton />
            <ThemeToggle />
            <SiteNav links={navLinks} />
          </div>
        </header>
        <main className="min-h-screen">{children}</main>
        <Footer siteTitle={settings.siteTitle} icpNumber={settings.icpNumber} contactInfo={settings.contactInfo} />
      </body>
    </html>
  );
}
