import type { MetadataRoute } from 'next';
import { prisma } from '@/lib/db';
import { siteUrl } from '@/lib/site-url';

export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = siteUrl();

  // docker build 阶段拿不到真实 DATABASE_URL（数据库容器此时还没起来），
  // 跟 lib/navlinks.ts、lib/settings.ts 保持一致的兜底策略：查询失败就返回空列表，
  // 不让 /sitemap.xml 的预渲染把整个 build 搞挂。容器跑起来之后，revalidate=3600 会用
  // 真实数据库重新生成。
  let albumEntries: MetadataRoute.Sitemap = [];
  let tagEntries: MetadataRoute.Sitemap = [];
  try {
    const albums = await prisma.album.findMany({
      where: { status: 'PUBLISHED' },
      select: { slug: true, updatedAt: true },
      orderBy: { publishedAt: 'desc' },
    });

    albumEntries = albums.map((album) => ({
      url: `${base}/albums/${album.slug}`,
      lastModified: album.updatedAt,
      changeFrequency: 'weekly',
      priority: 0.8,
    }));

    const tags = await prisma.$queryRaw<{ tag: string }[]>`
      SELECT DISTINCT tag
      FROM "Album", unnest("Album"."tags") AS tag
      WHERE "Album"."status" = 'PUBLISHED'
    `;
    tagEntries = tags.map(({ tag }) => ({
      url: `${base}/tags/${encodeURIComponent(tag)}`,
      changeFrequency: 'weekly',
      priority: 0.4,
    }));
  } catch {
    // 数据库还没跑迁移，或者构建期查询失败时兜底为空，不影响页面渲染
  }

  return [
    {
      url: base,
      changeFrequency: 'daily',
      priority: 1,
    },
    {
      url: `${base}/about`,
      changeFrequency: 'monthly',
      priority: 0.3,
    },
    {
      url: `${base}/tags`,
      changeFrequency: 'weekly',
      priority: 0.4,
    },
    ...albumEntries,
    ...tagEntries,
  ];
}
