'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import type { SiteSettings } from '@/lib/settings';
import { getContrastTextColor } from '@/lib/color';

// favicon 用不上原图分辨率，缩小到这个长边再编码，存进数据库的这行数据不会太大
const LOGO_DATA_MAX_DIMENSION = 400;
const LOGO_DATA_QUALITY = 0.92;

// 用 canvas 把图片缩小、编码成 base64 data URI，直接存数据库用（不经过 R2）。
// 固定输出 PNG，是为了保留透明背景——logo 大概率是透明底的图，压成有损格式容易出问题。
async function fileToLogoDataUri(file: File): Promise<string> {
  const img = await createImageBitmap(file);
  const scale = Math.min(1, LOGO_DATA_MAX_DIMENSION / Math.max(img.width, img.height));
  const w = Math.round(img.width * scale);
  const h = Math.round(img.height * scale);
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  ctx.drawImage(img, 0, 0, w, h);
  return canvas.toDataURL('image/png', LOGO_DATA_QUALITY);
}

// 杂志风预设配色：背景统一走"暖调浅色"而不是纯白/纯灰，文字也不用纯黑，
// 强调色各自挑了一个克制的印刷色，整体是"editorial"的调性，不是渐变、不是图片。
const THEME_PRESETS: {
  name: string;
  backgroundColor: string;
  textColor: string;
  accentColor: string;
}[] = [
  { name: '经典杂志白', backgroundColor: '#F7F3EA', textColor: '#2B2723', accentColor: '#B5442E' },
  { name: '奶油牛皮纸', backgroundColor: '#F1E7D0', textColor: '#3A3226', accentColor: '#4B5D3A' },
  { name: '画廊灰白', backgroundColor: '#F3F1EC', textColor: '#1E1E1E', accentColor: '#1C3F5E' },
  { name: '暖调米黄', backgroundColor: '#EFE6D8', textColor: '#332B22', accentColor: '#8A6D3B' },
];

function ThemePresetSwatches({
  onPick,
}: {
  onPick: (preset: (typeof THEME_PRESETS)[number]) => void;
}) {
  return (
    <div>
      <label className="mb-1 block text-sm text-[var(--fg-70)]">
        杂志风预设（点一下直接套用，套用后仍可在下面手动微调）
      </label>
      <div className="flex flex-wrap gap-3">
        {THEME_PRESETS.map((preset) => (
          <button
            key={preset.name}
            type="button"
            onClick={() => onPick(preset)}
            title={preset.name}
            className="flex items-center gap-2 rounded border border-[var(--fg-20)] px-3 py-2 text-sm transition hover:border-[var(--fg-50)]"
            style={{ backgroundColor: preset.backgroundColor, color: preset.textColor }}
          >
            <span
              aria-hidden
              className="h-3.5 w-3.5 shrink-0 rounded-full ring-1 ring-black/10"
              style={{ backgroundColor: preset.accentColor }}
            />
            {preset.name}
          </button>
        ))}
      </div>
    </div>
  );
}

function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div>
      <label className="mb-1 block text-sm text-[var(--fg-70)]">{label}</label>
      <div className="flex items-center gap-2">
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-9 w-12 cursor-pointer rounded border border-[var(--fg-20)] bg-transparent p-0.5"
        />
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 rounded border border-[var(--fg-20)] bg-transparent px-3 py-2 text-sm"
        />
      </div>
    </div>
  );
}

export default function SettingsForm({
  initial,
  initialLogoUrl,
}: {
  initial: SiteSettings;
  initialLogoUrl: string | null;
}) {
  const router = useRouter();
  const [form, setForm] = useState(initial);
  const [submitting, setSubmitting] = useState(false);
  const [saved, setSaved] = useState(false);
  const [logoPreview, setLogoPreview] = useState(initialLogoUrl);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  // undefined = 这次没动 logo，保存时不touch数据库里的 logoData；
  // string = 新上传了一张，把这份缩小版 base64 存进去；null = 点了移除，清空它。
  const [logoDataDraft, setLogoDataDraft] = useState<string | null | undefined>(undefined);

  async function handleLogoChange(fileList: FileList | null) {
    const file = fileList?.[0];
    if (!file) return;
    setUploadingLogo(true);
    setLogoPreview(URL.createObjectURL(file)); // 先用本地预览，手感跟得上
    try {
      const [uploadRes, logoDataUri] = await Promise.all([
        (async () => {
          const res = await fetch('/api/admin/upload-url', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename: file.name, contentType: file.type, kind: 'logo' }),
          });
          if (!res.ok) throw new Error();
          return res.json();
        })(),
        fileToLogoDataUri(file), // 顺便生成缩小版 base64，给 favicon 用，存数据库
      ]);
      const { uploadUrl, key } = uploadRes;
      await fetch(uploadUrl, { method: 'PUT', headers: { 'Content-Type': file.type }, body: file });
      setForm((f) => ({ ...f, logoKey: key }));
      setLogoDataDraft(logoDataUri);
    } catch {
      alert('logo 上传失败，换张图再试试');
      setLogoPreview(initialLogoUrl);
    } finally {
      setUploadingLogo(false);
    }
  }

  function handleRemoveLogo() {
    setForm((f) => ({ ...f, logoKey: null }));
    setLogoPreview(null);
    setLogoDataDraft(null);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setSaved(false);
    const res = await fetch('/api/admin/settings', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...form,
        ...(logoDataDraft !== undefined ? { logoData: logoDataDraft } : {}),
      }),
    });
    setSubmitting(false);
    if (res.ok) {
      setSaved(true);
      setLogoDataDraft(undefined); // 保存成功后清掉草稿标记，避免下次没改 logo 也重复提交这份数据
      router.refresh();
    } else {
      alert('保存失败');
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div>
        <label className="mb-1 block text-sm text-[var(--fg-70)]">网站标题</label>
        <input
          value={form.siteTitle}
          onChange={(e) => setForm({ ...form, siteTitle: e.target.value })}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        />
      </div>

      <div>
        <label className="mb-1 block text-sm text-[var(--fg-70)]">
          网站 Logo（留空则页头显示纯文字标题；建议 PNG/WebP 透明背景，横向长条比较合适）
        </label>
        <div className="flex items-center gap-3">
          {logoPreview && (
            <div className="flex h-10 items-center rounded border border-[var(--fg-10)] bg-[var(--fg-5)] px-2">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={logoPreview} alt="Logo 预览" className="h-7 w-auto object-contain" />
            </div>
          )}
          <input
            type="file"
            accept="image/png,image/webp,image/jpeg,image/gif,image/avif"
            disabled={uploadingLogo}
            onChange={(e) => {
              handleLogoChange(e.target.files);
              e.target.value = '';
            }}
            className="flex-1 text-sm"
          />
          {logoPreview && (
            <button
              type="button"
              onClick={handleRemoveLogo}
              className="shrink-0 rounded px-2 py-1 text-xs text-red-400 hover:bg-[var(--fg-10)]"
            >
              移除
            </button>
          )}
        </div>
        {uploadingLogo && <p className="mt-1 text-xs text-[var(--fg-50)]">上传中…</p>}
      </div>

      <div>
        <label className="mb-1 block text-sm text-[var(--fg-70)]">网站描述（用于 SEO）</label>
        <textarea
          value={form.siteDescription}
          onChange={(e) => setForm({ ...form, siteDescription: e.target.value })}
          rows={2}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        />
      </div>

      <ThemePresetSwatches
        onPick={(preset) =>
          setForm((f) => ({
            ...f,
            backgroundColor: preset.backgroundColor,
            textColor: preset.textColor,
            accentColor: preset.accentColor,
          }))
        }
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <ColorField
          label="背景色"
          value={form.backgroundColor}
          onChange={(v) => setForm({ ...form, backgroundColor: v })}
        />
        <ColorField
          label="文字颜色"
          value={form.textColor}
          onChange={(v) => setForm({ ...form, textColor: v })}
        />
        <ColorField
          label="强调色（按钮/高亮）"
          value={form.accentColor}
          onChange={(v) => setForm({ ...form, accentColor: v })}
        />
      </div>

      {/* 实时预览 */}
      <div
        className="rounded border border-[var(--fg-10)] p-4"
        style={{ backgroundColor: form.backgroundColor, color: form.textColor }}
      >
        <div className="flex items-center gap-2 text-sm">
          {logoPreview ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={logoPreview} alt="" className="h-6 w-auto object-contain" />
          ) : null}
          <span>预览：{form.siteTitle}</span>
        </div>
        <button
          type="button"
          style={{ backgroundColor: form.accentColor, color: getContrastTextColor(form.accentColor) }}
          className="mt-2 rounded px-3 py-1 text-sm"
        >
          示例按钮
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-sm text-[var(--fg-70)]">备案号（留空则页脚不显示）</label>
          <input
            placeholder="例如：京ICP备xxxxxxxx号"
            value={form.icpNumber}
            onChange={(e) => setForm({ ...form, icpNumber: e.target.value })}
            className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          />
        </div>
        <div>
          <label className="mb-1 block text-sm text-[var(--fg-70)]">联系方式（留空则页脚不显示）</label>
          <input
            placeholder="例如：邮箱或微信号"
            value={form.contactInfo}
            onChange={(e) => setForm({ ...form, contactInfo: e.target.value })}
            className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          />
        </div>
      </div>

      <div>
        <label className="mb-1 block text-sm text-[var(--fg-70)]">
          关于页内容（显示在 /about，每行一段）
        </label>
        <textarea
          value={form.aboutContent}
          onChange={(e) => setForm({ ...form, aboutContent: e.target.value })}
          rows={4}
          placeholder="留空的话，关于页会显示「站长还没有填写关于页内容」"
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        />
      </div>

      <div className="flex items-center gap-3">
        <button
          type="submit"
          disabled={submitting}
          style={{ backgroundColor: 'var(--accent-color)' }}
          className="rounded px-4 py-2 text-[var(--accent-contrast)] disabled:opacity-50"
        >
          {submitting ? '保存中…' : '保存'}
        </button>
        {saved && <span className="text-sm text-green-400">已保存，前台立即生效</span>}
      </div>
    </form>
  );
}
