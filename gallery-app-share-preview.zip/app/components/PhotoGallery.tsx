'use client';

import { useEffect, useState, useCallback } from 'react';
import Image from 'next/image';

export type GalleryPhoto = {
  id: string;
  url: string;
  width: number;
  height: number;
  alt: string;
  blurDataURL?: string;
};

export default function PhotoGallery({ photos }: { photos: GalleryPhoto[] }) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const close = useCallback(() => setOpenIndex(null), []);
  const showPrev = useCallback(
    () => setOpenIndex((i) => (i === null ? i : (i - 1 + photos.length) % photos.length)),
    [photos.length]
  );
  const showNext = useCallback(
    () => setOpenIndex((i) => (i === null ? i : (i + 1) % photos.length)),
    [photos.length]
  );

  // 打开大图时锁住背景滚动，键盘走 Esc / ← / → 三个键
  useEffect(() => {
    if (openIndex === null) return;

    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    function handleKeydown(e: KeyboardEvent) {
      if (e.key === 'Escape') close();
      if (e.key === 'ArrowLeft') showPrev();
      if (e.key === 'ArrowRight') showNext();
    }
    document.addEventListener('keydown', handleKeydown);

    return () => {
      document.body.style.overflow = prevOverflow;
      document.removeEventListener('keydown', handleKeydown);
    };
  }, [openIndex, close, showPrev, showNext]);

  return (
    <>
      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
        {photos.map((photo, index) => (
          <button
            key={photo.id}
            type="button"
            onClick={() => setOpenIndex(index)}
            className="relative block aspect-auto overflow-hidden bg-[var(--fg-5)] text-left"
            aria-label="点击查看原图"
          >
            <Image
              src={photo.url}
              alt={photo.alt}
              width={photo.width}
              height={photo.height}
              sizes="(max-width: 768px) 100vw, 50vw"
              className="w-full"
              priority={index === 0}
              loading={index === 0 ? undefined : 'lazy'}
              {...(photo.blurDataURL ? { placeholder: 'blur' as const, blurDataURL: photo.blurDataURL } : {})}
            />
          </button>
        ))}
      </div>

      {openIndex !== null && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90"
          onClick={close}
        >
          <button
            type="button"
            onClick={close}
            aria-label="关闭"
            className="absolute right-3 top-3 flex h-11 w-11 items-center justify-center rounded-full text-2xl text-white/80 hover:bg-white/10 hover:text-white"
          >
            ✕
          </button>

          {photos.length > 1 && (
            <>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  showPrev();
                }}
                aria-label="上一张"
                className="absolute left-1 top-1/2 flex h-14 w-14 -translate-y-1/2 items-center justify-center rounded-full text-3xl text-white/80 hover:bg-white/10 hover:text-white sm:left-3"
              >
                ‹
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  showNext();
                }}
                aria-label="下一张"
                className="absolute right-1 top-1/2 flex h-14 w-14 -translate-y-1/2 items-center justify-center rounded-full text-3xl text-white/80 hover:bg-white/10 hover:text-white sm:right-3"
              >
                ›
              </button>
            </>
          )}

          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={photos[openIndex].url}
            alt={photos[openIndex].alt}
            onClick={(e) => e.stopPropagation()}
            style={
              photos[openIndex].blurDataURL
                ? {
                    backgroundImage: `url(${photos[openIndex].blurDataURL})`,
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                  }
                : undefined
            }
            className="max-h-[92vh] max-w-[92vw] object-contain"
          />

          {photos.length > 1 && (
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full bg-black/40 px-3 py-1 text-xs text-white/80">
              {openIndex + 1} / {photos.length}
            </div>
          )}
        </div>
      )}
    </>
  );
}
