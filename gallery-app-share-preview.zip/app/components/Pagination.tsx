import Link from 'next/link';

// 生成带省略号的页码列表，比如: 1 … 4 5 [6] 7 8 … 20
function buildPageList(current: number, total: number): (number | 'ellipsis')[] {
  const delta = 1; // 当前页左右各显示几个
  const pages: (number | 'ellipsis')[] = [];

  const left = Math.max(2, current - delta);
  const right = Math.min(total - 1, current + delta);

  pages.push(1);
  if (left > 2) pages.push('ellipsis');
  for (let p = left; p <= right; p++) pages.push(p);
  if (right < total - 1) pages.push('ellipsis');
  if (total > 1) pages.push(total);

  return pages;
}

export default function Pagination({
  currentPage,
  totalPages,
  basePath,
  extraParams,
}: {
  currentPage: number;
  totalPages: number;
  basePath: string;
  extraParams?: Record<string, string | undefined>;
}) {
  if (totalPages <= 1) return null;

  function hrefFor(page: number) {
    const params = new URLSearchParams();
    if (extraParams) {
      for (const [key, value] of Object.entries(extraParams)) {
        if (value) params.set(key, value);
      }
    }
    if (page > 1) params.set('page', String(page));
    const qs = params.toString();
    return qs ? `${basePath}?${qs}` : basePath;
  }

  const pages = buildPageList(currentPage, totalPages);

  return (
    <nav className="flex items-center justify-center gap-1 py-8 text-sm">
      <Link
        href={hrefFor(Math.max(1, currentPage - 1))}
        aria-disabled={currentPage === 1}
        aria-label="上一页"
        className={`flex h-11 min-w-[2.75rem] items-center justify-center rounded ${currentPage === 1 ? 'pointer-events-none text-[var(--fg-20)]' : 'text-[var(--fg-70)] hover:bg-[var(--fg-5)] hover:text-[var(--text-color)]'}`}
      >
        ‹
      </Link>

      {pages.map((p, i) =>
        p === 'ellipsis' ? (
          <span key={`e${i}`} className="flex h-11 items-center px-1 text-[var(--fg-30)]">
            …
          </span>
        ) : (
          <Link
            key={p}
            href={hrefFor(p)}
            style={p === currentPage ? { backgroundColor: 'var(--accent-color)' } : undefined}
            className={`flex h-11 min-w-[2.75rem] items-center justify-center rounded text-center ${
              p === currentPage
                ? 'text-[var(--accent-contrast)]'
                : 'text-[var(--fg-70)] hover:bg-[var(--fg-5)] hover:text-[var(--text-color)]'
            }`}
          >
            {p}
          </Link>
        )
      )}

      <Link
        href={hrefFor(Math.min(totalPages, currentPage + 1))}
        aria-disabled={currentPage === totalPages}
        aria-label="下一页"
        className={`flex h-11 min-w-[2.75rem] items-center justify-center rounded ${currentPage === totalPages ? 'pointer-events-none text-[var(--fg-20)]' : 'text-[var(--fg-70)] hover:bg-[var(--fg-5)] hover:text-[var(--text-color)]'}`}
      >
        ›
      </Link>
    </nav>
  );
}
