'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import type { NavLinkItem } from '@/lib/navlinks';

function isInternal(url: string) {
  return url.startsWith('/');
}

export default function SiteNav({ links }: { links: NavLinkItem[] }) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;

    function handleClickOutside(e: MouseEvent) {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    function handleEscape(e: KeyboardEvent) {
      if (e.key === 'Escape') setOpen(false);
    }
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [open]);

  if (links.length === 0) return null;

  return (
    <div ref={rootRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-label={open ? '关闭菜单' : '打开菜单'}
        className="flex items-center gap-1.5 rounded-md px-2 py-1.5 text-sm text-[var(--fg-70)] transition hover:bg-[var(--fg-5)] hover:text-[var(--text-color)]"
      >
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
          {open ? (
            <path d="M4 4L14 14M14 4L4 14" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          ) : (
            <>
              <line x1="2.5" y1="5" x2="15.5" y2="5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
              <line x1="2.5" y1="9" x2="15.5" y2="9" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
              <line x1="2.5" y1="13" x2="15.5" y2="13" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
            </>
          )}
        </svg>
        菜单
      </button>

      {open && (
        <nav
          className="absolute right-0 top-full z-20 mt-2 max-h-[70vh] min-w-[10rem] overflow-y-auto overflow-x-hidden rounded-lg border border-[var(--fg-10)] bg-[var(--bg-color)] py-1 shadow-lg"
        >
          {links.map((link) =>
            isInternal(link.url) ? (
              <Link
                key={link.id}
                href={link.url}
                target={link.newTab ? '_blank' : undefined}
                rel={link.newTab ? 'noopener noreferrer' : undefined}
                onClick={() => setOpen(false)}
                className="block px-4 py-2 text-sm text-[var(--fg-70)] hover:bg-[var(--fg-5)] hover:text-[var(--text-color)]"
              >
                {link.label}
              </Link>
            ) : (
              <a
                key={link.id}
                href={link.url}
                target={link.newTab ? '_blank' : undefined}
                rel={link.newTab ? 'noopener noreferrer' : undefined}
                onClick={() => setOpen(false)}
                className="block px-4 py-2 text-sm text-[var(--fg-70)] hover:bg-[var(--fg-5)] hover:text-[var(--text-color)]"
              >
                {link.label}
              </a>
            )
          )}
        </nav>
      )}
    </div>
  );
}
