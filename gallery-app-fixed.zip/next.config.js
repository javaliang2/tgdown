/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        // 替换成你的 R2 公开访问域名（自定义域名或 R2.dev 域名）
        hostname: process.env.R2_PUBLIC_HOSTNAME || 'example.r2.dev',
      },
    ],
  },
};

module.exports = nextConfig;
