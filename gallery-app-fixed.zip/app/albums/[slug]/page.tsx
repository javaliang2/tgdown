import { cache } from 'react';
import { prisma } from '@/lib/db';
import { publicUrl } from '@/lib/r2';
import Image from 'next/image';
import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { getSiteSettings } from '@/lib/settings';
import { siteUrl } from '@/lib/site-url';

export const revalidate = 3600;

// 注意：这里故意不写 generateStaticParams。
// 如果加上它，`next build` 会在构建镜像的阶段就去查数据库拿所有图集 slug，
// 但 docker build 阶段 Postgres 服务通常还没起来（build 和 up 是两个独立阶段），
// 构建环境也不一定连得上数据库，容易导致镜像构建失败。
// 不写这个函数，页面照样是 ISR：第一次访问时按需生成 + 缓存，之后跟静态页一样快。

const getAlbum = cache(async (slug: string) => {
  return prisma.album.findUnique({
    where: { slug, status: 'PUBLISHED' },
    include: {
      photos: { orderBy: { sortOrder: 'asc' } },
      category: { select: { name: true, slug: true, parent: { select: { name: true, slug: true } } } },
    },
  });
});

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const album = await getAlbum(slug);
  if (!album) return {};

  const settings = await getSiteSettings();
  const title = `${album.title} - ${settings.siteTitle}`;
  const description = album.description || settings.siteDescription;
  const cover = album.coverKey || album.photos[0]?.r2Key;
  const url = `${siteUrl()}/albums/${album.slug}`;

  return {
    title,
    description,
    alternates: { canonical: url },
    openGraph: {
      title,
      description,
      url,
      type: 'article',
      images: cover ? [{ url: publicUrl(cover) }] : undefined,
    },
    twitter: {
      card: cover ? 'summary_large_image' : 'summary',
      title,
      description,
      images: cover ? [publicUrl(cover)] : undefined,
    },
  };
}

export default async function AlbumPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const album = await getAlbum(slug);

  if (!album) notFound();

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      {album.category && (
        <div className="flex items-center gap-1 text-xs uppercase tracking-wide text-[var(--fg-50)]">
          {album.category.parent && (
            <>
              <a href={`/?category=${album.category.parent.slug}`} className="hover:text-[var(--text-color)]">
                {album.category.parent.name}
              </a>
              <span>/</span>
            </>
          )}
          <a href={`/?category=${album.category.slug}`} className="hover:text-[var(--text-color)]">
            {album.category.name}
          </a>
        </div>
      )}
      <h1 className="mt-1 text-2xl font-medium">{album.title}</h1>
      {album.description && <p className="mt-2 text-[var(--fg-60)]">{album.description}</p>}
      {album.tags.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-2">
          {album.tags.map((tag) => (
            <span key={tag} className="rounded-full bg-[var(--fg-10)] px-3 py-1 text-xs">
              {tag}
            </span>
          ))}
        </div>
      )}

      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
        {album.photos.map((photo, index) => (
          <div key={photo.id} className="relative overflow-hidden bg-[var(--fg-5)]">
            <Image
              src={publicUrl(photo.r2Key)}
              alt={photo.altText || album.title}
              width={photo.width}
              height={photo.height}
              sizes="(max-width: 768px) 100vw, 50vw"
              className="w-full"
              priority={index === 0}
              loading={index === 0 ? undefined : 'lazy'}
            />
          </div>
        ))}
      </div>

      {/* 浏览量埋点：客户端上报，不影响静态页缓存 */}
      <ViewTracker slug={album.slug} />
    </div>
  );
}

function ViewTracker({ slug }: { slug: string }) {
  return (
    <script
      dangerouslySetInnerHTML={{
        __html: `fetch('/api/albums/${slug}/view', { method: 'POST' }).catch(() => {});`,
      }}
    />
  );
}
