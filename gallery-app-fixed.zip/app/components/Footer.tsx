export default function Footer({
  siteTitle,
  icpNumber,
  contactInfo,
}: {
  siteTitle: string;
  icpNumber: string;
  contactInfo: string;
}) {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-[var(--fg-10)] px-6 py-6 text-center text-xs text-[var(--fg-50)]">
      <p>
        © {year} {siteTitle}
      </p>
      {(icpNumber || contactInfo) && (
        <p className="mt-1 flex flex-wrap items-center justify-center gap-x-3 gap-y-1">
          {icpNumber && (
            <a
              href="https://beian.miit.gov.cn/"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[var(--fg-70)]"
            >
              {icpNumber}
            </a>
          )}
          {contactInfo && <span>{contactInfo}</span>}
        </p>
      )}
    </footer>
  );
}
