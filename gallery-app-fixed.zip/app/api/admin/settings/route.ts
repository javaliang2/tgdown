import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { revalidatePath } from 'next/cache';

export async function GET() {
  const settings = await prisma.siteSetting.findUnique({ where: { id: 1 } });
  return NextResponse.json(settings);
}

export async function PATCH(req: NextRequest) {
  const body = await req.json();
  const { siteTitle, siteDescription, backgroundColor, textColor, accentColor, icpNumber, contactInfo, aboutContent } =
    body;

  const settings = await prisma.siteSetting.upsert({
    where: { id: 1 },
    update: { siteTitle, siteDescription, backgroundColor, textColor, accentColor, icpNumber, contactInfo, aboutContent },
    create: { id: 1, siteTitle, siteDescription, backgroundColor, textColor, accentColor, icpNumber, contactInfo, aboutContent },
  });

  // layout 是所有页面共用的，type: 'layout' 会让所有路由的布局缓存一起失效，改完立即生效
  revalidatePath('/', 'layout');

  return NextResponse.json(settings);
}
