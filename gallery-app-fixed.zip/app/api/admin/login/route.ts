import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/db';
import { createSession } from '@/lib/auth';

const MAX_ATTEMPTS = 5;
const LOCK_MINUTES = 15;

export async function POST(req: NextRequest) {
  const { email, password } = await req.json();

  if (!email || !password) {
    return NextResponse.json({ error: '请输入邮箱和密码' }, { status: 400 });
  }

  const user = await prisma.adminUser.findUnique({ where: { email } });

  // 邮箱不存在时也返回统一的错误文案，不透露账号是否存在
  if (!user) {
    return NextResponse.json({ error: '邮箱或密码错误' }, { status: 401 });
  }

  // 账号被锁定期间，直接拒绝，不再尝试校验密码
  if (user.lockedUntil && user.lockedUntil > new Date()) {
    const remainingMin = Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60000);
    return NextResponse.json(
      { error: `登录失败次数过多，账号已锁定，请 ${remainingMin} 分钟后再试` },
      { status: 429 }
    );
  }

  const valid = await bcrypt.compare(password, user.passwordHash);

  if (!valid) {
    const failedAttempts = user.failedAttempts + 1;
    const shouldLock = failedAttempts >= MAX_ATTEMPTS;

    await prisma.adminUser.update({
      where: { id: user.id },
      data: {
        failedAttempts: shouldLock ? 0 : failedAttempts,
        lockedUntil: shouldLock ? new Date(Date.now() + LOCK_MINUTES * 60_000) : null,
      },
    });

    if (shouldLock) {
      return NextResponse.json(
        { error: `连续输错 ${MAX_ATTEMPTS} 次，账号已锁定 ${LOCK_MINUTES} 分钟` },
        { status: 429 }
      );
    }

    return NextResponse.json(
      { error: `邮箱或密码错误（还可以尝试 ${MAX_ATTEMPTS - failedAttempts} 次）` },
      { status: 401 }
    );
  }

  // 登录成功，清空失败记录
  if (user.failedAttempts > 0 || user.lockedUntil) {
    await prisma.adminUser.update({
      where: { id: user.id },
      data: { failedAttempts: 0, lockedUntil: null },
    });
  }

  await createSession(user.id);
  return NextResponse.json({ ok: true });
}
