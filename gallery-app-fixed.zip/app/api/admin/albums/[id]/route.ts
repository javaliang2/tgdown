import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { deleteObject } from '@/lib/r2';
import { revalidatePath } from 'next/cache';

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const album = await prisma.album.findUnique({
    where: { id },
    include: { photos: true },
  });
  if (!album) {
    return NextResponse.json({ error: '图集不存在' }, { status: 404 });
  }

  // 先删 R2 上的文件，再删数据库记录（级联删除 photos）
  await Promise.all(
    album.photos.flatMap((p) => [deleteObject(p.r2Key), deleteObject(p.thumbKey)])
  );
  await prisma.album.delete({ where: { id } });

  revalidatePath('/');
  revalidatePath(`/albums/${album.slug}`);

  return NextResponse.json({ ok: true });
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json();
  const album = await prisma.album.update({
    where: { id },
    data: {
      title: body.title,
      description: body.description,
      tags: body.tags,
      status: body.status,
      categoryId: body.categoryId ?? undefined,
      coverKey: body.coverKey ?? undefined,
    },
  });

  revalidatePath('/');
  revalidatePath(`/albums/${album.slug}`);

  return NextResponse.json(album);
}
