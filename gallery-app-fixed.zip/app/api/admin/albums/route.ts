import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import slugify from 'slugify';

// GET: 后台图集列表（含草稿）
export async function GET() {
  const albums = await prisma.album.findMany({
    orderBy: { createdAt: 'desc' },
    include: { _count: { select: { photos: true } } },
  });
  return NextResponse.json(albums);
}

// POST: 创建图集
// body: { title, description, tags: string[], categoryId?: string, coverIndex?: number, photos: [{ r2Key, thumbKey, width, height, altText }] }
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { title, description, tags = [], categoryId, coverIndex = 0, photos = [] } = body;

  if (!title || photos.length === 0) {
    return NextResponse.json({ error: '标题和至少一张图片是必须的' }, { status: 400 });
  }

  const baseSlug = slugify(title, { lower: true, strict: true });
  let slug = baseSlug;
  let counter = 1;
  while (await prisma.album.findUnique({ where: { slug } })) {
    slug = `${baseSlug}-${counter++}`;
  }

  const cover = photos[coverIndex] || photos[0];

  const album = await prisma.album.create({
    data: {
      title,
      slug,
      description,
      tags,
      categoryId: categoryId || null,
      coverKey: cover?.thumbKey,
      status: 'PUBLISHED',
      publishedAt: new Date(),
      photos: {
        create: photos.map((p: any, i: number) => ({
          r2Key: p.r2Key,
          thumbKey: p.thumbKey,
          width: p.width,
          height: p.height,
          altText: p.altText || '',
          sortOrder: i,
        })),
      },
    },
  });

  // 重新生成首页和图集详情页的静态缓存
  revalidatePath('/');
  revalidatePath(`/albums/${slug}`);

  return NextResponse.json(album, { status: 201 });
}
