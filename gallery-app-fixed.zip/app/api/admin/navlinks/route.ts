import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { revalidatePath } from 'next/cache';

export async function GET() {
  const links = await prisma.navLink.findMany({ orderBy: { sortOrder: 'asc' } });
  return NextResponse.json(links);
}

export async function POST(req: NextRequest) {
  const { label, url, categoryId, newTab, sortOrder } = await req.json();
  if (!label) {
    return NextResponse.json({ error: '请填写菜单文字' }, { status: 400 });
  }
  if (!categoryId && !url) {
    return NextResponse.json({ error: '关联分类和自定义链接至少要选一个' }, { status: 400 });
  }

  const link = await prisma.navLink.create({
    data: {
      label,
      url: categoryId ? null : url, // 关联了分类的话，实际链接由 categoryId 现算，url 就不存了
      categoryId: categoryId || null,
      newTab: Boolean(newTab),
      sortOrder: Number.isFinite(sortOrder) ? sortOrder : 0,
    },
  });

  // 导航菜单是根 layout 的一部分，跟站点设置一样要让所有页面的布局缓存失效
  revalidatePath('/', 'layout');
  return NextResponse.json(link, { status: 201 });
}
