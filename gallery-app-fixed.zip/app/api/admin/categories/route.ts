import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import slugify from 'slugify';
import { revalidatePath } from 'next/cache';

export async function GET() {
  const categories = await prisma.category.findMany({
    orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
    include: { _count: { select: { albums: true } }, parent: { select: { name: true } } },
  });
  return NextResponse.json(categories);
}

export async function POST(req: NextRequest) {
  const { name, parentId } = await req.json();
  if (!name) {
    return NextResponse.json({ error: '请输入分类名称' }, { status: 400 });
  }

  const baseSlug = slugify(name, { lower: true, strict: true });
  let slug = baseSlug;
  let counter = 1;
  while (await prisma.category.findUnique({ where: { slug } })) {
    slug = `${baseSlug}-${counter++}`;
  }

  const category = await prisma.category.create({ data: { name, slug, parentId: parentId || null } });
  revalidatePath('/');
  return NextResponse.json(category, { status: 201 });
}
