import { NextRequest, NextResponse } from 'next/server';
import { createUploadUrl } from '@/lib/r2';
import { randomUUID } from 'crypto';

// 请求体: { filename: string, contentType: string, kind: 'original' | 'thumb' }
export async function POST(req: NextRequest) {
  const { filename, contentType, kind } = await req.json();

  if (!filename || !contentType) {
    return NextResponse.json({ error: '缺少 filename 或 contentType' }, { status: 400 });
  }

  const ext = filename.split('.').pop() || 'jpg';
  const prefix = kind === 'thumb' ? 'thumbs' : 'photos';
  const key = `${prefix}/${new Date().getFullYear()}/${randomUUID()}.${ext}`;

  const uploadUrl = await createUploadUrl(key, contentType);

  return NextResponse.json({ uploadUrl, key });
}
