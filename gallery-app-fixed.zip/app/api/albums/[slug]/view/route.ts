import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

// 简单直接写库，量级不大完全够用；量大了再考虑 Redis 累加 + 定时同步

const VIEWED_COOKIE = 'viewed_albums';
const VIEWED_COOKIE_MAX_AGE = 60 * 60 * 24; // 24 小时内同一浏览器对同一图集只计一次
const RATE_LIMIT_WINDOW_MS = 60 * 1000; // 每个 IP 每分钟最多这么多次上报（跨所有图集）
const RATE_LIMIT_MAX = 20;

// 注意：这是单实例进程内的内存计数器，够用来挡住简单的刷量脚本；
// 如果以后 web 服务横向扩容成多实例，这里要换成 Redis 之类的共享存储。
const ipHits = new Map<string, { count: number; resetAt: number }>();

function isRateLimited(ip: string): boolean {
  const now = Date.now();
  const entry = ipHits.get(ip);
  if (!entry || now > entry.resetAt) {
    ipHits.set(ip, { count: 1, resetAt: now + RATE_LIMIT_WINDOW_MS });
    return false;
  }
  entry.count += 1;
  return entry.count > RATE_LIMIT_MAX;
}

function getClientIp(req: NextRequest): string {
  return req.headers.get('x-real-ip') || req.headers.get('x-forwarded-for')?.split(',')[0].trim() || 'unknown';
}

function parseViewedSlugs(raw: string | undefined): Set<string> {
  if (!raw) return new Set();
  try {
    const arr = JSON.parse(raw);
    return new Set(Array.isArray(arr) ? arr : []);
  } catch {
    return new Set();
  }
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;

  const ip = getClientIp(req);
  if (isRateLimited(ip)) {
    return NextResponse.json({ ok: false, reason: 'rate_limited' }, { status: 429 });
  }

  const viewedSlugs = parseViewedSlugs(req.cookies.get(VIEWED_COOKIE)?.value);
  if (viewedSlugs.has(slug)) {
    // 24 小时内已经计过一次了，直接返回成功但不再 +1
    return NextResponse.json({ ok: true, counted: false });
  }

  try {
    await prisma.album.update({
      where: { slug },
      data: { viewCount: { increment: 1 } },
    });

    viewedSlugs.add(slug);
    const res = NextResponse.json({ ok: true, counted: true });
    res.cookies.set(VIEWED_COOKIE, JSON.stringify([...viewedSlugs]), {
      httpOnly: true,
      sameSite: 'lax',
      path: '/',
      maxAge: VIEWED_COOKIE_MAX_AGE,
    });
    return res;
  } catch {
    return NextResponse.json({ ok: false }, { status: 404 });
  }
}
