import type { Metadata } from 'next';
import './globals.css';
import { getSiteSettings } from '@/lib/settings';
import { getContrastTextColor } from '@/lib/color';
import { getNavLinks } from '@/lib/navlinks';
import SiteNav from './components/SiteNav';
import Footer from './components/Footer';
import { siteUrl } from '@/lib/site-url';

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getSiteSettings();
  return {
    metadataBase: new URL(siteUrl()),
    title: {
      default: settings.siteTitle,
      template: `%s`,
    },
    description: settings.siteDescription,
  };
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const [settings, navLinks] = await Promise.all([getSiteSettings(), getNavLinks()]);

  return (
    <html
      lang="zh-CN"
      style={
        {
          '--bg-color': settings.backgroundColor,
          '--text-color': settings.textColor,
          '--accent-color': settings.accentColor,
          '--accent-contrast': getContrastTextColor(settings.accentColor),
        } as React.CSSProperties
      }
    >
      <body>
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--fg-10)] px-6 py-4">
          <a href="/" className="text-lg tracking-wide">{settings.siteTitle}</a>
          <SiteNav links={navLinks} />
        </header>
        <main className="min-h-screen">{children}</main>
        <Footer siteTitle={settings.siteTitle} icpNumber={settings.icpNumber} contactInfo={settings.contactInfo} />
      </body>
    </html>
  );
}
