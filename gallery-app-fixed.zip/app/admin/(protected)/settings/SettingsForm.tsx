'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import type { SiteSettings } from '@/lib/settings';
import { getContrastTextColor } from '@/lib/color';

function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div>
      <label className="mb-1 block text-sm text-[var(--fg-70)]">{label}</label>
      <div className="flex items-center gap-2">
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-9 w-12 cursor-pointer rounded border border-[var(--fg-20)] bg-transparent p-0.5"
        />
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 rounded border border-[var(--fg-20)] bg-transparent px-3 py-2 text-sm"
        />
      </div>
    </div>
  );
}

export default function SettingsForm({ initial }: { initial: SiteSettings }) {
  const router = useRouter();
  const [form, setForm] = useState(initial);
  const [submitting, setSubmitting] = useState(false);
  const [saved, setSaved] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setSaved(false);
    const res = await fetch('/api/admin/settings', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    setSubmitting(false);
    if (res.ok) {
      setSaved(true);
      router.refresh();
    } else {
      alert('保存失败');
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div>
        <label className="mb-1 block text-sm text-[var(--fg-70)]">网站标题</label>
        <input
          value={form.siteTitle}
          onChange={(e) => setForm({ ...form, siteTitle: e.target.value })}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        />
      </div>

      <div>
        <label className="mb-1 block text-sm text-[var(--fg-70)]">网站描述（用于 SEO）</label>
        <textarea
          value={form.siteDescription}
          onChange={(e) => setForm({ ...form, siteDescription: e.target.value })}
          rows={2}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        />
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <ColorField
          label="背景色"
          value={form.backgroundColor}
          onChange={(v) => setForm({ ...form, backgroundColor: v })}
        />
        <ColorField
          label="文字颜色"
          value={form.textColor}
          onChange={(v) => setForm({ ...form, textColor: v })}
        />
        <ColorField
          label="强调色（按钮/高亮）"
          value={form.accentColor}
          onChange={(v) => setForm({ ...form, accentColor: v })}
        />
      </div>

      {/* 实时预览 */}
      <div
        className="rounded border border-[var(--fg-10)] p-4"
        style={{ backgroundColor: form.backgroundColor, color: form.textColor }}
      >
        <p className="text-sm">预览：{form.siteTitle}</p>
        <button
          type="button"
          style={{ backgroundColor: form.accentColor, color: getContrastTextColor(form.accentColor) }}
          className="mt-2 rounded px-3 py-1 text-sm"
        >
          示例按钮
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-sm text-[var(--fg-70)]">备案号（留空则页脚不显示）</label>
          <input
            placeholder="例如：京ICP备xxxxxxxx号"
            value={form.icpNumber}
            onChange={(e) => setForm({ ...form, icpNumber: e.target.value })}
            className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          />
        </div>
        <div>
          <label className="mb-1 block text-sm text-[var(--fg-70)]">联系方式（留空则页脚不显示）</label>
          <input
            placeholder="例如：邮箱或微信号"
            value={form.contactInfo}
            onChange={(e) => setForm({ ...form, contactInfo: e.target.value })}
            className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          />
        </div>
      </div>

      <div>
        <label className="mb-1 block text-sm text-[var(--fg-70)]">
          关于页内容（显示在 /about，每行一段）
        </label>
        <textarea
          value={form.aboutContent}
          onChange={(e) => setForm({ ...form, aboutContent: e.target.value })}
          rows={4}
          placeholder="留空的话，关于页会显示「站长还没有填写关于页内容」"
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        />
      </div>

      <div className="flex items-center gap-3">
        <button
          type="submit"
          disabled={submitting}
          style={{ backgroundColor: 'var(--accent-color)' }}
          className="rounded px-4 py-2 text-[var(--accent-contrast)] disabled:opacity-50"
        >
          {submitting ? '保存中…' : '保存'}
        </button>
        {saved && <span className="text-sm text-green-400">已保存，前台立即生效</span>}
      </div>
    </form>
  );
}
