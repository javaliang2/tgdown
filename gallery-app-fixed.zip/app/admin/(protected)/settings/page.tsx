import SettingsForm from './SettingsForm';
import { getSiteSettings } from '@/lib/settings';

export const dynamic = 'force-dynamic';

export default async function SettingsPage() {
  const settings = await getSiteSettings();

  return (
    <div className="mx-auto max-w-xl px-4 py-8">
      <h1 className="mb-6 text-xl">网站外观设置</h1>
      <SettingsForm initial={settings} />
    </div>
  );
}
