'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

type Category = { id: string; name: string; slug: string; parentId: string | null };

type PendingPhoto = {
  file: File;
  r2Key?: string;
  thumbKey?: string;
  width: number;
  height: number;
};

// 在浏览器端用 canvas 生成一张缩略图，避免额外起一个图片处理服务
async function makeThumbnail(file: File, maxSize = 600): Promise<{ blob: Blob; width: number; height: number }> {
  const img = await createImageBitmap(file);
  const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
  const w = Math.round(img.width * scale);
  const h = Math.round(img.height * scale);
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  ctx.drawImage(img, 0, 0, w, h);
  const blob: Blob = await new Promise((resolve) =>
    canvas.toBlob((b) => resolve(b!), 'image/webp', 0.85)
  );
  return { blob, width: img.width, height: img.height };
}

async function uploadToR2(file: Blob, filename: string, contentType: string, kind: 'original' | 'thumb') {
  const res = await fetch('/api/admin/upload-url', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ filename, contentType, kind }),
  });
  const { uploadUrl, key } = await res.json();
  await fetch(uploadUrl, { method: 'PUT', headers: { 'Content-Type': contentType }, body: file });
  return key as string;
}

export default function NewAlbumPage() {
  const router = useRouter();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [tags, setTags] = useState('');
  const [categories, setCategories] = useState<Category[]>([]);
  const [parentCategoryId, setParentCategoryId] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [coverIndex, setCoverIndex] = useState(0);
  const [progress, setProgress] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetch('/api/admin/categories')
      .then((r) => r.json())
      .then(setCategories)
      .catch(() => {});
  }, []);

  function handleFilesChange(fileList: FileList | null) {
    const list = Array.from(fileList || []);
    setFiles(list);
    setCoverIndex(0);
    previews.forEach((url) => URL.revokeObjectURL(url));
    setPreviews(list.map((f) => URL.createObjectURL(f)));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (files.length === 0) return;
    setSubmitting(true);

    const photos = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      setProgress(`正在上传第 ${i + 1} / ${files.length} 张…`);

      const { blob: thumbBlob, width, height } = await makeThumbnail(file);
      const [r2Key, thumbKey] = await Promise.all([
        uploadToR2(file, file.name, file.type, 'original'),
        uploadToR2(thumbBlob, file.name.replace(/\.\w+$/, '.webp'), 'image/webp', 'thumb'),
      ]);

      photos.push({ r2Key, thumbKey, width, height, altText: title });
    }

    setProgress('正在保存图集…');
    const res = await fetch('/api/admin/albums', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title,
        description,
        tags: tags.split(',').map((t) => t.trim()).filter(Boolean),
        categoryId: categoryId || parentCategoryId || null,
        coverIndex,
        photos,
      }),
    });

    setSubmitting(false);
    if (res.ok) {
      router.push('/admin');
      router.refresh();
    } else {
      const data = await res.json();
      setProgress('');
      alert(data.error || '保存失败');
    }
  }

  return (
    <div className="mx-auto max-w-xl px-4 py-8">
      <h1 className="mb-6 text-xl">新建图集</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          placeholder="标题"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        />
        <textarea
          placeholder="描述（可选）"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          rows={3}
        />
        <input
          placeholder="标签，用逗号分隔"
          value={tags}
          onChange={(e) => setTags(e.target.value)}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        />
        <div className="flex flex-col gap-2 sm:flex-row">
          <select
            value={parentCategoryId}
            onChange={(e) => {
              setParentCategoryId(e.target.value);
              setCategoryId(''); // 换大类后清空已选的子分类
            }}
            className="flex-1 rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          >
            <option value="" className="bg-black">选择大类</option>
            {categories
              .filter((c) => !c.parentId)
              .map((c) => (
                <option key={c.id} value={c.id} className="bg-black">
                  {c.name}
                </option>
              ))}
          </select>
          <select
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value)}
            disabled={!parentCategoryId}
            className="flex-1 rounded border border-[var(--fg-20)] bg-transparent px-3 py-2 disabled:opacity-40"
          >
            <option value="" className="bg-black">
              {parentCategoryId ? '不选子分类（直接挂在大类下）' : '先选大类'}
            </option>
            {categories
              .filter((c) => c.parentId === parentCategoryId)
              .map((c) => (
                <option key={c.id} value={c.id} className="bg-black">
                  {c.name}
                </option>
              ))}
          </select>
        </div>
        <input
          type="file"
          accept="image/*"
          multiple
          onChange={(e) => handleFilesChange(e.target.files)}
          className="w-full text-sm"
        />

        {previews.length > 0 && (
          <div>
            <p className="mb-2 text-xs text-[var(--fg-50)]">点击图片设为封面（当前：第 {coverIndex + 1} 张）</p>
            <div className="grid grid-cols-4 gap-2">
              {previews.map((src, i) => (
                <button
                  type="button"
                  key={src}
                  onClick={() => setCoverIndex(i)}
                  style={i === coverIndex ? { boxShadow: '0 0 0 2px var(--accent-color)' } : undefined}
                  className={`relative aspect-square overflow-hidden rounded ${
                    i === coverIndex ? '' : 'opacity-70'
                  }`}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={src} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          </div>
        )}

        <button
          type="submit"
          disabled={submitting || !title || files.length === 0}
          style={{ backgroundColor: 'var(--accent-color)' }}
          className="w-full rounded py-2 text-[var(--accent-contrast)] disabled:opacity-50"
        >
          {submitting ? progress || '提交中…' : `发布（${files.length} 张图片）`}
        </button>
      </form>
    </div>
  );
}
