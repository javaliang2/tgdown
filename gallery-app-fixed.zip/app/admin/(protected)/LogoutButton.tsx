'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

export default function LogoutButton() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function handleLogout() {
    setLoading(true);
    await fetch('/api/admin/logout', { method: 'POST' });
    router.push('/admin/login');
    router.refresh();
  }

  return (
    <button
      onClick={handleLogout}
      disabled={loading}
      className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)] disabled:opacity-50"
    >
      {loading ? '退出中…' : '退出登录'}
    </button>
  );
}
