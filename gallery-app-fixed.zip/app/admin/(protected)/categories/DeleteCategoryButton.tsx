'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

export default function DeleteCategoryButton({ id }: { id: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function handleDelete() {
    if (!confirm('确定删除这个分类吗？该分类下的图集会变成未分类；如果这是一个有子分类的顶级分类，子分类会自动升级为顶级分类。')) return;
    setLoading(true);
    await fetch(`/api/admin/categories/${id}`, { method: 'DELETE' });
    setLoading(false);
    router.refresh();
  }

  return (
    <button
      onClick={handleDelete}
      disabled={loading}
      className="text-red-400 hover:text-red-300 disabled:opacity-50"
    >
      {loading ? '删除中…' : '删除'}
    </button>
  );
}
