import type { MetadataRoute } from 'next';
import { prisma } from '@/lib/db';
import { siteUrl } from '@/lib/site-url';

export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = siteUrl();

  const albums = await prisma.album.findMany({
    where: { status: 'PUBLISHED' },
    select: { slug: true, updatedAt: true },
    orderBy: { publishedAt: 'desc' },
  });

  const albumEntries: MetadataRoute.Sitemap = albums.map((album) => ({
    url: `${base}/albums/${album.slug}`,
    lastModified: album.updatedAt,
    changeFrequency: 'weekly',
    priority: 0.8,
  }));

  return [
    {
      url: base,
      changeFrequency: 'daily',
      priority: 1,
    },
    {
      url: `${base}/about`,
      changeFrequency: 'monthly',
      priority: 0.3,
    },
    ...albumEntries,
  ];
}
