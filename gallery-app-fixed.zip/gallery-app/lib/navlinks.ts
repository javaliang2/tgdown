import { prisma } from '@/lib/db';
import { redis } from '@/lib/redis';

export type NavLinkItem = {
  id: string;
  label: string;
  url: string;
  newTab: boolean;
};

// 跟写入端（app/api/monkey/navlinks/route.ts）保持一致的协议白名单。
// 这里再校验一遍是图个保险：万一之前有脏数据、或者以后又加了别的写入路径忘了校验，
// 前台渲染这一步兜底把危险协议换成 '#'，不会真的把 javascript:/data: 之类的链接吐给访客。
function isAllowedUrl(url: string): boolean {
  if (url.startsWith('/')) return true;
  return /^(https?:|mailto:|tel:)/i.test(url);
}

// 跟 lib/settings.ts 同一个思路：导航菜单也是根 layout 里每个页面都要查一次的数据，
// 用 Redis 缓存一份减少查库次数。后台增删导航项时会主动清缓存，不用等 TTL 过期。
const CACHE_KEY = 'gallery:navlinks';
const CACHE_TTL_SEC = 300;

async function loadNavLinks(): Promise<NavLinkItem[]> {
  try {
    const links = await prisma.navLink.findMany({
      orderBy: { sortOrder: 'asc' },
      select: {
        id: true,
        label: true,
        url: true,
        newTab: true,
        category: { select: { slug: true } },
      },
    });
    return links.map((link) => {
      const rawUrl = link.category ? `/?category=${link.category.slug}` : link.url ?? '#';
      return {
        id: link.id,
        label: link.label,
        url: isAllowedUrl(rawUrl) ? rawUrl : '#',
        newTab: link.newTab,
      };
    });
  } catch {
    // 数据库还没跑迁移，或者查询失败时兜底为空菜单，不影响页面渲染
    return [];
  }
}

export async function getNavLinks(): Promise<NavLinkItem[]> {
  if (redis) {
    try {
      const cached = await redis.get(CACHE_KEY);
      if (cached) return JSON.parse(cached) as NavLinkItem[];
    } catch (err) {
      console.error('[navlinks] redis read failed, falling back to db:', err);
    }
  }

  const links = await loadNavLinks();

  if (redis) {
    redis.set(CACHE_KEY, JSON.stringify(links), 'EX', CACHE_TTL_SEC).catch((err) => {
      console.error('[navlinks] redis write failed:', err);
    });
  }

  return links;
}

export async function invalidateNavLinksCache(): Promise<void> {
  if (!redis) return;
  try {
    await redis.del(CACHE_KEY);
  } catch (err) {
    console.error('[navlinks] redis cache invalidation failed:', err);
  }
}
