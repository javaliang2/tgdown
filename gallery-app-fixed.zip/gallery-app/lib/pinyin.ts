import { pinyin } from 'pinyin-pro';

/**
 * 把标题转成一个用来做模糊搜索的拼音字符串，写入 Album.titlePinyin。
 *
 * 存两种形式拼在一起（空格分隔），一次 ILIKE '%xxx%' 就能同时命中全拼和首字母缩写：
 *   - 全拼、去掉声调、去掉音节间空格："梅花" -> "meihua"，方便打整段拼音的人（"meihua"）
 *   - 首字母缩写："梅花" -> "mh"，方便打首字母的人（"mh"）
 * 英文/数字这些非中文字符原样保留（nonZh: 'consecutive' 让连续的非中文段落保持原样，
 * 不会被拆散成一个个字符），这样标题里混着英文单词也不会被拼音转换搞乱。
 *
 * 这一步在写入时（创建/编辑图集）算好存进数据库，不在查询时现算——查询时现算的话，
 * 每次搜索都要把全库标题现场转一遍拼音再比较，既没法用 pg_trgm 索引，量一大就是全表扫描。
 */
export function toTitlePinyin(title: string): string {
  if (!title) return '';
  const full = pinyin(title, { toneType: 'none', nonZh: 'consecutive' })
    .replace(/\s+/g, '')
    .toLowerCase();
  const initials = pinyin(title, { pattern: 'first', toneType: 'none', nonZh: 'consecutive' })
    .replace(/\s+/g, '')
    .toLowerCase();
  return initials && initials !== full ? `${full} ${initials}` : full;
}
