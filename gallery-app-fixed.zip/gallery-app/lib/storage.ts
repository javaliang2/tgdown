import { S3Client, PutObjectCommand, DeleteObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

// 任意 S3 兼容对象存储都可以接（Cloudflare R2、阿里云 OSS、腾讯云 COS、
// Backblaze B2、MinIO、AWS S3 本身等），只要支持 SigV4 签名 + 预签名 URL，
// 换存储商只需要改 .env 里的 S3_* 变量，不用改这里的代码。
export const s3 = new S3Client({
  region: 'auto',
  endpoint: process.env.S3_ENDPOINT!,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY_ID!,
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY!,
  },
});

const BUCKET = process.env.S3_BUCKET!;

/**
 * 生成一个用于前端直传的预签名 URL，有效期默认 5 分钟。
 *
 * contentLength 可选：传了的话会把 Content-Length 也签进请求里，S3/R2 会要求
 * 实际 PUT 请求的 Content-Length 跟这个值完全一致，不一致直接拒绝。
 * 用途是防止"报小传大"——调用方（app/api/monkey/upload-url/route.ts）会先校验
 * 客户端声明的文件大小不超过上限，再把这个大小签进 URL 里；单纯不传 contentLength
 * 只能挡"声明超过上限"这一种情况，签进去之后连"先报一个很小的值骗过校验、
 * 实际传一个大文件"这种绕过方式也一并挡掉，因为 URL 本身就锁死了大小。
 */
export async function createUploadUrl(
  key: string,
  contentType: string,
  expiresIn = 300,
  contentLength?: number,
) {
  const command = new PutObjectCommand({
    Bucket: BUCKET,
    Key: key,
    ContentType: contentType,
    ...(typeof contentLength === 'number' ? { ContentLength: contentLength } : {}),
  });
  return getSignedUrl(s3, command, { expiresIn });
}

export async function deleteObject(key: string) {
  await s3.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: key }));
}

/** 拼出公开访问 URL（需要在存储桶开启公开访问，或绑定自定义域名 / CDN） */
export function publicUrl(key: string) {
  const base = process.env.S3_PUBLIC_URL!; // 例如 https://images.yourdomain.com
  return `${base.replace(/\/$/, '')}/${key}`;
}

/**
 * 私密相册专用：生成一个带签名、限时有效的原图访问 URL，默认 30 分钟。
 *
 * 跟 publicUrl() 的区别：publicUrl() 拼出的是长期有效的公开地址，只要 URL 泄露
 * 出去（分享链接、浏览器历史、代理日志……）任何人都能一直访问，跟"私密"这个
 * 定位是矛盾的——哪怕页面本身做了登录态校验，图片地址一旦被拿到就绕过了那层校验。
 * 这个函数走 S3 GetObject 预签名，URL 里带时效和签名校验，过期后存储端会直接拒绝，
 * 不依赖也不信任应用层是否还记得要不要给这张图鉴权。
 *
 * 30 分钟是权衡后的默认值：足够看完一个相册（包括中途切换 tab 回来），
 * 又不会长到跟公开链接没区别。真要更短/更长可以传 expiresIn 覆盖。
 */
export async function createPrivatePhotoUrl(key: string, expiresIn = 1800) {
  const command = new GetObjectCommand({ Bucket: BUCKET, Key: key });
  return getSignedUrl(s3, command, { expiresIn });
}
