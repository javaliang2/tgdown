import type { NextRequest } from 'next/server';

// 部署在 WireGuard 内网、由 Caddy/Nginx 反代到本机端口，反代通常会设 x-real-ip；
// 没有的话退回 x-forwarded-for 的第一段（离用户最近的那一跳）。都拿不到就归为 'unknown'，
// 限流时 'unknown' 会被当成同一个桶处理，不影响真实 IP 的限流额度。
//
// x-real-ip / x-forwarded-for 本质是普通请求头，只要请求能直接打到这个进程（没有反代
// 挡在前面把这两个头覆盖成可信的值），就可以被随便伪造——伪造成不同的 IP，登录失败锁定、
// IP 限流、扫描器限流全都可以被绕过。只要部署确实按文档走 Caddy/Nginx 反代到内网端口、
// 应用本身不直接暴露公网，这两个头就是可信的；但这个前提完全靠运维配置保证，代码本身
// 没法验证。
//
// 配置了 PROXY_TRUST_SECRET 之后会多一层校验：只有同时带着这个密钥的请求才会被采信，
// 密钥只有反代自己知道（在 nginx/Caddy 配置里加一行 proxy_set_header 设置，并且要确保
// 反代会覆盖掉、而不是透传客户端自己带来的同名头，不然等于形同虚设）。没配置的话保持
// 原来的行为（不校验，直接信任这两个头），只在第一次调用时打一条警告日志，提醒尽快配置。
const proxyTrustSecret = process.env.PROXY_TRUST_SECRET;
let warnedAboutMissingSecret = false;

export function getClientIp(req: NextRequest): string {
  if (proxyTrustSecret) {
    if (req.headers.get('x-proxy-trust-secret') !== proxyTrustSecret) {
      // 密钥核对不上：要么是反代没配对，要么是有人绕过反代直接打到应用、还试图伪造 IP。
      // 两种情况都不该信任请求自带的 IP 头，归到 'unknown' 桶里，比信一个可能被伪造的值更安全。
      return 'unknown';
    }
  } else if (!warnedAboutMissingSecret) {
    warnedAboutMissingSecret = true;
    console.warn(
      '[client-ip] 未配置 PROXY_TRUST_SECRET：x-real-ip/x-forwarded-for 会被直接信任，' +
        '如果应用可能被绕过反代直接访问，限流和账号锁定可以被伪造 IP 绕过。' +
        '建议在 .env 里配置这个变量，并让反代在转发时带上同名请求头。',
    );
  }

  return req.headers.get('x-real-ip') || req.headers.get('x-forwarded-for')?.split(',')[0].trim() || 'unknown';
}
