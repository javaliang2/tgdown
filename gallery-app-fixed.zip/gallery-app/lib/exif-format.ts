// 把 exifr 解析出来的原始 EXIF tag 转成人类可读的字符串/数字，存进 Photo 表的字段里。
// 拆成纯函数（不依赖 exifr 本身、不碰 DOM/File API）方便单测，也方便以后如果换一个
// EXIF 解析库，只要喂进来的 raw 对象字段名对得上，这层格式化逻辑不用动。

export type PhotoExif = {
  takenAt?: string; // ISO 字符串，Prisma DateTime 字段直接能吃
  cameraMake?: string;
  cameraModel?: string;
  lensModel?: string;
  focalLength?: string; // "50mm"
  aperture?: string; // "f/1.8"
  shutterSpeed?: string; // "1/250s" 或 "2s"
  iso?: number;
};

// exifr 用 `pick` 选项只解析这些 tag，picks 之外的原始类型大致长这样
type RawExifTags = {
  Make?: string;
  Model?: string;
  LensModel?: string;
  FocalLength?: number; // 单位 mm
  FNumber?: number; // 光圈值，比如 1.8
  ExposureTime?: number; // 单位秒，比如 1/250 存成 0.004
  ISO?: number;
  DateTimeOriginal?: Date;
  CreateDate?: Date;
};

function formatAperture(fNumber?: number): string | undefined {
  if (typeof fNumber !== 'number' || !Number.isFinite(fNumber) || fNumber <= 0) return undefined;
  // 光圈值本身没有约定俗成的小数位数：f/1.8、f/2.8 这种个位数小数常见，f/4、f/8 这种整数也常见，
  // 保留一位小数、末尾是 .0 就去掉，两种写法都覆盖到
  const rounded = Math.round(fNumber * 10) / 10;
  return `f/${Number.isInteger(rounded) ? rounded : rounded.toFixed(1)}`;
}

function formatShutterSpeed(exposureTime?: number): string | undefined {
  if (typeof exposureTime !== 'number' || !Number.isFinite(exposureTime) || exposureTime <= 0) return undefined;
  if (exposureTime >= 1) {
    // 长曝光：1.6s、2s 这种直接显示秒数，非整数保留一位小数
    const rounded = Math.round(exposureTime * 10) / 10;
    return `${Number.isInteger(rounded) ? rounded : rounded.toFixed(1)}s`;
  }
  // 快门速度习惯用分数表示（1/250s），不是小数（0.004s）
  return `1/${Math.round(1 / exposureTime)}s`;
}

function formatFocalLength(focalLength?: number): string | undefined {
  if (typeof focalLength !== 'number' || !Number.isFinite(focalLength) || focalLength <= 0) return undefined;
  return `${Math.round(focalLength)}mm`;
}

export function formatExifFromRaw(raw: RawExifTags | null | undefined): PhotoExif {
  if (!raw) return {};

  const takenAtDate = raw.DateTimeOriginal ?? raw.CreateDate;

  return {
    takenAt: takenAtDate instanceof Date && !isNaN(takenAtDate.getTime()) ? takenAtDate.toISOString() : undefined,
    cameraMake: raw.Make?.trim() || undefined,
    cameraModel: raw.Model?.trim() || undefined,
    lensModel: raw.LensModel?.trim() || undefined,
    focalLength: formatFocalLength(raw.FocalLength),
    aperture: formatAperture(raw.FNumber),
    shutterSpeed: formatShutterSpeed(raw.ExposureTime),
    iso: typeof raw.ISO === 'number' && Number.isFinite(raw.ISO) ? Math.round(raw.ISO) : undefined,
  };
}
