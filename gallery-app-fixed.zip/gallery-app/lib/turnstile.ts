// Cloudflare Turnstile 人机验证：校验客户端提交的 token 是否真的通过了验证，
// 挡的是"防批量注册"这几层里最关键的一环——限流、蜜罐、耗时检查都只是增加脚本的成本，
// 真正能有效区分真人和自动化脚本的还是这个。
//
// 没配 TURNSTILE_SECRET_KEY 时优雅降级为跳过校验（返回 true），方便本地开发/测试
// 不用先去 Cloudflare 开好 Turnstile 才能跑通注册流程。但正式对外开放注册前必须配置这个变量，
// 不然这里形同虚设，注册接口就直接暴露给批量脚本了。
export async function verifyTurnstile(token: unknown, ip: string): Promise<boolean> {
  const secretKey = process.env.TURNSTILE_SECRET_KEY;
  if (!secretKey) {
    console.warn('[turnstile] TURNSTILE_SECRET_KEY 未配置，跳过人机验证 —— 正式环境必须配置这个变量，否则注册接口没有防批量能力');
    return true;
  }
  if (typeof token !== 'string' || !token) return false;

  try {
    const res = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ secret: secretKey, response: token, remoteip: ip }),
    });
    const data = (await res.json()) as { success?: boolean };
    return data.success === true;
  } catch (err) {
    console.error('[turnstile] 校验请求失败:', err);
    // Cloudflare 校验服务本身连不上时，保守起见直接拒绝而不是放行——
    // 网络抖动偶尔误伤几个真实用户的成本，远低于"人机验证一挂就等于没有"的成本
    return false;
  }
}
