import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { NextResponse } from 'next/server';
import { getAuthSecretBytes } from '@/lib/auth-secret';

const secret = getAuthSecretBytes();
const COOKIE_NAME = 'admin_session';

// Secure cookie 只有在 HTTPS 下浏览器才会保留，用 http://IP:端口 测试时会被浏览器悄悄丢弃，
// 导致登录看起来成功、但下一个请求就被当成没登录。正式环境配好 HTTPS 后一定要把
// COOKIE_INSECURE 从 .env 里删掉或者设成 false，不然生产环境的登录 cookie 会用不加密的方式传输。
const useSecureCookie = process.env.NODE_ENV === 'production' && process.env.COOKIE_INSECURE !== 'true';

export async function createSession(userId: string) {
  const token = await new SignJWT({ userId })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(secret);

  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: useSecureCookie,
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function getSession() {
  const cookieStore = await cookies();
  const token = cookieStore.get(COOKIE_NAME)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret);
    return payload as { userId: string };
  } catch {
    return null;
  }
}

export async function clearSession() {
  const cookieStore = await cookies();
  cookieStore.delete(COOKIE_NAME);
}

// ---------------------------------------------------------------------------
// 下面两个函数是 proxy.ts 之外的第二道防线。
//
// proxy.ts（Next.js 16 里 middleware.ts 的新名字）目前是后台唯一的权限校验点：
// /monkey 和 /api/monkey 下面的页面和接口本身都没有再查一次 session。这在
// proxy.ts 逻辑本身没问题时能正常工作，但 Next.js 官方在 16 的迁移文档里明确提到，
// proxy.ts 不应该被当成唯一的安全边界（这也是当初 middleware 认证绕过漏洞
// CVE-2025-29927 暴露出的问题模式）——它覆盖的是网络边界，不保证一定会在
// 请求真正到达页面渲染 / route handler 之前生效。
//
// 所以这里补一层：受保护页面和后台接口自己也再查一次 session，
// 就算 proxy.ts 那层因为改动、绕过或配置疏漏没有生效，这一层依然会拒绝未登录请求。
// ---------------------------------------------------------------------------

/**
 * 给受保护的页面（Server Component，比如 app/monkey/(protected)/layout.tsx）用。
 * 没有有效 session 时直接跳转到登录页，不往下渲染任何后台数据。
 */
export async function requireAdminPage() {
  const session = await getSession();
  if (!session) {
    redirect('/monkey/login');
  }
  return session;
}

/**
 * 给 /api/monkey/* 的 route handler 用。
 * 没有有效 session 时返回一个可以直接 `return` 的 401 响应；
 * 有 session 时返回 session 本身，调用方按需取用 userId。
 *
 * 用法：
 *   const auth = await requireAdminApi();
 *   if ('response' in auth) return auth.response;
 *   // 走到这里说明已登录，auth.session.userId 可用
 */
export async function requireAdminApi(): Promise<
  { session: { userId: string } } | { response: NextResponse }
> {
  const session = await getSession();
  if (!session) {
    return { response: NextResponse.json({ error: '未登录或登录已过期' }, { status: 401 }) };
  }
  return { session };
}
