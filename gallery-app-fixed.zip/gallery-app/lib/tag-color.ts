import type { CSSProperties } from 'react';

// 从标签名字算出一个 0-359 的色相（hue），同一个名字在任何地方算出来的都一样，
// 不用后台手动给每个标签指定颜色。用的是简单的字符串哈希（djb2 变体），
// 不追求密码学强度，只要能把常见标签名打散开、不容易撞色就够了。
function hashHue(name: string): number {
  let hash = 5381;
  for (let i = 0; i < name.length; i++) {
    hash = (hash * 33 + name.charCodeAt(i)) | 0;
  }
  return Math.abs(hash) % 360;
}

// 站点背景色、文字色、强调色都是后台可自定义的（见 lib/settings.ts），日间/夜间还各有一套，
// 不能直接写死一批 hex 颜色当标签色——换个背景色主题就可能糊成一片看不清。
// 用 color-mix() 把哈希出来的色相跟当前主题的 --text-color / --bg-color 按比例混合，
// 混合基准会自动跟着主题走，色相只负责在这个基准上叠一层"这个标签专属的色调"。
// 这跟 globals.css 里 .site-title 用 var(--accent-color) 混 var(--text-color) 是同一个思路。

// 纯文字场景用（图集卡片、标签云）：不带底色，只把文字染色
export function tagTextColor(name: string): CSSProperties {
  const hue = hashHue(name);
  return { color: `color-mix(in srgb, hsl(${hue} 65% 55%) 60%, var(--text-color))` };
}

// 徽章/chip 场景用（图集详情页、后台标签管理、标签输入框）：底色 + 文字都带一点标签色
export function tagBadgeStyle(name: string): CSSProperties {
  const hue = hashHue(name);
  return {
    backgroundColor: `color-mix(in srgb, hsl(${hue} 65% 55%) 16%, var(--bg-color))`,
    color: `color-mix(in srgb, hsl(${hue} 65% 55%) 75%, var(--text-color))`,
  };
}

// 后台标签管理页那种小圆点场景用：只要一块实心的标签色，不用再跟主题混
export function tagDotColor(name: string): CSSProperties {
  const hue = hashHue(name);
  return { backgroundColor: `hsl(${hue} 65% 55%)` };
}
