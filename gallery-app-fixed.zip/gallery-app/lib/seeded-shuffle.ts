// 简单的确定性 PRNG（mulberry32），同一个 seed 每次调用产出的序列完全一样。
// "随机排序"不能真的每次请求都随机——分页是靠 skip/take 切片的，如果每次请求
// 独立随机一次，同一张图可能同时出现在第 1 页和第 2 页，也可能有的图哪页都不出现。
// 调用方一般会拿"当前小时"当 seed：同一个 ISR 缓存周期内所有分页请求拿到的是
// 同一个打乱顺序的切片，下一次 revalidate 时种子变了，顺序才会跟着换一批。
export function seededShuffle<T>(arr: T[], seed: number): T[] {
  let s = seed | 0;
  const rand = () => {
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const result = [...arr];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

// 拿"当前小时"当种子，配合 revalidate = 3600 的 ISR 页面：同一小时内所有请求
// （包括不同分页）拿到同一个打乱顺序，下一小时 revalidate 时才会换一批
export function currentHourSeed(): number {
  return Math.floor(Date.now() / (60 * 60 * 1000));
}
