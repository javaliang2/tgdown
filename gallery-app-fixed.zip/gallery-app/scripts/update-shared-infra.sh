#!/bin/bash
# 共享 PostgreSQL / Redis 那台机器换了地方（换 VPS、WireGuard IP 变了）时用这个脚本，
# 更新本地 .env 里的 DATABASE_URL / REDIS_URL，然后重新构建镜像 + 重启容器。
# 用法：在项目根目录下执行 ./scripts/update-shared-infra.sh
set -e

BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${BLUE}▸${NC} $1"; }
ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}!${NC} $1"; }
err()  { echo -e "${RED}✗${NC} $1"; }

if [ ! -f .env ]; then
  err "当前目录下没有 .env，请先 cd 到项目根目录"
  exit 1
fi

CHANGED=false

# ---- 1. 解析并更新 DATABASE_URL: postgresql://user:pass@host:port/dbname ----
CUR_DB_URL=$(grep '^DATABASE_URL=' .env | cut -d'=' -f2-)
if [ -z "$CUR_DB_URL" ]; then
  err "没能从 .env 读到 DATABASE_URL，检查一下这是不是正确的项目目录"
  exit 1
fi

DB_USER=$(echo "$CUR_DB_URL" | sed -E 's#postgresql://([^:]+):.*#\1#')
DB_PASS=$(echo "$CUR_DB_URL" | sed -E 's#postgresql://[^:]+:([^@]+)@.*#\1#')
DB_HOST=$(echo "$CUR_DB_URL" | sed -E 's#.*@([^:/]+):[0-9]+/.*#\1#')
DB_PORT=$(echo "$CUR_DB_URL" | sed -E 's#.*@[^:/]+:([0-9]+)/.*#\1#')
DB_NAME=$(echo "$CUR_DB_URL" | sed -E 's#.*/([^/?]+)(\?.*)?$#\1#')

echo
log "当前数据库：用户=${DB_USER}  地址=${DB_HOST}:${DB_PORT}  库名=${DB_NAME}"
read -rp "共享库新的 WireGuard IP（回车 = 不改，仍是 ${DB_HOST}）: " NEW_DB_HOST
read -rp "数据库密码是否也变了？变了就输入新密码，没变直接回车: " NEW_DB_PASS

FINAL_DB_HOST="${NEW_DB_HOST:-$DB_HOST}"
FINAL_DB_PASS="${NEW_DB_PASS:-$DB_PASS}"
NEW_DATABASE_URL="postgresql://${DB_USER}:${FINAL_DB_PASS}@${FINAL_DB_HOST}:${DB_PORT}/${DB_NAME}"

if [ "$NEW_DATABASE_URL" != "$CUR_DB_URL" ]; then
  sed -i.bak "s#^DATABASE_URL=.*#DATABASE_URL=${NEW_DATABASE_URL}#" .env
  rm -f .env.bak
  ok "DATABASE_URL 已更新"
  CHANGED=true
else
  log "DATABASE_URL 没有变化"
fi

# ---- 2. 解析并更新 REDIS_URL（可能没配置，也可能是注释掉的）----
echo
CUR_REDIS_LINE=$(grep -E '^REDIS_URL=' .env || true)
if [ -n "$CUR_REDIS_LINE" ]; then
  CUR_REDIS_URL=$(echo "$CUR_REDIS_LINE" | cut -d'=' -f2-)
  REDIS_PASS=$(echo "$CUR_REDIS_URL" | sed -E 's#redis://:([^@]*)@.*#\1#')
  REDIS_HOST=$(echo "$CUR_REDIS_URL" | sed -E 's#.*@([^:/]+):[0-9]+$#\1#')
  REDIS_PORT=$(echo "$CUR_REDIS_URL" | sed -E 's#.*:([0-9]+)$#\1#')

  log "当前 Redis：地址=${REDIS_HOST}:${REDIS_PORT}"
  read -rp "Redis 新的 WireGuard IP（回车 = 不改，仍是 ${REDIS_HOST}；通常跟数据库同一台，可直接填 ${FINAL_DB_HOST}）: " NEW_REDIS_HOST
  read -rp "Redis 密码是否也变了？变了就输入新密码，没变直接回车: " NEW_REDIS_PASS

  FINAL_REDIS_HOST="${NEW_REDIS_HOST:-$REDIS_HOST}"
  FINAL_REDIS_PASS="${NEW_REDIS_PASS:-$REDIS_PASS}"
  NEW_REDIS_URL="redis://:${FINAL_REDIS_PASS}@${FINAL_REDIS_HOST}:${REDIS_PORT}"

  if [ "$NEW_REDIS_URL" != "$CUR_REDIS_URL" ]; then
    sed -i.bak "s#^REDIS_URL=.*#REDIS_URL=${NEW_REDIS_URL}#" .env
    rm -f .env.bak
    ok "REDIS_URL 已更新"
    CHANGED=true
  else
    log "REDIS_URL 没有变化"
  fi
else
  warn "当前没有启用 REDIS_URL（单节点部署，或还没配 Redis），跳过。需要现在配置的话手动编辑 .env 里的 REDIS_URL 那一行"
fi

if [ "$CHANGED" != true ]; then
  echo
  ok "没有改动，退出"
  exit 0
fi

# ---- 3. 连通性测试（装了 psql 才测，测不了也不阻塞）----
if command -v psql &> /dev/null; then
  echo
  log "测试新的数据库连接…"
  if PGPASSWORD="$FINAL_DB_PASS" psql "postgresql://${DB_USER}@${FINAL_DB_HOST}:${DB_PORT}/${DB_NAME}" -c '\q' 2>/dev/null; then
    ok "数据库连接成功"
  else
    err "连不上新地址，先别重启服务。检查一下：WireGuard mesh 是否已连通、IP/密码是否正确、"
    echo "  共享库那台机器是否已经用 pg-redis-shared.sh 起好了服务"
    warn ".env 已经写入新值了，确认信息无误后重跑这个脚本，或者自己手动执行： docker compose up -d --build"
    exit 1
  fi
else
  warn "没检测到 psql，跳过连通性测试，直接重启"
fi

# ---- 4. 重新构建 + 重启 ----
# DATABASE_URL 同时是 docker-compose.yml 里的 build arg（构建阶段要预渲染页面查库），
# 换了地址必须重新 build，只 up -d 不够。
echo
log "DATABASE_URL 是构建参数，重新构建镜像…"
docker compose build

log "重启服务…"
docker compose up -d

echo
ok "完成，新的数据库/Redis 地址已生效"
warn "建议再跑一次 ./scripts/backup.sh 确认备份脚本也能连上新地址（backup.sh/restore.sh 用的是同一个 DATABASE_URL）"
