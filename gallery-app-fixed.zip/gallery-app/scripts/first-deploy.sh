#!/bin/bash
# 首次在新 VPS 上部署，从零到能访问网站。
# 用法：在项目根目录下执行 ./scripts/first-deploy.sh
set -e

BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${BLUE}▸${NC} $1"; }
ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}!${NC} $1"; }
err()  { echo -e "${RED}✗${NC} $1"; }

# 跟 pg-redis-shared.sh / infra-shared.sh 保持一致的写法，探测本机 WireGuard 网卡的 IP。
# 多节点部署时，每个节点跑一次 first-deploy.sh，各自把自己的 WG_IP 写进本地 .env，
# web 容器就只监听这个节点的 WireGuard 内网地址，配合 nginx-gateway.sh 在网关节点做负载均衡。
get_wg_ip() {
  local wg_iface="${WG_IFACE:-wg0}" ip
  ip=$(ip addr show "${wg_iface}" 2>/dev/null \
      | awk '/inet /{gsub(/\/.*/, "", $2); print $2; exit}')
  echo "$ip"
}

# ---- 1. 检查/安装 Docker ----
if ! command -v docker &> /dev/null; then
  log "没检测到 Docker，开始安装…"
  curl -fsSL https://get.docker.com | sh
  sudo usermod -aG docker "$USER"
  warn "Docker 组权限刚加上，如果下面的命令报权限错误，请退出重新 SSH 登录一次再重跑这个脚本"
else
  ok "Docker 已安装"
fi

if ! docker compose version &> /dev/null; then
  err "docker compose 插件不可用，请手动检查 Docker 安装（较新版本一般自带）"
  exit 1
fi
ok "docker compose 可用"

# ---- 1.5 检查/安装 aws-cli（备份脚本用它做异地备份，可选但顺手装上） ----
if command -v aws &> /dev/null; then
  ok "aws-cli 已安装"
else
  log "没检测到 aws-cli，尝试自动安装（用于 backup.sh 的异地备份，装不上也不影响本次部署）…"
  if command -v apt-get &> /dev/null; then
    sudo apt-get update -qq && sudo apt-get install -y -qq awscli
  elif command -v pip3 &> /dev/null; then
    pip3 install --quiet awscli
  fi

  if command -v aws &> /dev/null; then
    ok "aws-cli 安装完成"
  else
    warn "aws-cli 自动安装失败，不影响当前部署。之后想要异地备份的话手动装一下："
    echo "    sudo apt install -y awscli   # 或 pip install awscli"
  fi
fi

# ---- 1.6 检查/安装 postgresql-client（backup.sh/restore.sh 用它的 pg_dump/psql 连远程共享库，
#          应用本身走 Prisma 连库不需要这个，只有想用备份/恢复脚本时才用得上，可选但顺手装上）
#
#          pg_dump 有个硬性规则：客户端版本必须 >= 服务端版本，不然直接拒绝导出。
#          Debian 默认软件源给的版本比较保守（比如 Debian 13 默认是 17），跟共享库那台机器
#          实际跑的 Postgres 大版本对不上就会导出失败。所以这里不用发行版默认源，
#          改成加 PGDG（PostgreSQL 官方 apt 源）装一个明确指定大版本的包，跟共享库版本对齐。
#          共享库现在是 18，如果之后用 pg-major-upgrade.sh 把共享库升级到更新的大版本，
#          这里的 PG_CLIENT_MAJOR 也要跟着改，不然又会重新掉进版本不匹配的坑。 ----
PG_CLIENT_MAJOR=18
if command -v pg_dump &> /dev/null && command -v psql &> /dev/null; then
  ok "postgresql-client 已安装（$(pg_dump --version)）"
else
  log "没检测到 pg_dump/psql，尝试自动安装 postgresql-client-${PG_CLIENT_MAJOR}（用于 backup.sh/restore.sh，装不上也不影响本次部署）…"
  if command -v apt-get &> /dev/null; then
    sudo install -d /usr/share/postgresql-common/pgdg
    sudo curl -fsSL https://www.postgresql.org/media/keys/ACCC4CF8.asc \
      -o /usr/share/postgresql-common/pgdg/apt.postgresql.org.asc
    echo "deb [signed-by=/usr/share/postgresql-common/pgdg/apt.postgresql.org.asc] https://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" \
      | sudo tee /etc/apt/sources.list.d/pgdg.list > /dev/null
    sudo apt-get update -qq && sudo apt-get install -y -qq "postgresql-client-${PG_CLIENT_MAJOR}"
  fi

  if command -v pg_dump &> /dev/null && command -v psql &> /dev/null; then
    ok "postgresql-client 安装完成（$(pg_dump --version)）"
  else
    warn "postgresql-client 自动安装失败，不影响当前部署。之后想要用备份/恢复脚本的话手动装一下（要跟共享库的大版本对上，不能直接装发行版默认的 postgresql-client）："
    echo "    sudo apt install -y postgresql-client-${PG_CLIENT_MAJOR}   # 需要先加 PGDG 源，见 README"
  fi
fi

# ---- 2. 准备 .env ----
if [ ! -f .env ]; then
  log "没有 .env，从 .env.example 创建一份"
  cp .env.example .env

  # ---- 会话密钥：单节点直接自动生成；多节点部署时，所有节点必须用同一把，
  #      不然请求被 nginx-gateway.sh 负载均衡到不同节点时，这个节点验不了
  #      另一个节点签发的 cookie，用户会莫名其妙掉登录。管理员和前台用户
  #      各一把独立密钥，不能共用同一个值——见 lib/auth-secret.ts 里的说明 ----
  echo
  log "配置会话密钥（AUTH_SECRET / USER_AUTH_SECRET）"
  echo "  多节点部署时，同一个网站的所有节点必须用同一把密钥，否则跨节点 session 会失效"
  read -rp "这是唯一一次部署吗？（单节点，或者是多节点里的第一个节点）[Y/n] " -n 1 SINGLE_DEPLOY_REPLY
  echo

  if [[ $SINGLE_DEPLOY_REPLY =~ ^[Nn]$ ]]; then
    log "多节点部署：粘贴第一个节点部署完成时打印出来的密钥（两把都要，必须跟第一个节点完全一致）"
    read -rp "AUTH_SECRET: " AUTH_SECRET
    read -rp "USER_AUTH_SECRET: " USER_AUTH_SECRET
    while [ -z "$AUTH_SECRET" ] || [ "${#AUTH_SECRET}" -lt 16 ] || [ -z "$USER_AUTH_SECRET" ] || [ "${#USER_AUTH_SECRET}" -lt 16 ]; do
      warn "密钥不能为空，且长度至少 16 位（跟 lib/auth-secret.ts 里的校验对上），重新粘贴一次"
      read -rp "AUTH_SECRET: " AUTH_SECRET
      read -rp "USER_AUTH_SECRET: " USER_AUTH_SECRET
    done
    GENERATED_SECRETS=false
    ok "已使用粘贴的密钥（与其他节点保持一致）"
  else
    AUTH_SECRET=$(openssl rand -base64 32)
    USER_AUTH_SECRET=$(openssl rand -base64 32)
    GENERATED_SECRETS=true
    ok "已自动生成会话密钥（管理员、前台用户各一把），部署完成后会打印出来，多节点部署时后续节点要用到"
  fi

  sed -i.bak "s#^AUTH_SECRET=.*#AUTH_SECRET=${AUTH_SECRET}#" .env
  sed -i.bak "s#^USER_AUTH_SECRET=.*#USER_AUTH_SECRET=${USER_AUTH_SECRET}#" .env
  rm -f .env.bak

  # ---- 数据库：连接 pg-redis-shared.sh 部署的共享库（走 WireGuard 内网） ----
  echo
  log "配置数据库连接（先去共享库那台机器上执行一次，拿到库名/用户/密码：）"
  echo "    ./pg-redis-shared.sh add-db /srv/pg-infra gallery gallery"
  echo "  不确定密码的话，也可以用 list-db 查看，或者重新跑 add-db 传第4个参数指定密码"
  echo

  read -rp "共享库所在机器的 WireGuard IP: " DB_WG_IP_INPUT
  read -rp "数据库密码（add-db 生成/指定的那个）: " DB_PASS_INPUT

  if [ -n "$DB_WG_IP_INPUT" ] && [ -n "$DB_PASS_INPUT" ]; then
    sed -i.bak "s#^DATABASE_URL=.*#DATABASE_URL=postgresql://gallery:${DB_PASS_INPUT}@${DB_WG_IP_INPUT}:5432/gallery#" .env
    rm -f .env.bak
    ok "数据库连接已写入 .env"
  else
    warn "数据库连接信息不完整，先跳过。之后手动编辑 .env 里的 DATABASE_URL 再启动，确保本机已连上 WireGuard mesh 能通到共享库"
  fi

  # ---- 本机 WireGuard IP：多节点部署时，web 容器只监听这个地址 ----
  echo
  MY_WG_IP=$(get_wg_ip)
  if [ -n "$MY_WG_IP" ]; then
    sed -i.bak "s#^\# WG_IP=.*#WG_IP=${MY_WG_IP}#" .env
    rm -f .env.bak
    ok "检测到本机 WireGuard IP: ${MY_WG_IP}，已写入 .env（web 容器将只监听这个地址）"
    warn "如果这是单节点部署、不打算用 nginx-gateway.sh 做多节点负载均衡，可以把 .env 里的 WG_IP 这行删掉/注释掉，回退成绑 127.0.0.1"

    echo
    log "配置 Redis（可选，多节点部署时用于跨节点共享限流；单节点部署直接回车跳过即可）"
    read -rp "共享 Redis 所在机器的 WireGuard IP（留空跳过；通常跟数据库同一台: ${DB_WG_IP_INPUT:-未设置}）: " REDIS_WG_IP_INPUT
    if [ -n "$REDIS_WG_IP_INPUT" ]; then
      read -rp "Redis 密码: " REDIS_PASS_INPUT
    fi

    if [ -n "$REDIS_WG_IP_INPUT" ] && [ -n "$REDIS_PASS_INPUT" ]; then
      sed -i.bak "s#^\# REDIS_URL=.*#REDIS_URL=redis://:${REDIS_PASS_INPUT}@${REDIS_WG_IP_INPUT}:6379#" .env
      rm -f .env.bak
      ok "Redis 连接已写入 .env"
    else
      warn "跳过 Redis 配置，单节点部署不影响；多节点部署的话之后手动编辑 .env 里的 REDIS_URL"
    fi
  else
    warn "没检测到 ${WG_IFACE:-wg0} 网卡，跳过 WG_IP 自动写入。单节点部署不影响，.env 会回退绑 127.0.0.1；多节点部署的话请先确认 WireGuard 已连上再重跑"
  fi

  # ---- R2 配置，交互式输入 ----
  echo
  log "接下来配置 Cloudflare R2（去 Cloudflare Dashboard → R2 → 管理 API 令牌 拿这几项）"
  echo "  不确定的话可以先留空，回车跳过，之后自己手动编辑 .env 再补上"
  echo

  read -rp "S3_ENDPOINT (形如 https://<account-id>.r2.cloudflarestorage.com): " S3_ENDPOINT_INPUT
  read -rp "S3_ACCESS_KEY_ID: " S3_ACCESS_KEY_INPUT
  read -rp "S3_SECRET_ACCESS_KEY: " S3_SECRET_KEY_INPUT
  read -rp "S3_BUCKET (bucket 名称): " S3_BUCKET_INPUT
  read -rp "S3_PUBLIC_URL (公开访问域名，形如 https://images.yourdomain.com): " S3_PUBLIC_URL_INPUT

  # 只有实际输入了内容才写进 .env，避免把已有的占位符值清空成空字符串
  [ -n "$S3_ENDPOINT_INPUT" ] && sed -i.bak "s#^S3_ENDPOINT=.*#S3_ENDPOINT=${S3_ENDPOINT_INPUT}#" .env
  [ -n "$S3_ACCESS_KEY_INPUT" ] && sed -i.bak "s#^S3_ACCESS_KEY_ID=.*#S3_ACCESS_KEY_ID=${S3_ACCESS_KEY_INPUT}#" .env
  [ -n "$S3_SECRET_KEY_INPUT" ] && sed -i.bak "s#^S3_SECRET_ACCESS_KEY=.*#S3_SECRET_ACCESS_KEY=${S3_SECRET_KEY_INPUT}#" .env
  [ -n "$S3_BUCKET_INPUT" ] && sed -i.bak "s#^S3_BUCKET=.*#S3_BUCKET=${S3_BUCKET_INPUT}#" .env
  if [ -n "$S3_PUBLIC_URL_INPUT" ]; then
    sed -i.bak "s#^S3_PUBLIC_URL=.*#S3_PUBLIC_URL=${S3_PUBLIC_URL_INPUT}#" .env
    # next.config.js 用这个校验图片域名，自动从 URL 里把域名部分抠出来
    S3_HOSTNAME=$(echo "$S3_PUBLIC_URL_INPUT" | sed -E 's#^https?://##' | cut -d'/' -f1)
    sed -i.bak "s#^S3_PUBLIC_HOSTNAME=.*#S3_PUBLIC_HOSTNAME=${S3_HOSTNAME}#" .env
  fi
  rm -f .env.bak

  if [ -z "$S3_ENDPOINT_INPUT" ] || [ -z "$S3_ACCESS_KEY_INPUT" ] || [ -z "$S3_SECRET_KEY_INPUT" ] || [ -z "$S3_BUCKET_INPUT" ]; then
    warn "R2 配置不完整，图片上传功能现在用不了。之后想起来了手动编辑 .env 补上，改完记得跑："
    echo "    docker compose up -d --build"
  else
    ok "R2 配置已写入 .env"
  fi

  # ---- Cloudflare Turnstile 配置，交互式输入 ----
  # 前台注册接口（/api/register）靠这个防批量刷号，见 lib/turnstile.ts。
  # 留空不会挡住部署——lib/turnstile.ts 没检测到 TURNSTILE_SECRET_KEY 会优雅降级跳过校验，
  # 只是这样一来注册接口就没有人机验证这道防线了，正式对外开放注册前建议还是配上。
  echo
  log "接下来配置 Cloudflare Turnstile（前台注册接口的人机验证，去 Cloudflare Dashboard → Turnstile 新建一个 widget 拿这两项）"
  echo "  不确定的话可以先留空，回车跳过——注册接口会自动跳过人机验证并打警告日志，不影响部署，之后配上重新构建即可"
  echo

  read -rp "NEXT_PUBLIC_TURNSTILE_SITE_KEY: " TURNSTILE_SITE_KEY_INPUT
  read -rp "TURNSTILE_SECRET_KEY: " TURNSTILE_SECRET_KEY_INPUT

  [ -n "$TURNSTILE_SITE_KEY_INPUT" ] && sed -i.bak "s#^NEXT_PUBLIC_TURNSTILE_SITE_KEY=.*#NEXT_PUBLIC_TURNSTILE_SITE_KEY=${TURNSTILE_SITE_KEY_INPUT}#" .env
  [ -n "$TURNSTILE_SECRET_KEY_INPUT" ] && sed -i.bak "s#^TURNSTILE_SECRET_KEY=.*#TURNSTILE_SECRET_KEY=${TURNSTILE_SECRET_KEY_INPUT}#" .env
  rm -f .env.bak

  if [ -z "$TURNSTILE_SITE_KEY_INPUT" ] || [ -z "$TURNSTILE_SECRET_KEY_INPUT" ]; then
    warn "Turnstile 未配置，注册接口暂时没有人机验证防护。正式对外开放注册前，手动编辑 .env 补上，改完记得跑："
    echo "    docker compose up -d --build"
  else
    ok "Turnstile 配置已写入 .env"
  fi
else
  ok ".env 已存在，跳过生成"
fi

# ---- 3. 首次部署：build 阶段会预渲染页面（查 siteSetting/navLink/Album/tag 等，
#          sitemap.ts 也会在构建时查 Album 和 Tag），这时候库里还没有表，必须先把
#          migration 跑一遍，构建才不会因为 "table does not exist" 报错退出。
#          用 deps 阶段的镜像跑 migrate，不用装额外工具，也不用等 npm run build
#          跑完才失败。注意这里跑的是 `prisma migrate deploy`，会把 prisma/migrations/
#          下所有迁移一次性应用完，不是按表名单独建，所以以后 schema 里再加新表/
#          新迁移，这一步不用跟着改，自动就包含进去了。
log "首次部署，先在共享库里建表（跑 prisma migrate deploy）…"
docker build --target deps -t gallery-app:deps . > /dev/null
DEPLOY_DB_URL=$(grep '^DATABASE_URL=' .env | cut -d'=' -f2-)
if [ -z "$DEPLOY_DB_URL" ]; then
  err "没能从 .env 读到 DATABASE_URL，检查一下再重跑"
  exit 1
fi
docker run --rm --network host \
  -v "$(pwd)/prisma:/app/prisma:ro" \
  -w /app \
  -e DATABASE_URL="${DEPLOY_DB_URL}" \
  gallery-app:deps sh -c "apk add --no-cache openssl >/dev/null 2>&1; npx prisma migrate deploy"
ok "建表完成"

# ---- 4. 构建并启动 ----
log "构建镜像并启动服务（第一次会比较慢，耐心等下）…"
docker compose up -d --build

log "等待数据库和应用就绪…"
sleep 5
for i in $(seq 1 12); do
  if docker compose exec -T web node -e "
    require('http').get('http://localhost:3000', res => {
      process.exit(res.statusCode === 200 ? 0 : 1);
    }).on('error', () => process.exit(1));
  " 2>/dev/null; then
    ok "应用已经能响应了"
    break
  fi
  if [ "$i" -eq 12 ]; then
    warn "等了一分钟还没就绪，去看看日志：docker compose logs -f web"
  fi
  sleep 5
done

# ---- 5. 创建管理员账号 ----
echo
log "接下来可以创建管理员账号"
warn "create-admin.cjs 是 upsert：如果这不是第一次跑本脚本、库里已经有管理员了，同邮箱会直接覆盖密码"
read -rp "现在要创建/重置管理员账号吗？(y/N) " -n 1 CREATE_ADMIN_REPLY
echo

if [[ $CREATE_ADMIN_REPLY =~ ^[Yy]$ ]]; then
  read -rp "管理员邮箱: " ADMIN_EMAIL
  read -rp "管理员密码（至少10位，包含字母和数字）: " ADMIN_PASS

  if docker compose exec -T web node prisma/create-admin.cjs "$ADMIN_EMAIL" "$ADMIN_PASS"; then
    ok "管理员账号创建成功"
  else
    err "创建失败，密码可能不满足强度要求，重跑一次："
    echo "  docker compose exec web node prisma/create-admin.cjs <email> <password>"
  fi
else
  log "已跳过，之后需要的话手动跑："
  echo "  docker compose exec web node prisma/create-admin.cjs <email> <password>"
fi

# ---- 6. 完成 ----
echo
ok "部署完成！"

if [ "${GENERATED_SECRETS:-false}" = true ]; then
  echo
  warn "记下这两把会话密钥——多节点部署时，其他节点跑本脚本时选「否」并粘贴这两个值，保持所有节点一致："
  echo "    AUTH_SECRET=${AUTH_SECRET}"
  echo "    USER_AUTH_SECRET=${USER_AUTH_SECRET}"
fi
warn "3000 端口只绑在了 127.0.0.1 上，不对公网暴露（Docker 发布端口会绕过 ufw 规则，所以干脆不监听公网接口），VPS 的 IP:3000 是访问不了的，这是有意为之。"
echo "  先测试的话，两种办法："
echo "    1. 在 VPS 上直接跑：curl http://localhost:3000"
echo "    2. 本地执行：ssh -L 3000:localhost:3000 你的VPS，然后浏览器打开 http://localhost:3000"
echo
echo "  正式使用前记得："
echo "    1. 配置域名 + Caddy/Nginx 反代和 HTTPS（反代进程跑在 VPS 上，通过 localhost:3000 连到容器）"
echo "    2. 用 ufw 只放行 22/80/443（3000 本来就没对外开，这步主要是防其他服务）"
