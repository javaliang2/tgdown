/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  images: {
    // 关掉 Next 自带的图片优化（/_next/image 那个实时缩放+重新编码的接口）。
    // 不关的话，网页上 <Image> 实际请求的不是对象存储里的原图 URL，而是 Next 服务端
    // 按目标宽度现算现转的版本（默认 quality=75），用户在网站上看到/下载到的
    // 就都是被二次压缩过的图，跟存储里的原图对不上。
    // 图片本来就走 CDN 分发了，缩略图也已经是前端上传前用 canvas 生成好的，
    // 没必要再让 app server 自己实时转码一遍，白白吃 CPU。
    unoptimized: true,
    remotePatterns: [
      {
        protocol: 'https',
        // 替换成你的对象存储公开访问域名（自定义域名或存储商自带的公开域名）
        hostname: process.env.S3_PUBLIC_HOSTNAME || 'example.r2.dev',
      },
    ],
  },
  // 部署说明里一直是"反代负责 HTTPS，应用只管业务逻辑"，但这几个头本来就该由应用自己兜底，
  // 不该完全依赖反代有没有配对——反代换了/漏配了，网站还是有基本的安全头。
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          // 禁止浏览器猜测/嗅探响应的 MIME 类型，避免把上传的图片当成脚本执行之类的攻击
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          // 跳转到别的站点时只带 origin，不带完整路径（比如带 token 的路径），保护隐私
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          // 明确关掉用不到的浏览器能力，图集站不需要摄像头/麦克风/定位这些
          { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
          // HSTS：只有实际走 HTTPS 时浏览器才会认这个头，HTTP 场景下无害，可以放心常驻。
          // 部署文档里那种"临时用 http://IP:端口 测试"的场景不受影响。
          { key: 'Strict-Transport-Security', value: 'max-age=15552000; includeSubDomains' },
        ],
      },
      {
        // 后台管理页面单独再加一道，禁止被嵌入 iframe（防点击劫持），
        // 前台展示页不加这条，因为以后如果想让前台被别的站点 iframe 嵌入展示图集也不受影响
        source: '/monkey/:path*',
        headers: [{ key: 'X-Frame-Options', value: 'DENY' }],
      },
      {
        // 登录页单独加一道，禁止被嵌入 iframe（防点击劫持）
        source: '/login',
        headers: [{ key: 'X-Frame-Options', value: 'DENY' }],
      },
      {
        // 注册页同上——处理的是密码，跟后台管理页是同一个风险等级，同样禁止被嵌入 iframe——
        // 不加这条的话，理论上恶意页面可以用一个透明 iframe 叠在自己页面上诱导用户在不知情的
        // 情况下点击/输入，把凭证"偷"到本站的登录请求里（点击劫持的一种变体）
        //
        // 注：headers() 的 source 字段 Next.js 只支持单个字符串，不支持数组，
        // 写成 ['/login', '/register'] 会在 `next build` 阶段直接报 "Invalid header found"
        // 然后构建失败退出，所以这里拆成两条分别配置
        source: '/register',
        headers: [{ key: 'X-Frame-Options', value: 'DENY' }],
      },
    ];
  },
};

module.exports = nextConfig;
