import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { broadcastCacheInvalidation } from '@/lib/cache-broadcast';
import { findConflictingTag } from '@/lib/slug';
import { requireAdminApi } from '@/lib/auth';

// 重命名 / 合并标签。如果 newName 已经是另一个标签的名字，效果就是合并：
// 把旧标签关联的图集转接到目标标签上（关系表有唯一约束，两个标签下都有的图集不会重复关联），
// 再删掉旧标签这一行。如果 newName 是全新的名字，就是单纯重命名：只改 Tag.name 这一个字段，
// 图集和标签的关联关系完全不用动。
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ tag: string }> }) {
  const auth = await requireAdminApi();
  if ('response' in auth) return auth.response;

  const { tag } = await params;
  const oldTag = decodeURIComponent(tag);
  const { newName } = await req.json();
  const trimmed = typeof newName === 'string' ? newName.trim() : '';

  if (!trimmed) {
    return NextResponse.json({ error: '请输入新的标签名' }, { status: 400 });
  }
  if (trimmed === oldTag) {
    return NextResponse.json({ ok: true }); // 没变化，直接算成功
  }

  const conflict = await findConflictingTag([trimmed]);
  if (conflict) {
    return NextResponse.json(
      { error: `标签名"${conflict}"和站点固定路径或已有图集地址重名，换一个名字` },
      { status: 400 },
    );
  }

  const oldTagRow = await prisma.tag.findUnique({ where: { name: oldTag } });
  if (!oldTagRow) {
    return NextResponse.json({ error: '标签不存在' }, { status: 404 });
  }

  const affected = await prisma.album.count({ where: { tags: { some: { id: oldTagRow.id } } } });
  const existingTarget = await prisma.tag.findUnique({ where: { name: trimmed } });

  if (existingTarget) {
    // 合并：把 oldTag 关联的每个图集都转接到 existingTarget 上，再删掉 oldTag。
    // 一个图集如果本来就同时挂了 oldTag 和 existingTarget，connect 到已经存在的关系是幂等的，不会报错。
    const albums = await prisma.album.findMany({
      where: { tags: { some: { id: oldTagRow.id } } },
      select: { id: true },
    });
    await prisma.$transaction([
      ...albums.map((album) =>
        prisma.album.update({
          where: { id: album.id },
          data: {
            tags: {
              disconnect: { id: oldTagRow.id },
              connect: { id: existingTarget.id },
            },
          },
        }),
      ),
      prisma.tag.delete({ where: { id: oldTagRow.id } }),
    ]);
  } else {
    // 单纯重命名：改这一行 name 就行，所有关联关系（哪些图集挂着这个标签）完全不受影响
    await prisma.tag.update({ where: { id: oldTagRow.id }, data: { name: trimmed } });
  }

  revalidatePath('/tags');
  revalidatePath(`/${encodeURIComponent(oldTag)}`);
  revalidatePath(`/${encodeURIComponent(trimmed)}`);
  await broadcastCacheInvalidation([
    { path: '/tags' },
    { path: `/${encodeURIComponent(oldTag)}` },
    { path: `/${encodeURIComponent(trimmed)}` },
  ]);

  return NextResponse.json({ ok: true, affected });
}

// 删除标签：把这一行 Tag 删掉，关联关系表里的对应行会跟着级联删除，图集本身不受影响。
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ tag: string }> }) {
  const auth = await requireAdminApi();
  if ('response' in auth) return auth.response;

  const { tag } = await params;
  const target = decodeURIComponent(tag);

  const tagRow = await prisma.tag.findUnique({ where: { name: target } });
  if (!tagRow) {
    return NextResponse.json({ ok: true, affected: 0 });
  }

  const affected = await prisma.album.count({ where: { tags: { some: { id: tagRow.id } } } });
  await prisma.tag.delete({ where: { id: tagRow.id } });

  revalidatePath('/tags');
  revalidatePath(`/${encodeURIComponent(target)}`);
  await broadcastCacheInvalidation([{ path: '/tags' }, { path: `/${encodeURIComponent(target)}` }]);

  return NextResponse.json({ ok: true, affected });
}
