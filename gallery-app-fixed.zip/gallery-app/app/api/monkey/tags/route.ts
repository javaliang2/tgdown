import { NextResponse } from 'next/server';
import { getTagCounts } from '@/lib/tags';
import { requireAdminApi } from '@/lib/auth';

// 跟前台 app/tags/page.tsx 的统计口径不一样：这里不加 status 过滤，
// 草稿图集上的标签后台也要能看到、能管理，不然改名/合并的时候会漏掉。
export async function GET() {
  const auth = await requireAdminApi();
  if ('response' in auth) return auth.response;

  const tagCounts = await getTagCounts(false);
  return NextResponse.json(tagCounts);
}
