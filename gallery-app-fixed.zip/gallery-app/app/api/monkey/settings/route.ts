import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { invalidateSiteSettingsCache } from '@/lib/settings';
import { broadcastCacheInvalidation } from '@/lib/cache-broadcast';
import { requireAdminApi } from '@/lib/auth';

export async function GET() {
  const auth = await requireAdminApi();
  if ('response' in auth) return auth.response;

  const settings = await prisma.siteSetting.findUnique({ where: { id: 1 } });
  return NextResponse.json(settings);
}

export async function PATCH(req: NextRequest) {
  const auth = await requireAdminApi();
  if ('response' in auth) return auth.response;

  const body = await req.json();
  const { siteTitle, siteDescription, logoKey, backgroundColor, textColor, accentColor, icpNumber, contactInfo, aboutContent } =
    body;

  const settings = await prisma.siteSetting.upsert({
    where: { id: 1 },
    update: { siteTitle, siteDescription, logoKey, backgroundColor, textColor, accentColor, icpNumber, contactInfo, aboutContent },
    create: { id: 1, siteTitle, siteDescription, logoKey, backgroundColor, textColor, accentColor, icpNumber, contactInfo, aboutContent },
  });

  // logoData 只在前端这次确实改了 logo（重新上传或点了移除）时才会出现在 body 里，
  // 没改动的话就不动 SiteAsset 这张表，避免每次保存设置都重写一遍图片数据。
  if ('logoData' in body) {
    await prisma.siteAsset.upsert({
      where: { id: 1 },
      update: { logoData: body.logoData },
      create: { id: 1, logoData: body.logoData },
    });
  }

  // layout 是所有页面共用的，type: 'layout' 会让所有路由的布局缓存一起失效，改完立即生效；
  // Redis 里缓存的那份 settings 也要一起清掉，不然新请求可能命中缓存里的旧数据
  await invalidateSiteSettingsCache();
  revalidatePath('/', 'layout');
  // 多节点部署时，这个请求只落在了一个节点上，revalidatePath 只清了这个节点自己的页面缓存，
  // 广播出去让其它节点也刷新各自的缓存
  await broadcastCacheInvalidation([{ path: '/', type: 'layout' }]);

  return NextResponse.json(settings);
}
