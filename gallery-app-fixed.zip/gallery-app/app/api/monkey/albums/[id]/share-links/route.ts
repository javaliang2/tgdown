import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { requireAdminApi } from '@/lib/auth';

// GET: 列出某个图集下的所有分享链接（包括已撤销/已过期的，后台自己按 revokedAt/expiresAt 判断展示状态）
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAdminApi();
  if ('response' in auth) return auth.response;

  const { id } = await params;
  const links = await prisma.shareLink.findMany({ where: { albumId: id }, orderBy: { createdAt: 'desc' } });
  return NextResponse.json(links);
}

// POST: 新建一条分享链接
// body: { label?: string, expiresInDays?: number } —— expiresInDays 不传 = 永久有效
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAdminApi();
  if ('response' in auth) return auth.response;

  const { id } = await params;
  const album = await prisma.album.findUnique({ where: { id }, select: { id: true, visibility: true } });
  if (!album) {
    return NextResponse.json({ error: '图集不存在' }, { status: 404 });
  }
  if (album.visibility !== 'PRIVATE') {
    // 分享链接是给私密相册用的免注册访问方式，公开相册本来就谁都能看，开分享链接没有意义，
    // 干脆在这里拦掉，免得后台出现一堆没用的链接
    return NextResponse.json({ error: '只有私密相册才需要分享链接' }, { status: 400 });
  }

  const { label, expiresInDays } = await req.json().catch(() => ({}));
  const expiresAt =
    typeof expiresInDays === 'number' && expiresInDays > 0
      ? new Date(Date.now() + expiresInDays * 24 * 60 * 60 * 1000)
      : null;

  const link = await prisma.shareLink.create({
    data: { albumId: id, label: typeof label === 'string' && label.trim() ? label.trim() : null, expiresAt },
  });

  return NextResponse.json(link, { status: 201 });
}
