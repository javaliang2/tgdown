import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { toSlug } from '@/lib/slug';
import { revalidatePath } from 'next/cache';
import { invalidateCategoryTreeCache } from '@/lib/categories';
import { broadcastCacheInvalidation } from '@/lib/cache-broadcast';
import { requireAdminApi } from '@/lib/auth';

export async function GET() {
  const auth = await requireAdminApi();
  if ('response' in auth) return auth.response;

  const categories = await prisma.category.findMany({
    orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
    include: { _count: { select: { albums: true } }, parent: { select: { name: true } } },
  });
  return NextResponse.json(categories);
}

export async function POST(req: NextRequest) {
  const auth = await requireAdminApi();
  if ('response' in auth) return auth.response;

  const { name, parentId } = await req.json();
  if (!name) {
    return NextResponse.json({ error: '请输入分类名称' }, { status: 400 });
  }

  const baseSlug = toSlug(name);
  let slug = baseSlug;
  let counter = 1;
  while (await prisma.category.findUnique({ where: { slug } })) {
    slug = `${baseSlug}-${counter++}`;
  }

  const category = await prisma.category.create({ data: { name, slug, parentId: parentId || null } });
  await invalidateCategoryTreeCache();
  revalidatePath('/');
  await broadcastCacheInvalidation([{ path: '/' }]);
  return NextResponse.json(category, { status: 201 });
}
