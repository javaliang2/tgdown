import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { requireAdminApi } from '@/lib/auth';

// 更新"这个用户能访问哪些私密相册"——每次提交的是完整的授权相册 id 列表，
// 用 set 整体替换掉现有的关联关系，而不是一个个 connect/disconnect。
// 前端是勾选框列表，天然就是"提交当前完整勾选状态"这种交互，跟 set 这种"整体替换"
// 的语义正好对上，不用自己去 diff 出"新增了哪些、去掉了哪些"。
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAdminApi();
  if ('response' in auth) return auth.response;

  const { id } = await params;
  const body = await req.json().catch(() => null);
  const albumIds = body && Array.isArray(body.albumIds) ? body.albumIds : null;

  if (!albumIds || !albumIds.every((a: unknown) => typeof a === 'string')) {
    return NextResponse.json({ error: '参数不对' }, { status: 400 });
  }

  const user = await prisma.user.findUnique({ where: { id }, select: { id: true } });
  if (!user) {
    return NextResponse.json({ error: '用户不存在' }, { status: 404 });
  }

  await prisma.user.update({
    where: { id },
    data: { albums: { set: albumIds.map((albumId: string) => ({ id: albumId })) } },
  });

  // 被授权/取消授权的相册详情页缓存要失效，不然已经登录、刚被撤销权限的用户
  // 还能在缓存过期前继续看到锁定前的状态——虽然实际权限判断走的是 force-dynamic
  // 的 /api/albums/[slug]/photos，本身不会被缓存，这里 revalidate 主要是让页面
  // 壳层（标题/简介那部分）也尽快反映最新状态，双重保险
  revalidatePath('/monkey/users');

  return NextResponse.json({ ok: true });
}

// 删除用户：连带的授权关系（_AlbumToUser 那张关系表）会自动级联删除，
// 相册本身不受影响。这个用户已经签发出去的 session token 在过期之前签名依然有效，
// 但 lib/user-auth.ts 的 getCurrentUser() 每次都会重新查一次数据库，查不到这个用户了
// 就返回 null，任何权限判断都会立刻正确地拒绝掉，不用等 token 自然过期。
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAdminApi();
  if ('response' in auth) return auth.response;

  const { id } = await params;

  const user = await prisma.user.findUnique({ where: { id }, select: { id: true } });
  if (!user) {
    return NextResponse.json({ ok: true }); // 已经不存在，直接算成功，幂等
  }

  await prisma.user.delete({ where: { id } });
  revalidatePath('/monkey/users');

  return NextResponse.json({ ok: true });
}
