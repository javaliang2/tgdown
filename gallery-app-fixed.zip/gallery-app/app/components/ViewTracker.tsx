'use client';

import { useEffect } from 'react';

// 浏览量埋点：客户端上报，不影响静态页缓存（详情页是 ISR 静态页，埋点只能挂载后单独发请求）。
//
// 之前这里是用 <script dangerouslySetInnerHTML> 把 slug 拼进一段内联 JS 字符串里执行。
// 因为 slug 一律经过 lib/slug.ts 的 toSlug()（pinyin + slugify）净化过，实际不会包含引号
// 之类的危险字符，所以那样写目前是安全的——但这份"安全"完全依赖调用方有没有老老实实
// 走 toSlug()，不是这段渲染代码自己的保证。换成真正的 React 组件 + fetch()，
// slug 只是当一个普通的请求参数用，不会被当成可执行代码拼进页面，彻底不用考虑这类风险，
// 不管上游数据是否经过净化都一样安全。
export default function ViewTracker({ slug }: { slug: string }) {
  useEffect(() => {
    fetch(`/api/albums/${encodeURIComponent(slug)}/view`, { method: 'POST' }).catch(() => {});
  }, [slug]);

  return null;
}
