'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

export default function AuthWidget() {
  const router = useRouter();
  const [email, setEmail] = useState<string | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);

  useEffect(() => {
    fetch('/api/me')
      .then((r) => r.json())
      .then((data) => setEmail(data.email ?? null))
      .catch(() => {})
      .finally(() => setLoaded(true));
  }, []);

  async function handleLogout() {
    setLoggingOut(true);
    await fetch('/api/logout', { method: 'POST' });
    setEmail(null);
    setLoggingOut(false);
    router.push('/');
    router.refresh();
  }

  // 登录状态还没查回来之前占位不渲染内容，总比"先闪一下未登录图标、
  // 一秒后又跳成已登录"更不突兀——这一次查询很快，占位时间基本感知不到
  if (!loaded) {
    return <div className="h-11 w-11" aria-hidden="true" />;
  }

  if (!email) {
    return (
      <Link
        href="/login"
        aria-label="登录"
        title="登录"
        className="flex h-11 w-11 items-center justify-center rounded-md transition hover:bg-white/10 hover:text-[var(--accent-color)]"
      >
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
          <circle cx="9" cy="6" r="3" stroke="currentColor" strokeWidth="1.6" />
          <path
            d="M2.5 16c.9-3.2 3.5-5 6.5-5s5.6 1.8 6.5 5"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
        </svg>
      </Link>
    );
  }

  return (
    <div className="flex items-center gap-1">
      <span className="hidden max-w-[10rem] truncate text-sm sm:inline" title={email}>
        {email}
      </span>
      <button
        type="button"
        onClick={handleLogout}
        disabled={loggingOut}
        aria-label="退出登录"
        title="退出登录"
        className="flex h-11 w-11 items-center justify-center rounded-md transition hover:bg-white/10 hover:text-[var(--accent-color)] disabled:opacity-50"
      >
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
          <path
            d="M7 2.5H4a1.5 1.5 0 0 0-1.5 1.5v10A1.5 1.5 0 0 0 4 15.5h3"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M11.5 12.5 15.5 9l-4-3.5"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <line x1="6.5" y1="9" x2="15" y2="9" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      </button>
    </div>
  );
}
