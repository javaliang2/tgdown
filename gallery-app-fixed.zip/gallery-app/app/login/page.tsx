import { Suspense } from 'react';
import LoginForm from './LoginForm';

// LoginForm 里用了 useSearchParams()（读 ?next= 参数），Next.js 要求这种用法
// 必须包一层 Suspense，不然预渲染这个页面时会报错退出构建
export default function LoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  );
}
