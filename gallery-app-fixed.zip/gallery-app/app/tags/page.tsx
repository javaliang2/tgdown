import { getTagCounts } from '@/lib/tags';
import Link from 'next/link';
import type { Metadata } from 'next';
import { tagTextColor } from '@/lib/tag-color';

export const metadata: Metadata = { title: '全部标签', description: '浏览全部图集标签' };
export const revalidate = 3600;

// 按出现次数把字号从 min~max 之间线性插值，出现越多的标签看起来越显眼
function fontSizeFor(count: number, min: number, max: number) {
  if (max === min) return 1.1;
  const ratio = (count - min) / (max - min);
  return 0.85 + ratio * (1.9 - 0.85);
}

export default async function TagsPage() {
  const tagCounts = await getTagCounts(true);
  const counts = tagCounts.map((t) => t.count);
  const min = counts.length ? Math.min(...counts) : 0;
  const max = counts.length ? Math.max(...counts) : 0;

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="mb-6 text-xl">全部标签</h1>

      {tagCounts.length === 0 ? (
        <p className="p-8 text-center text-[var(--fg-50)]">还没有图集打过标签</p>
      ) : (
        <div className="flex flex-wrap items-baseline gap-x-4 gap-y-3">
          {tagCounts.map(({ tag, count }) => (
            <Link
              key={tag}
              href={`/${encodeURIComponent(tag)}`}
              style={{ fontSize: `${fontSizeFor(count, min, max)}rem`, ...tagTextColor(tag) }}
              className="transition hover:opacity-75"
            >
              {tag}
              <span className="ml-1 text-xs text-[var(--fg-40)]">{count}</span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
