import { permanentRedirect } from 'next/navigation';

// 标签详情页已经搬到扁平路径 /标签名（见 app/[slug]/page.tsx）。
// 这里只保留一个 308 永久重定向，兼容外部已经收藏/分享出去的旧链接，
// 别删这个文件，删了老链接直接 404。
// 注意：直接透传 params.tag 这个原始（已经是 URL 编码过的）字符串拼到新地址里，
// 不在这里做 decodeURIComponent 再 encodeURIComponent 的往返，省得因为编码方式不一致产生二次编码的 bug。
export default async function LegacyTagRedirect({ params }: { params: Promise<{ tag: string }> }) {
  const { tag } = await params;
  permanentRedirect(`/${tag}`);
}
