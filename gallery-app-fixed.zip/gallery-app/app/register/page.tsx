'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { validatePasswordStrength } from '@/lib/password';
import TurnstileWidget from '@/app/components/TurnstileWidget';

export default function RegisterPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [website, setWebsite] = useState(''); // 蜜罐字段，真人看不见也不会填
  const [turnstileToken, setTurnstileToken] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  // 表单渲染时刻的时间戳，提交时后端会拿它算距离渲染过了多久——
  // 用 useState 的惰性初始值只在挂载时算一次，不会每次渲染都刷新
  const [formRenderedAt] = useState(() => Date.now());

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');

    if (password !== confirmPassword) {
      setError('两次输入的密码不一致');
      return;
    }
    // 客户端先做一次强度校验，弱密码不用等一趟网络往返才知道
    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      setError(strength.message ?? '密码强度不够');
      return;
    }

    setLoading(true);
    const res = await fetch('/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, turnstileToken, website, formRenderedAt }),
    });
    setLoading(false);

    if (res.ok) {
      router.push('/');
      router.refresh();
    } else {
      const data = await res.json().catch(() => ({}));
      setError(data.error || '注册失败，请重试');
    }
  }

  return (
    <div className="mx-auto max-w-sm px-4 py-24">
      <h1 className="mb-6 text-xl">注册账号</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="email"
          placeholder="邮箱"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          required
          autoComplete="email"
        />
        <input
          type="password"
          placeholder="密码（至少 10 位，需包含字母和数字）"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          required
          autoComplete="new-password"
        />
        <input
          type="password"
          placeholder="确认密码"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          required
          autoComplete="new-password"
        />

        {/* 蜜罐字段：CSS 挪到屏幕外藏起来，真人看不到也不会填，
            很多简单脚本会无脑把所有 input 都填一遍，一填就露馅 */}
        <div
          aria-hidden="true"
          style={{ position: 'absolute', left: '-9999px', top: '-9999px', opacity: 0, pointerEvents: 'none' }}
        >
          <label htmlFor="website">Website</label>
          <input
            id="website"
            name="website"
            type="text"
            tabIndex={-1}
            autoComplete="off"
            value={website}
            onChange={(e) => setWebsite(e.target.value)}
          />
        </div>

        <TurnstileWidget onToken={setTurnstileToken} />

        {error && <p className="text-sm text-red-400">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          style={{ backgroundColor: 'var(--accent-color)' }}
          className="w-full rounded py-2 text-[var(--accent-contrast)] disabled:opacity-50"
        >
          {loading ? '注册中…' : '注册'}
        </button>
      </form>

      <p className="mt-4 text-sm text-[var(--fg-60)]">
        已经有账号？
        <Link href="/login" className="ml-1 underline hover:text-[var(--accent-color)]">
          去登录
        </Link>
      </p>
    </div>
  );
}
