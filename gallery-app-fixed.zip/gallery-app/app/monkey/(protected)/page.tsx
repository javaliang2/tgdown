import { prisma } from '@/lib/db';
import Link from 'next/link';
import Pagination from '@/app/components/Pagination';
import { getPageParams, getTotalPages } from '@/lib/pagination';
import { getCategoryTree, type CategoryNode } from '@/lib/categories';
import AlbumsTable from './AlbumsTable';
import ViewTrendChart from './ViewTrendChart';

export const dynamic = 'force-dynamic'; // 后台不缓存，实时看最新数据

type SearchParams = Promise<{ [key: string]: string | string[] | undefined }>;

// 分类树摊平成"顶级 / 子级"这种带层级前缀的下拉选项列表，批量操作那个 <select> 用得上
function flattenCategoryOptions(tree: CategoryNode[]): { id: string; label: string }[] {
  const options: { id: string; label: string }[] = [];
  for (const top of tree) {
    options.push({ id: top.id, label: top.name });
    for (const child of top.children) {
      options.push({ id: child.id, label: `${top.name} / ${child.name}` });
    }
  }
  return options;
}

export default async function AdminDashboard({ searchParams }: { searchParams: SearchParams }) {
  const sp = await searchParams;
  const { page, skip, take } = getPageParams(sp);

  const [albums, totalCount, categoryTree] = await Promise.all([
    prisma.album.findMany({
      orderBy: { createdAt: 'desc' },
      skip,
      take,
      include: {
        _count: { select: { photos: true } },
        category: { select: { name: true, parent: { select: { name: true } } } },
      },
    }),
    prisma.album.count(),
    getCategoryTree(),
  ]);
  const totalPages = getTotalPages(totalCount);
  const categoryOptions = flattenCategoryOptions(categoryTree);

  const albumRows = albums.map((album) => ({
    id: album.id,
    title: album.title,
    slug: album.slug,
    status: album.status,
    visibility: album.visibility,
    featured: album.featured,
    viewCount: album.viewCount,
    categoryLabel: album.category
      ? `${album.category.parent ? album.category.parent.name + ' / ' : ''}${album.category.name}`
      : null,
    photoCount: album._count.photos,
  }));

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-xl">图集管理</h1>
        <Link
          href="/monkey/albums/new"
          style={{ backgroundColor: 'var(--accent-color)' }}
          className="rounded px-4 py-2 text-center text-sm text-[var(--accent-contrast)]"
        >
          + 新建图集
        </Link>
      </div>

      <ViewTrendChart />

      <AlbumsTable albums={albumRows} categoryOptions={categoryOptions} />

      {albums.length === 0 && totalCount === 0 && (
        <p className="py-8 text-center text-[var(--fg-50)]">还没有图集，点右上角新建一个吧</p>
      )}
      {albums.length === 0 && totalCount > 0 && (
        <p className="py-8 text-center text-[var(--fg-50)]">这一页没有内容了，返回前面看看</p>
      )}

      <Pagination currentPage={page} totalPages={totalPages} basePath="/monkey" />
    </div>
  );
}
