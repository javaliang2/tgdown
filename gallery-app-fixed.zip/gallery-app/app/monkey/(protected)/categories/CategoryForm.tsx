'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

type TopLevelCategory = { id: string; name: string };

export default function CategoryForm({ topLevelCategories }: { topLevelCategories: TopLevelCategory[] }) {
  const router = useRouter();
  const [name, setName] = useState('');
  const [parentId, setParentId] = useState('');
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    const res = await fetch('/api/monkey/categories', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, parentId: parentId || null }),
    });
    setSubmitting(false);
    if (res.ok) {
      setName('');
      router.refresh();
    } else {
      const data = await res.json();
      alert(data.error || '创建失败');
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-2 sm:flex-row">
      <input
        placeholder={parentId ? '子分类名称，比如「纽约」' : '分类名称，比如「城市风景」'}
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
        className="flex-1 rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
      />
      <select
        value={parentId}
        onChange={(e) => setParentId(e.target.value)}
        className="rounded border border-[var(--fg-20)] bg-transparent px-3 py-2 sm:w-48"
      >
        <option value="" className="bg-black">顶级分类</option>
        {topLevelCategories.map((c) => (
          <option key={c.id} value={c.id} className="bg-black">
            归到「{c.name}」下
          </option>
        ))}
      </select>
      <button
        type="submit"
        disabled={submitting || !name}
        style={{ backgroundColor: 'var(--accent-color)' }}
        className="rounded px-4 py-2 text-[var(--accent-contrast)] disabled:opacity-50"
      >
        {submitting ? '创建中…' : '新建'}
      </button>
    </form>
  );
}
