'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

type CategoryOption = { id: string; label: string };

export default function NavLinkForm({ categoryOptions }: { categoryOptions: CategoryOption[] }) {
  const router = useRouter();
  const [mode, setMode] = useState<'category' | 'url'>('category');
  const [label, setLabel] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [url, setUrl] = useState('');
  const [newTab, setNewTab] = useState(false);
  const [sortOrder, setSortOrder] = useState('0');
  const [submitting, setSubmitting] = useState(false);

  const canSubmit = label && (mode === 'category' ? categoryId : url);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    const res = await fetch('/api/monkey/navlinks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        label,
        categoryId: mode === 'category' ? categoryId : null,
        url: mode === 'url' ? url : null,
        newTab,
        sortOrder: Number(sortOrder) || 0,
      }),
    });
    setSubmitting(false);
    if (res.ok) {
      setLabel('');
      setCategoryId('');
      setUrl('');
      setNewTab(false);
      setSortOrder('0');
      router.refresh();
    } else {
      const data = await res.json();
      alert(data.error || '创建失败');
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3 rounded border border-[var(--fg-10)] p-3">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
        <input
          placeholder="菜单文字，比如「风景」"
          value={label}
          onChange={(e) => setLabel(e.target.value)}
          required
          className="flex-1 rounded border border-[var(--fg-20)] bg-transparent px-3 py-2 sm:min-w-[10rem]"
        />
        <input
          type="number"
          placeholder="排序"
          value={sortOrder}
          onChange={(e) => setSortOrder(e.target.value)}
          className="w-20 rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        />
      </div>

      <div className="flex gap-4 text-sm text-[var(--fg-70)]">
        <label className="flex items-center gap-1.5">
          <input
            type="radio"
            checked={mode === 'category'}
            onChange={() => setMode('category')}
            disabled={categoryOptions.length === 0}
          />
          关联分类
        </label>
        <label className="flex items-center gap-1.5">
          <input type="radio" checked={mode === 'url'} onChange={() => setMode('url')} />
          自定义链接
        </label>
      </div>

      {mode === 'category' ? (
        categoryOptions.length > 0 ? (
          <select
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value)}
            className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          >
            <option value="" className="bg-black">
              选一个分类
            </option>
            {categoryOptions.map((c) => (
              <option key={c.id} value={c.id} className="bg-black">
                {c.label}
              </option>
            ))}
          </select>
        ) : (
          <p className="text-sm text-[var(--fg-30)]">还没有分类，先去「分类管理」建一个，或者切到「自定义链接」</p>
        )
      ) : (
        <input
          placeholder="链接，比如 /about 或 https://..."
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        />
      )}

      <div className="flex items-center justify-between">
        <label className="flex items-center gap-1.5 text-sm text-[var(--fg-70)]">
          <input type="checkbox" checked={newTab} onChange={(e) => setNewTab(e.target.checked)} />
          新窗口打开
        </label>
        <button
          type="submit"
          disabled={submitting || !canSubmit}
          style={{ backgroundColor: 'var(--accent-color)' }}
          className="rounded px-4 py-2 text-[var(--accent-contrast)] disabled:opacity-50"
        >
          {submitting ? '创建中…' : '新建'}
        </button>
      </div>
    </form>
  );
}
