'use client';

import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import Link from 'next/link';

type Point = { date: string; views: number };
type TopAlbum = { id: string; title: string; slug: string; viewCount: number };

export default function ViewTrendChartClient({ points, topAlbums }: { points: Point[]; topAlbums: TopAlbum[] }) {
  return (
    <div className="mb-8 grid gap-4 sm:grid-cols-[2fr_1fr]">
      <div className="rounded border border-[var(--fg-10)] p-4">
        <h2 className="mb-3 text-sm text-[var(--fg-60)]">近 30 天浏览趋势</h2>
        <ResponsiveContainer width="100%" height={160}>
          <LineChart data={points} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--fg-10)" />
            {/* interval=4：30 个点里每隔 4 个显示一个横轴标签，不然日期会挤成一团看不清 */}
            <XAxis dataKey="date" tick={{ fontSize: 11, fill: 'var(--fg-50)' }} interval={4} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: 'var(--fg-50)' }} allowDecimals={false} axisLine={false} tickLine={false} width={32} />
            <Tooltip
              contentStyle={{ backgroundColor: 'var(--bg-color)', border: '1px solid var(--fg-20)', fontSize: 12 }}
              labelFormatter={(label) => `${label}`}
              formatter={(value) => [`${value} 次`, '浏览量']}
            />
            <Line type="monotone" dataKey="views" stroke="var(--accent-color)" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="rounded border border-[var(--fg-10)] p-4">
        <h2 className="mb-3 text-sm text-[var(--fg-60)]">浏览量排行</h2>
        {topAlbums.length === 0 ? (
          <p className="text-sm text-[var(--fg-50)]">还没有数据</p>
        ) : (
          <ol className="space-y-2 text-sm">
            {topAlbums.map((album, i) => (
              <li key={album.id} className="flex items-center justify-between gap-2">
                <Link href={`/monkey/albums/${album.id}/edit`} className="truncate hover:text-[var(--text-color)]">
                  {i + 1}. {album.title}
                </Link>
                <span className="shrink-0 text-[var(--fg-50)]">{album.viewCount}</span>
              </li>
            ))}
          </ol>
        )}
      </div>
    </div>
  );
}
