'use client';

import { useEffect, useState, useCallback } from 'react';

type ShareLink = {
  id: string;
  token: string;
  label: string | null;
  expiresAt: string | null;
  revokedAt: string | null;
  createdAt: string;
};

function linkStatus(link: ShareLink): { text: string; className: string } {
  if (link.revokedAt) return { text: '已撤销', className: 'text-[var(--fg-40)]' };
  if (link.expiresAt && new Date(link.expiresAt) < new Date()) return { text: '已过期', className: 'text-[var(--fg-40)]' };
  return { text: '有效', className: 'text-green-500' };
}

export default function ShareLinksPanel({ albumId, albumSlug }: { albumId: string; albumSlug: string }) {
  const [links, setLinks] = useState<ShareLink[] | null>(null);
  const [label, setLabel] = useState('');
  const [expiresInDays, setExpiresInDays] = useState(''); // 空字符串 = 永久有效
  const [creating, setCreating] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const load = useCallback(async () => {
    const res = await fetch(`/api/monkey/albums/${albumId}/share-links`);
    if (res.ok) setLinks(await res.json());
  }, [albumId]);

  useEffect(() => {
    load();
  }, [load]);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setCreating(true);
    try {
      const res = await fetch(`/api/monkey/albums/${albumId}/share-links`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          label: label || undefined,
          expiresInDays: expiresInDays ? Number(expiresInDays) : undefined,
        }),
      });
      if (res.ok) {
        setLabel('');
        setExpiresInDays('');
        await load();
      } else {
        const data = await res.json().catch(() => ({}));
        alert(data.error || '创建分享链接失败');
      }
    } finally {
      setCreating(false);
    }
  }

  async function handleRevoke(linkId: string) {
    if (!confirm('撤销这条分享链接？撤销后带着这个链接的人也打不开这个相册了，不能撤销这个撤销操作。')) return;
    const res = await fetch(`/api/monkey/albums/${albumId}/share-links/${linkId}`, { method: 'DELETE' });
    if (res.ok) await load();
  }

  function shareUrl(token: string) {
    // 直接用当前浏览器的 origin 拼链接，不依赖服务端传下来的站点 URL——
    // 管理员现在访问后台用的是哪个域名，分享出去的链接就该是哪个域名，两者理论上应该一致
    return `${window.location.origin}/${encodeURIComponent(albumSlug)}?token=${token}`;
  }

  async function handleCopy(link: ShareLink) {
    try {
      await navigator.clipboard.writeText(shareUrl(link.token));
      setCopiedId(link.id);
      setTimeout(() => setCopiedId((cur) => (cur === link.id ? null : cur)), 2000);
    } catch {
      alert('复制失败，浏览器不支持自动复制，手动选中链接文字复制吧');
    }
  }

  return (
    <div>
      <h2 className="mb-1 text-sm font-medium">分享链接</h2>
      <p className="mb-4 text-xs text-[var(--fg-50)]">
        不想让对方注册账号的话，生成一条链接发过去，知道链接就能看，不用登录。跟"用户管理"里的账号授权可以同时用，互不影响。
      </p>

      <form onSubmit={handleCreate} className="mb-4 flex flex-col gap-2 sm:flex-row">
        <input
          value={label}
          onChange={(e) => setLabel(e.target.value)}
          placeholder="备注（可选，比如「发给小明家」）"
          className="flex-1 rounded border border-[var(--fg-20)] bg-transparent px-3 py-2 text-sm"
        />
        <input
          type="number"
          min={1}
          value={expiresInDays}
          onChange={(e) => setExpiresInDays(e.target.value)}
          placeholder="有效天数（留空=永久）"
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2 text-sm sm:w-44"
        />
        <button
          type="submit"
          disabled={creating}
          style={{ backgroundColor: 'var(--accent-color)' }}
          className="whitespace-nowrap rounded px-4 py-2 text-sm text-[var(--accent-contrast)] disabled:opacity-50"
        >
          {creating ? '生成中…' : '生成链接'}
        </button>
      </form>

      {links === null ? (
        <p className="text-sm text-[var(--fg-50)]">加载中…</p>
      ) : links.length === 0 ? (
        <p className="text-sm text-[var(--fg-40)]">还没有生成过分享链接</p>
      ) : (
        <ul className="space-y-2">
          {links.map((link) => {
            const status = linkStatus(link);
            const revoked = !!link.revokedAt;
            return (
              <li
                key={link.id}
                className="flex flex-col gap-2 rounded border border-[var(--fg-10)] p-3 text-sm sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="truncate font-medium">{link.label || '（无备注）'}</span>
                    <span className={`text-xs ${status.className}`}>· {status.text}</span>
                  </div>
                  <p className="mt-0.5 truncate text-xs text-[var(--fg-50)]">
                    {link.expiresAt ? `${new Date(link.expiresAt).toLocaleDateString('zh-CN')} 过期` : '永久有效'}
                  </p>
                </div>
                {!revoked && (
                  <div className="flex shrink-0 items-center gap-3 text-xs">
                    <button
                      type="button"
                      onClick={() => handleCopy(link)}
                      className="rounded border border-[var(--fg-20)] px-2.5 py-1 hover:bg-[var(--fg-5)]"
                    >
                      {copiedId === link.id ? '已复制' : '复制链接'}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRevoke(link.id)}
                      className="rounded border border-red-900/50 px-2.5 py-1 text-red-400 hover:bg-red-950/30"
                    >
                      撤销
                    </button>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
