'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { uploadPhoto } from '../../photo-upload';
import TagInput from '../../../TagInput';
import ShareLinksPanel from './ShareLinksPanel';

type Category = { id: string; name: string; parentId: string | null };

type Photo = {
  id: string;
  thumbUrl: string;
  thumbKey: string;
  width: number;
  height: number;
  takenAt: string | null;
  cameraMake: string | null;
  cameraModel: string | null;
  lensModel: string | null;
  focalLength: string | null;
  aperture: string | null;
  shutterSpeed: string | null;
  iso: number | null;
};

type AlbumMeta = {
  id: string;
  slug: string;
  title: string;
  description: string;
  tags: string[];
  status: 'DRAFT' | 'PUBLISHED';
  visibility: 'PUBLIC' | 'PRIVATE';
  categoryId: string;
  parentCategoryId: string;
  coverKey: string;
  featured: boolean;
  scheduledPublishAt: string | null;
};

// datetime-local 输入框要的是本地时间格式 "YYYY-MM-DDTHH:mm"，不能直接用 toISOString()
// （那给出来的是 UTC，会跟用户在输入框里看到的时间对不上）
function isoToDatetimeLocal(iso: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// 把几个 EXIF 字段拼成一行摘要，没有的字段直接跳过（很多截图/转发过的图片没有 EXIF，
// 是正常情况，不是 bug），全部都没有就整行不显示
function formatExifSummary(photo: Photo): string | null {
  const parts = [photo.cameraModel, photo.focalLength, photo.aperture, photo.shutterSpeed, photo.iso ? `ISO${photo.iso}` : null].filter(
    Boolean,
  );
  return parts.length > 0 ? parts.join(' · ') : null;
}

export default function EditAlbumForm({
  album,
  categories,
  initialPhotos,
}: {
  album: AlbumMeta;
  categories: Category[];
  initialPhotos: Photo[];
}) {
  const router = useRouter();

  const [title, setTitle] = useState(album.title);
  const [description, setDescription] = useState(album.description);
  const [tags, setTags] = useState(album.tags);
  const [status, setStatus] = useState(album.status);
  const [visibility, setVisibility] = useState(album.visibility);
  const [parentCategoryId, setParentCategoryId] = useState(album.parentCategoryId);
  const [categoryId, setCategoryId] = useState(album.categoryId);
  const [coverKey, setCoverKey] = useState(album.coverKey);
  const [featured, setFeatured] = useState(album.featured);
  const [scheduledPublishAt, setScheduledPublishAt] = useState(isoToDatetimeLocal(album.scheduledPublishAt));
  const [photos, setPhotos] = useState(initialPhotos);

  const [savingMeta, setSavingMeta] = useState(false);
  const [metaMessage, setMetaMessage] = useState('');
  const [busyPhotoId, setBusyPhotoId] = useState<string | null>(null); // 正在删/排序哪张图，禁用对应按钮
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState('');

  // router.refresh() 之后服务端组件会重新查数据库、传新的 props 下来，这里同步一下本地状态
  useEffect(() => setPhotos(initialPhotos), [initialPhotos]);
  useEffect(() => setCoverKey(album.coverKey), [album.coverKey]);

  async function saveMeta(e: React.FormEvent) {
    e.preventDefault();
    setSavingMeta(true);
    setMetaMessage('');
    const res = await fetch(`/api/monkey/albums/${album.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title,
        description,
        tags,
        status,
        visibility,
        categoryId: categoryId || parentCategoryId || null,
        featured,
        // 空字符串（用户清空了输入框）转成 null，表示"取消定时发布"；
        // 有值就转成 ISO 字符串——datetime-local 输入框给的是本地时间，new Date() 会按本地时区解析
        scheduledPublishAt: scheduledPublishAt ? new Date(scheduledPublishAt).toISOString() : null,
      }),
    });
    setSavingMeta(false);
    if (res.ok) {
      setMetaMessage('已保存');
      router.refresh();
    } else {
      const data = await res.json();
      setMetaMessage(data.error || '保存失败');
    }
  }

  async function handleAddFiles(fileList: FileList | null) {
    const list = Array.from(fileList || []);
    if (list.length === 0) return;
    setUploading(true);
    try {
      const newPhotos = [];
      for (let i = 0; i < list.length; i++) {
        setUploadProgress(`正在上传第 ${i + 1} / ${list.length} 张…`);
        newPhotos.push(await uploadPhoto(list[i], title));
      }
      setUploadProgress('正在保存…');
      const res = await fetch(`/api/monkey/albums/${album.id}/photos`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ photos: newPhotos }),
      });
      if (!res.ok) {
        const data = await res.json();
        alert(data.error || '添加图片失败');
      } else {
        router.refresh();
      }
    } finally {
      setUploading(false);
      setUploadProgress('');
    }
  }

  async function handleDeletePhoto(photoId: string) {
    if (!confirm('删除这张图片？（R2 上的原图和缩略图也会一起删，不能撤销）')) return;
    setBusyPhotoId(photoId);
    const res = await fetch(`/api/monkey/albums/${album.id}/photos/${photoId}`, { method: 'DELETE' });
    setBusyPhotoId(null);
    if (res.ok) {
      router.refresh();
    } else {
      const data = await res.json();
      alert(data.error || '删除失败');
    }
  }

  async function handleSetCover(photo: Photo) {
    setBusyPhotoId(photo.id);
    const res = await fetch(`/api/monkey/albums/${album.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ coverKey: photo.thumbKey }),
    });
    setBusyPhotoId(null);
    if (res.ok) {
      setCoverKey(photo.thumbKey);
      router.refresh();
    } else {
      const data = await res.json();
      alert(data.error || '设置封面失败');
    }
  }

  async function handleReorder(index: number, direction: -1 | 1) {
    const target = index + direction;
    if (target < 0 || target >= photos.length) return;
    const next = [...photos];
    [next[index], next[target]] = [next[target], next[index]];
    setPhotos(next); // 先本地换个位置，手感跟得上，接口失败了再靠 router.refresh() 兜回来

    setBusyPhotoId(photos[index].id);
    const res = await fetch(`/api/monkey/albums/${album.id}/photos/reorder`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ order: next.map((p) => p.id) }),
    });
    setBusyPhotoId(null);
    if (res.ok) {
      router.refresh();
    } else {
      alert('排序保存失败，刷新页面重试');
      router.refresh();
    }
  }

  return (
    <div className="mx-auto max-w-xl px-4 py-8">
      <h1 className="mb-6 text-xl">编辑图集</h1>

      <form onSubmit={saveMeta} className="space-y-4">
        <input
          placeholder="标题"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        />
        <textarea
          placeholder="描述（可选）"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          rows={3}
        />
        <TagInput value={tags} onChange={setTags} />
        <div className="flex flex-col gap-2 sm:flex-row">
          <select
            value={parentCategoryId}
            onChange={(e) => {
              setParentCategoryId(e.target.value);
              setCategoryId('');
            }}
            className="flex-1 rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          >
            <option value="" className="bg-black">选择大类</option>
            {categories
              .filter((c) => !c.parentId)
              .map((c) => (
                <option key={c.id} value={c.id} className="bg-black">
                  {c.name}
                </option>
              ))}
          </select>
          <select
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value)}
            disabled={!parentCategoryId}
            className="flex-1 rounded border border-[var(--fg-20)] bg-transparent px-3 py-2 disabled:opacity-40"
          >
            <option value="" className="bg-black">
              {parentCategoryId ? '不选子分类（直接挂在大类下）' : '先选大类'}
            </option>
            {categories
              .filter((c) => c.parentId === parentCategoryId)
              .map((c) => (
                <option key={c.id} value={c.id} className="bg-black">
                  {c.name}
                </option>
              ))}
          </select>
        </div>
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value as 'DRAFT' | 'PUBLISHED')}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        >
          <option value="PUBLISHED" className="bg-black">已发布</option>
          <option value="DRAFT" className="bg-black">草稿（前台不可见）</option>
        </select>
        <select
          value={visibility}
          onChange={(e) => setVisibility(e.target.value as 'PUBLIC' | 'PRIVATE')}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        >
          <option value="PUBLIC" className="bg-black">
            公开（所有人可见）
          </option>
          <option value="PRIVATE" className="bg-black">
            私密（封面正常展示，照片内容需要在"用户管理"里单独授权才能看）
          </option>
        </select>

        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={featured} onChange={(e) => setFeatured(e.target.checked)} />
          首页置顶（跟发布时间无关，手动挑选想放在前面的图集）
        </label>

        <div>
          <label className="mb-1 block text-sm text-[var(--fg-60)]">
            定时发布（可选，留空 = 不定时，用上面"已发布/草稿"直接控制）
          </label>
          <div className="flex items-center gap-2">
            <input
              type="datetime-local"
              value={scheduledPublishAt}
              onChange={(e) => setScheduledPublishAt(e.target.value)}
              className="flex-1 rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
            />
            {scheduledPublishAt && (
              <button
                type="button"
                onClick={() => setScheduledPublishAt('')}
                className="rounded border border-[var(--fg-20)] px-3 py-2 text-sm text-[var(--fg-60)] hover:bg-[var(--fg-5)]"
              >
                清除
              </button>
            )}
          </div>
          {scheduledPublishAt && status === 'PUBLISHED' && (
            <p className="mt-1 text-xs text-amber-400">
              状态目前是"已发布"，设了定时发布时间也不会生效——先把上面状态改成"草稿"，
              定时脚本只处理草稿状态的图集。
            </p>
          )}
        </div>

        <div className="flex items-center gap-3">
          <button
            type="submit"
            disabled={savingMeta || !title}
            style={{ backgroundColor: 'var(--accent-color)' }}
            className="rounded px-4 py-2 text-sm text-[var(--accent-contrast)] disabled:opacity-50"
          >
            {savingMeta ? '保存中…' : '保存修改'}
          </button>
          {metaMessage && <span className="text-sm text-[var(--fg-50)]">{metaMessage}</span>}
        </div>
      </form>

      {visibility === 'PRIVATE' && (
        <div className="mt-8 border-t border-[var(--fg-10)] pt-6">
          <ShareLinksPanel albumId={album.id} albumSlug={album.slug} />
        </div>
      )}

      <div className="mt-10 border-t border-[var(--fg-10)] pt-6">
        <p className="mb-2 text-sm text-[var(--fg-50)]">
          点图片设为封面；用左右箭头调整顺序；每张图旁边可以单独删除。改动是立即生效的，不用点"保存修改"。
        </p>
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
          {photos.map((photo, i) => {
            const busy = busyPhotoId === photo.id;
            const isCover = photo.thumbKey === coverKey;
            return (
              <div key={photo.id} className="space-y-1">
                <button
                  type="button"
                  onClick={() => handleSetCover(photo)}
                  disabled={busy}
                  style={isCover ? { boxShadow: '0 0 0 2px var(--accent-color)' } : undefined}
                  className="relative block aspect-square w-full overflow-hidden rounded bg-[var(--fg-5)] disabled:opacity-50"
                  title="设为封面"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={photo.thumbUrl} alt="" className="h-full w-full object-cover" />
                  {isCover && (
                    <span className="absolute bottom-1 left-1 rounded bg-[var(--accent-color)] px-1.5 py-0.5 text-[10px] text-[var(--accent-contrast)]">
                      封面
                    </span>
                  )}
                </button>
                <div className="flex items-center justify-between text-xs text-[var(--fg-50)]">
                  <div className="flex gap-1">
                    <button
                      type="button"
                      onClick={() => handleReorder(i, -1)}
                      disabled={busy || i === 0}
                      className="rounded px-1.5 py-0.5 hover:bg-[var(--fg-10)] disabled:opacity-30"
                    >
                      ←
                    </button>
                    <button
                      type="button"
                      onClick={() => handleReorder(i, 1)}
                      disabled={busy || i === photos.length - 1}
                      className="rounded px-1.5 py-0.5 hover:bg-[var(--fg-10)] disabled:opacity-30"
                    >
                      →
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleDeletePhoto(photo.id)}
                    disabled={busy}
                    className="rounded px-1.5 py-0.5 text-red-400 hover:bg-[var(--fg-10)] disabled:opacity-30"
                  >
                    删除
                  </button>
                </div>
                {formatExifSummary(photo) && (
                  <p className="truncate text-[10px] text-[var(--fg-40)]" title={formatExifSummary(photo)!}>
                    {formatExifSummary(photo)}
                  </p>
                )}
              </div>
            );
          })}
        </div>
        {photos.length === 0 && (
          <p className="py-6 text-center text-sm text-[var(--fg-30)]">这个图集还没有图片</p>
        )}

        <div className="mt-4">
          <input
            type="file"
            accept="image/*"
            multiple
            disabled={uploading}
            onChange={(e) => {
              handleAddFiles(e.target.files);
              e.target.value = ''; // 清空，方便再选同一批文件重新加
            }}
            className="w-full text-sm"
          />
          {uploading && <p className="mt-1 text-xs text-[var(--fg-50)]">{uploadProgress || '上传中…'}</p>}
        </div>
      </div>
    </div>
  );
}
