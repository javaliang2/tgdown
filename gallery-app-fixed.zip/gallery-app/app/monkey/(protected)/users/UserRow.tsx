'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

type PrivateAlbum = { id: string; title: string; slug: string };
type UserData = { id: string; email: string; createdAt: string; authorizedAlbumIds: string[] };

export default function UserRow({ user, privateAlbums }: { user: UserData; privateAlbums: PrivateAlbum[] }) {
  const router = useRouter();
  const [expanded, setExpanded] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set(user.authorizedAlbumIds));
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const dirty =
    selected.size !== user.authorizedAlbumIds.length ||
    user.authorizedAlbumIds.some((id) => !selected.has(id));

  function toggle(albumId: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(albumId)) {
        next.delete(albumId);
      } else {
        next.add(albumId);
      }
      return next;
    });
  }

  async function handleSave() {
    setSaving(true);
    const res = await fetch(`/api/monkey/users/${user.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ albumIds: Array.from(selected) }),
    });
    setSaving(false);
    if (res.ok) {
      router.refresh();
    } else {
      alert('保存失败，重试一下');
    }
  }

  async function handleDelete() {
    if (!confirm(`确定要删除用户 ${user.email} 吗？这个操作不可撤销，这个用户会立刻登出、失去所有访问权限。`)) {
      return;
    }
    setDeleting(true);
    const res = await fetch(`/api/monkey/users/${user.id}`, { method: 'DELETE' });
    setDeleting(false);
    if (res.ok) {
      router.refresh();
    } else {
      alert('删除失败，重试一下');
    }
  }

  return (
    <div className="py-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <p className="text-sm">{user.email}</p>
          <p className="text-xs text-[var(--fg-40)]">
            {new Date(user.createdAt).toLocaleDateString('zh-CN')} 注册 · 已授权 {user.authorizedAlbumIds.length}{' '}
            个私密相册
          </p>
        </div>
        <div className="flex items-center gap-3 text-sm">
          <button
            type="button"
            onClick={() => setExpanded((v) => !v)}
            className="text-[var(--fg-60)] hover:text-[var(--accent-color)]"
          >
            {expanded ? '收起' : '管理授权'}
          </button>
          <button
            type="button"
            onClick={handleDelete}
            disabled={deleting}
            className="text-red-400 hover:text-red-300 disabled:opacity-50"
          >
            {deleting ? '删除中…' : '删除用户'}
          </button>
        </div>
      </div>

      {expanded && (
        <div className="mt-3 rounded border border-[var(--fg-10)] bg-[var(--fg-5)] p-3">
          {privateAlbums.length === 0 ? (
            <p className="text-sm text-[var(--fg-50)]">
              还没有任何私密相册——去图集管理里把某个相册的可见性改成"私密"，就会出现在这里可以勾选授权了。
            </p>
          ) : (
            <>
              <div className="mb-2 flex items-center justify-between border-b border-[var(--fg-10)] pb-2">
                <label className="flex cursor-pointer items-center gap-2 text-sm text-[var(--fg-60)]">
                  <input
                    type="checkbox"
                    checked={selected.size === privateAlbums.length}
                    ref={(el) => {
                      if (el) el.indeterminate = selected.size > 0 && selected.size < privateAlbums.length;
                    }}
                    onChange={() => {
                      setSelected(
                        selected.size === privateAlbums.length
                          ? new Set()
                          : new Set(privateAlbums.map((a) => a.id))
                      );
                    }}
                    className="h-4 w-4"
                  />
                  全选（{selected.size}/{privateAlbums.length}）
                </label>
              </div>
              <div className="space-y-1.5">
                {privateAlbums.map((album) => (
                  <label
                    key={album.id}
                    className="flex cursor-pointer items-center gap-2 rounded px-1.5 py-1 text-sm hover:bg-[var(--fg-10)]"
                  >
                    <input
                      type="checkbox"
                      checked={selected.has(album.id)}
                      onChange={() => toggle(album.id)}
                      className="h-4 w-4"
                    />
                    {album.title}
                  </label>
                ))}
              </div>
              <button
                type="button"
                onClick={handleSave}
                disabled={!dirty || saving}
                style={dirty ? { backgroundColor: 'var(--accent-color)' } : undefined}
                className="mt-3 rounded px-3 py-1.5 text-sm text-[var(--accent-contrast)] disabled:cursor-default disabled:bg-[var(--fg-10)] disabled:text-[var(--fg-40)]"
              >
                {saving ? '保存中…' : dirty ? '保存修改' : '没有改动'}
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}
