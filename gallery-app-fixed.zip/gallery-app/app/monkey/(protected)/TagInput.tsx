'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { tagBadgeStyle, tagDotColor } from '@/lib/tag-color';

type Option = { label: string; isNew: boolean };

// 标签输入框：chip + 自动补全下拉。
// - 已有标签列表只在组件挂载时拉一次（GET /api/monkey/tags，后台口径，含草稿上的标签），
//   后台标签总量不大，没必要做防抖搜索请求，本地过滤就够了。
// - 输入匹配不到任何已有标签时，下拉列表末尾会多一项"创建新标签 xxx"，
//   回车/点击都能直接把它当成新标签加进去——实际是否落库建 Tag 行由提交表单时后端的
//   connectOrCreate 决定，这里只是纯前端的输入体验。
export default function TagInput({
  value,
  onChange,
  placeholder,
}: {
  value: string[];
  onChange: (tags: string[]) => void;
  placeholder?: string;
}) {
  const [allTags, setAllTags] = useState<string[]>([]);
  const [input, setInput] = useState('');
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetch('/api/monkey/tags')
      .then((r) => r.json())
      .then((rows: { tag: string }[]) => setAllTags(rows.map((r) => r.tag)))
      .catch(() => {});
  }, []);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const options = useMemo<Option[]>(() => {
    const q = input.trim();
    const ql = q.toLowerCase();
    const existing = allTags
      .filter((t) => !value.some((v) => v.toLowerCase() === t.toLowerCase()))
      .filter((t) => !ql || t.toLowerCase().includes(ql))
      .slice(0, 8)
      .map((t) => ({ label: t, isNew: false }));

    const alreadyHasExactMatch =
      !q ||
      allTags.some((t) => t.toLowerCase() === ql) ||
      value.some((v) => v.toLowerCase() === ql);

    return alreadyHasExactMatch ? existing : [...existing, { label: q, isNew: true }];
  }, [allTags, value, input]);

  // 选项数量变化时（比如从 9 个过滤到 2 个）把高亮索引夹回合法范围，不然会指向不存在的项
  useEffect(() => {
    setActiveIndex((i) => Math.min(i, Math.max(options.length - 1, 0)));
  }, [options.length]);

  function addTag(name: string) {
    const trimmed = name.trim();
    if (!trimmed) return;
    if (value.some((t) => t.toLowerCase() === trimmed.toLowerCase())) {
      setInput('');
      return;
    }
    onChange([...value, trimmed]);
    setInput('');
    setActiveIndex(0);
  }

  function removeTag(name: string) {
    onChange(value.filter((t) => t !== name));
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setOpen(true);
      setActiveIndex((i) => Math.min(i + 1, options.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveIndex((i) => Math.max(i - 1, 0));
    } else if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      if (open && options[activeIndex]) {
        addTag(options[activeIndex].label);
      } else if (input.trim()) {
        addTag(input);
      }
    } else if (e.key === 'Backspace' && input === '' && value.length > 0) {
      removeTag(value[value.length - 1]);
    } else if (e.key === 'Escape') {
      setOpen(false);
    }
  }

  return (
    <div ref={containerRef} className="relative">
      <div
        onClick={() => inputRef.current?.focus()}
        className="flex flex-wrap items-center gap-1.5 rounded border border-[var(--fg-20)] bg-transparent px-2 py-1.5 focus-within:border-[var(--fg-40)]"
      >
        {value.map((tag) => (
          <span
            key={tag}
            style={tagBadgeStyle(tag)}
            className="flex items-center gap-1 rounded-full px-2.5 py-1 text-xs"
          >
            {tag}
            <button
              type="button"
              onClick={() => removeTag(tag)}
              aria-label={`移除标签 ${tag}`}
              className="leading-none opacity-60 hover:opacity-100"
            >
              ×
            </button>
          </span>
        ))}
        <input
          ref={inputRef}
          value={input}
          onChange={(e) => {
            setInput(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          onKeyDown={handleKeyDown}
          placeholder={value.length === 0 ? (placeholder ?? '输入标签名，回车确认') : ''}
          className="min-w-[8ch] flex-1 bg-transparent px-1 py-1 text-sm text-[var(--text-color)] outline-none placeholder:text-[var(--fg-30)]"
        />
      </div>

      {open && options.length > 0 && (
        <ul className="absolute z-10 mt-1 max-h-56 w-full overflow-auto rounded border border-[var(--fg-20)] bg-[var(--bg-color)] py-1 shadow-lg">
          {options.map((opt, i) => (
            <li key={`${opt.label}:${opt.isNew}`}>
              <button
                type="button"
                // mousedown 而不是 click：防止先触发 input 的 blur 把下拉收起来，导致点击落空
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => addTag(opt.label)}
                className={`flex w-full items-center justify-between px-3 py-1.5 text-left text-sm text-[var(--text-color)] hover:bg-[var(--fg-10)] ${
                  i === activeIndex ? 'bg-[var(--fg-10)]' : ''
                }`}
              >
                <span className="flex items-center gap-2">
                  {!opt.isNew && (
                    <span aria-hidden style={tagDotColor(opt.label)} className="inline-block h-2 w-2 rounded-full" />
                  )}
                  <span>{opt.label}</span>
                </span>
                {opt.isNew && <span className="text-xs text-[var(--fg-40)]">创建新标签</span>}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
