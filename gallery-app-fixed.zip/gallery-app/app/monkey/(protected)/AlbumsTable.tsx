'use client';

import { useRouter } from 'next/navigation';
import { useState, useMemo } from 'react';
import Link from 'next/link';
import DeleteButton from './DeleteButton';

type AlbumRow = {
  id: string;
  title: string;
  slug: string;
  status: string;
  visibility: string;
  featured: boolean;
  viewCount: number;
  categoryLabel: string | null;
  photoCount: number;
};

type CategoryOption = { id: string; label: string };

// 图集列表 + 多选批量操作。原来这部分是纯服务端渲染的静态表格，改成客户端组件是因为
// 批量操作本身需要"哪些行被选中"这份客户端状态——数据本身还是服务端 page.tsx 一次性
// 查好传进来，这个组件不自己发请求拉列表，只在执行完批量操作之后调 router.refresh()
// 让服务端重新查一次最新数据，不用自己维护一份"跟服务端对不上"的本地列表状态。
export default function AlbumsTable({
  albums,
  categoryOptions,
}: {
  albums: AlbumRow[];
  categoryOptions: CategoryOption[];
}) {
  const router = useRouter();
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [pending, setPending] = useState(false);

  const allSelected = albums.length > 0 && albums.every((a) => selected.has(a.id));

  function toggleOne(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function toggleAll() {
    setSelected((prev) => (allSelected ? new Set() : new Set(albums.map((a) => a.id))));
  }

  async function runBulk(action: string, value?: unknown, confirmMessage?: string) {
    if (selected.size === 0) return;
    if (confirmMessage && !confirm(confirmMessage)) return;

    setPending(true);
    try {
      const res = await fetch('/api/monkey/albums/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: Array.from(selected), action, value }),
      });
      if (!res.ok) {
        const { error } = await res.json().catch(() => ({ error: '操作失败' }));
        alert(error || '操作失败');
        return;
      }
      setSelected(new Set());
      router.refresh();
    } finally {
      setPending(false);
    }
  }

  const categorySelectId = useMemo(() => 'bulk-category-select', []);

  return (
    <div>
      {/* 批量操作条：没选中任何行时不占地方，选中了才浮出来，不干扰平时浏览列表 */}
      {selected.size > 0 && (
        <div className="sticky top-0 z-10 mb-3 flex flex-wrap items-center gap-2 rounded border border-[var(--fg-20)] bg-[var(--bg-color)] px-3 py-2 text-sm shadow-sm">
          <span className="mr-1 text-[var(--fg-60)]">已选 {selected.size} 个</span>

          <button
            disabled={pending}
            onClick={() => runBulk('setVisibility', 'PUBLIC')}
            className="rounded border border-[var(--fg-20)] px-2.5 py-1 hover:bg-[var(--fg-5)] disabled:opacity-50"
          >
            设为公开
          </button>
          <button
            disabled={pending}
            onClick={() => runBulk('setVisibility', 'PRIVATE')}
            className="rounded border border-[var(--fg-20)] px-2.5 py-1 hover:bg-[var(--fg-5)] disabled:opacity-50"
          >
            设为私密
          </button>
          <button
            disabled={pending}
            onClick={() => runBulk('setFeatured', true)}
            className="rounded border border-[var(--fg-20)] px-2.5 py-1 hover:bg-[var(--fg-5)] disabled:opacity-50"
          >
            加入置顶
          </button>
          <button
            disabled={pending}
            onClick={() => runBulk('setFeatured', false)}
            className="rounded border border-[var(--fg-20)] px-2.5 py-1 hover:bg-[var(--fg-5)] disabled:opacity-50"
          >
            取消置顶
          </button>

          <label htmlFor={categorySelectId} className="sr-only">
            批量设置分类
          </label>
          <select
            id={categorySelectId}
            disabled={pending}
            defaultValue=""
            onChange={(e) => {
              const val = e.target.value;
              runBulk('setCategory', val || null);
              e.target.value = '';
            }}
            className="rounded border border-[var(--fg-20)] bg-transparent px-2 py-1 disabled:opacity-50"
          >
            <option value="" disabled>
              批量设为分类…
            </option>
            <option value="">（清空分类）</option>
            {categoryOptions.map((c) => (
              <option key={c.id} value={c.id}>
                {c.label}
              </option>
            ))}
          </select>

          <button
            disabled={pending}
            onClick={() => runBulk('delete', undefined, `确定要删除选中的 ${selected.size} 个图集吗？这个操作不可撤销。`)}
            className="ml-auto rounded border border-red-900/50 px-2.5 py-1 text-red-400 hover:bg-red-950/30 disabled:opacity-50"
          >
            批量删除
          </button>
        </div>
      )}

      {/* 窄屏：卡片列表 */}
      <div className="space-y-3 sm:hidden">
        {albums.map((album) => (
          <div key={album.id} className="rounded border border-[var(--fg-10)] p-4">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-start gap-2">
                <input
                  type="checkbox"
                  checked={selected.has(album.id)}
                  onChange={() => toggleOne(album.id)}
                  className="mt-1"
                  aria-label={`选中 ${album.title}`}
                />
                <div>
                  <p className="font-medium">
                    {album.featured && <span title="首页置顶">★ </span>}
                    {album.title}
                  </p>
                  <p className="mt-1 text-xs text-[var(--fg-50)]">{album.categoryLabel ?? '未分类'}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                {album.status === 'PUBLISHED' && (
                  <a
                    href={`/${album.slug}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[var(--fg-50)] hover:text-[var(--text-color)]"
                  >
                    预览
                  </a>
                )}
                <Link href={`/monkey/albums/${album.id}/edit`} className="text-[var(--fg-50)] hover:text-[var(--text-color)]">
                  编辑
                </Link>
                <DeleteButton id={album.id} />
              </div>
            </div>
            <div className="mt-3 flex gap-4 text-xs text-[var(--fg-50)]">
              <span>{album.status === 'PUBLISHED' ? '已发布' : '草稿'}</span>
              {album.visibility === 'PRIVATE' && <span className="text-amber-400">私密</span>}
              <span>{album.photoCount} 张图片</span>
              <span>{album.viewCount} 次浏览</span>
            </div>
          </div>
        ))}
      </div>

      {/* 宽屏：表格 */}
      <table className="hidden w-full text-left text-sm sm:table">
        <thead className="border-b border-[var(--fg-20)] text-[var(--fg-50)]">
          <tr>
            <th className="w-8 py-2">
              <input
                type="checkbox"
                checked={allSelected}
                onChange={toggleAll}
                aria-label="全选本页"
              />
            </th>
            <th>标题</th>
            <th>分类</th>
            <th>状态</th>
            <th>图片数</th>
            <th>浏览量</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {albums.map((album) => (
            <tr key={album.id} className="border-b border-[var(--fg-10)]">
              <td className="py-3">
                <input
                  type="checkbox"
                  checked={selected.has(album.id)}
                  onChange={() => toggleOne(album.id)}
                  aria-label={`选中 ${album.title}`}
                />
              </td>
              <td>
                {album.featured && <span title="首页置顶">★ </span>}
                {album.title}
              </td>
              <td className="text-[var(--fg-60)]">{album.categoryLabel ?? '—'}</td>
              <td>
                {album.status === 'PUBLISHED' ? '已发布' : '草稿'}
                {album.visibility === 'PRIVATE' && <span className="ml-1.5 text-amber-400">· 私密</span>}
              </td>
              <td>{album.photoCount}</td>
              <td>{album.viewCount}</td>
              <td className="text-right">
                <div className="flex items-center justify-end gap-3">
                  {album.status === 'PUBLISHED' && (
                    <a
                      href={`/${album.slug}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[var(--fg-50)] hover:text-[var(--text-color)]"
                    >
                      预览
                    </a>
                  )}
                  <Link href={`/monkey/albums/${album.id}/edit`} className="text-[var(--fg-50)] hover:text-[var(--text-color)]">
                    编辑
                  </Link>
                  <DeleteButton id={album.id} />
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
