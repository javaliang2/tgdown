import { getTagCounts } from '@/lib/tags';
import TagRow from './TagRow';

export const dynamic = 'force-dynamic';

export default async function TagsAdminPage() {
  const tagCounts = await getTagCounts(false);

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="mb-2 text-xl">标签管理</h1>
      <p className="mb-6 text-sm text-[var(--fg-50)]">
        标签是在每个图集的编辑页面里手动打的，这里只能重命名、合并、删除已经存在的标签，
        新增标签还是要去对应图集的编辑页面里加。
      </p>

      {tagCounts.length === 0 ? (
        <p className="py-8 text-center text-[var(--fg-50)]">还没有图集打过标签</p>
      ) : (
        <div className="divide-y divide-[var(--fg-10)]">
          {tagCounts.map(({ tag, count }) => (
            <TagRow
              key={tag}
              tag={tag}
              count={count}
              allTags={tagCounts.map((t) => t.tag)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
