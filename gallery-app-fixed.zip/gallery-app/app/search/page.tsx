import { prisma } from '@/lib/db';
import type { Metadata } from 'next';
import Pagination from '@/app/components/Pagination';
import AlbumCard from '@/app/components/AlbumCard';
import { getPageParams, getTotalPages } from '@/lib/pagination';

export const metadata: Metadata = {
  title: '搜索',
  // 搜索结果页对应无数种 ?q= 组合，内容跟别的页面高度重复，属于典型的"薄内容"，
  // 统一 noindex；follow 保留，链接权重照样能传到搜到的图集页
  robots: { index: false, follow: true },
};

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const params = await searchParams;
  const q = typeof params.q === 'string' ? params.q.trim() : '';
  // titlePinyin 里全拼部分是连写的（"meihua"，没有音节间空格），用户搜索时如果习惯性
  // 打了空格（"mei hua"）要先去掉再比较，不然明明该搜到的会因为多了空格搜不到
  const qForPinyin = q.replace(/\s+/g, '');
  const { page, skip, take } = getPageParams(params);

  const searchWhere = {
    status: 'PUBLISHED' as const,
    OR: [
      { title: { contains: q, mode: 'insensitive' as const } },
      { titlePinyin: { contains: qForPinyin, mode: 'insensitive' as const } },
      { description: { contains: q, mode: 'insensitive' as const } },
      { tags: { some: { name: q } } },
    ],
  };

  const [rawAlbums, totalCount] = q
    ? await Promise.all([
        prisma.album.findMany({
          where: searchWhere,
          orderBy: { publishedAt: 'desc' },
          skip,
          take,
          select: {
            title: true,
            slug: true,
            coverKey: true,
            coverBlurDataURL: true,
            visibility: true,
            tags: { select: { name: true } },
          },
        }),
        prisma.album.count({ where: searchWhere }),
      ])
    : [[], 0];

  const albums = rawAlbums.map((a) => ({ ...a, tags: a.tags.map((t) => t.name) }));
  const totalPages = getTotalPages(totalCount);

  return (
    <div>
      <form action="/search" className="px-4 py-6">
        <div className="mx-auto flex max-w-xl items-center gap-2 rounded-full border border-[var(--fg-10)] px-4 py-2.5">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true" className="shrink-0 text-[var(--fg-50)]">
            <circle cx="8" cy="8" r="5.5" stroke="currentColor" strokeWidth="1.6" />
            <line x1="12.2" y1="12.2" x2="16" y2="16" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          </svg>
          <input
            type="text"
            name="q"
            defaultValue={q}
            placeholder="搜索图集标题、简介或标签"
            autoFocus
            className="min-w-0 flex-1 bg-transparent text-sm text-[var(--text-color)] outline-none placeholder:text-[var(--fg-30)]"
          />
        </div>
      </form>

      {q ? (
        <>
          <div className="grid grid-cols-2 gap-x-1 gap-y-3 p-1 sm:grid-cols-3 md:grid-cols-4">
            {albums.map((album, index) => (
              <AlbumCard key={album.slug} album={album} priority={index === 0} />
            ))}
            {albums.length === 0 && (
              <p className="col-span-full p-8 text-center text-[var(--fg-50)]">没找到和"{q}"相关的图集</p>
            )}
          </div>

          <Pagination currentPage={page} totalPages={totalPages} basePath="/search" extraParams={{ q }} />
        </>
      ) : (
        <p className="p-8 text-center text-[var(--fg-50)]">输入关键词看看有没有相关的图集</p>
      )}
    </div>
  );
}
