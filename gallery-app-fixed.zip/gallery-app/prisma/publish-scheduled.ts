// 用法（本地开发）: npx tsx prisma/publish-scheduled.ts
// 生产环境（Docker）里跑的是构建时编译出来的 prisma/publish-scheduled.cjs，
// 见 Dockerfile 里 esbuild 那一步，运行时容器不装 tsx，改这个文件不用管编译产物，
// 重新 build 镜像时会自动重新编译。
//
// 配合 cron 定期跑（README「定时发布」那节有 crontab 示例）：找出 status = DRAFT 且
// scheduledPublishAt 已经到期的图集，转成 PUBLISHED，然后广播一条缓存失效消息，
// 让所有正在运行的节点尽快刷新首页/该图集详情页的静态缓存——不这么做的话要等
// revalidate 的自然间隔（比如 1 小时）才会刷新，等于"定时发布"实际对外可见的时间
// 比设置的时间晚了一截，达不到"定时"的意义。
//
// 不在这里直接 import next/cache 的 revalidatePath——这个脚本是独立进程跑的，
// 不在 Next.js 请求上下文里，revalidatePath 这类 API 依赖那套上下文才能正常工作。
// 直接手动 publish 到 Redis 的这个频道，跟 lib/cache-broadcast.ts 用的是同一个
// 频道名，由每个正在运行的 web 进程（订阅了这个频道）负责真正调用 revalidatePath。
// 没配 REDIS_URL（单节点部署）的话就跳过广播——单节点场景下这条广播本来也没有
// 别的节点可以收，Next.js 自己的 revalidate 间隔到了自然会刷新。
import { PrismaClient } from '@prisma/client';
import { redis } from '../lib/redis';

const prisma = new PrismaClient();
const CACHE_INVALIDATE_CHANNEL = 'gallery:cache-invalidate';

async function main() {
  const due = await prisma.album.findMany({
    where: { status: 'DRAFT', scheduledPublishAt: { lte: new Date() } },
    select: { id: true, slug: true },
  });

  if (due.length === 0) {
    console.log('[publish-scheduled] 没有到期的定时发布图集');
    return;
  }

  await prisma.album.updateMany({
    where: { id: { in: due.map((a) => a.id) } },
    data: { status: 'PUBLISHED', publishedAt: new Date(), scheduledPublishAt: null },
  });

  console.log(`[publish-scheduled] 发布了 ${due.length} 个图集: ${due.map((a) => a.slug).join(', ')}`);

  if (redis) {
    const paths = [{ path: '/' }, ...due.map((a) => ({ path: `/${a.slug}` }))];
    try {
      await redis.publish(CACHE_INVALIDATE_CHANNEL, JSON.stringify({ paths }));
    } catch (err) {
      // 图集已经发布成功了，广播失败顶多是缓存要多等一会儿自然过期才刷新，不算严重故障
      console.error('[publish-scheduled] 广播缓存失效失败:', err);
    }
  }
}

main()
  .catch((err) => {
    console.error('[publish-scheduled] 执行失败:', err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
    // ioredis 的连接会一直挂着不让进程自然退出，用完手动断开，
    // 不然 cron 跑的这个脚本会一直挂在后台退不出去
    redis?.disconnect();
  });
