// 用法（本地开发）: npx tsx prisma/backfill-title-pinyin.ts
// 生产环境（Docker）里跑的是构建时编译出来的 prisma/backfill-title-pinyin.cjs，
// 见 Dockerfile 里 esbuild 那一步，运行时容器不装 tsx，改这个文件不用管编译产物，
// 重新 build 镜像时会自动重新编译。
//
// 迁移 20260801000000_title_pinyin 只是加了 titlePinyin 这一列（默认空字符串），
// 加列本身没法用纯 SQL 把已有图集的拼音值算出来——拼音转换是 JS 里 pinyin-pro 做的事，
// 数据库不知道怎么算。所以拆成两步：迁移负责加列建索引，这个脚本负责一次性把
// 所有已存在的图集的 titlePinyin 补上实际值。加了新迁移之后跑一次就行，
// 之后新建/编辑图集时 app/api/monkey/albums 这两个路由会在写入时自动算好，不需要再跑这个脚本。
//
// 部署时机：docker compose exec web node prisma/backfill-title-pinyin.cjs
// 在 `prisma migrate deploy` 跑完、应用重新启动之后执行一次即可，重复执行也没问题（幂等）。
import { PrismaClient } from '@prisma/client';
import { toTitlePinyin } from '../lib/pinyin';

const prisma = new PrismaClient();

async function main() {
  const albums = await prisma.album.findMany({ select: { id: true, title: true } });

  if (albums.length === 0) {
    console.log('[backfill-title-pinyin] 没有图集，跳过');
    return;
  }

  let updated = 0;
  for (const album of albums) {
    await prisma.album.update({
      where: { id: album.id },
      data: { titlePinyin: toTitlePinyin(album.title) },
    });
    updated += 1;
  }

  console.log(`[backfill-title-pinyin] 已回填 ${updated} 个图集的拼音搜索字段`);
}

main()
  .catch((err) => {
    console.error('[backfill-title-pinyin] 执行失败:', err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
