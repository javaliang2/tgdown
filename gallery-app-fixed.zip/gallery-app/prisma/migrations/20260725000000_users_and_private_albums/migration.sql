-- 前台用户注册登录 + 私密相册授权访问，这一版是纯数据层改动，不改变任何现有行为：
-- 所有现存图集迁移后 visibility 默认是 PUBLIC，跟没加这个字段之前表现完全一样。
-- 这个迁移只搭地基（User 表、Album.visibility、两者的多对多关系），
-- 权限校验的实际逻辑在后面几轮加接口/页面的时候才会用到这些新增的表和字段。

-- 1) Album 加可见性字段 -----------------------------------------------------

CREATE TYPE "AlbumVisibility" AS ENUM ('PUBLIC', 'PRIVATE');

ALTER TABLE "Album" ADD COLUMN "visibility" "AlbumVisibility" NOT NULL DEFAULT 'PUBLIC';

-- 公开列表类查询（首页/分类/标签/搜索/sitemap）几乎总是同时按 status 和 visibility 过滤、
-- 再按 publishedAt 排序，把原来的 (status, publishedAt) 索引换成跟这个查询模式对齐的三列索引
DROP INDEX "Album_status_publishedAt_idx";
CREATE INDEX "Album_status_visibility_publishedAt_idx" ON "Album"("status", "visibility", "publishedAt");

-- 2) 前台用户表 --------------------------------------------------------------
-- 字段结构照抄 AdminUser（同一套失败次数锁定 + bcrypt 哈希的安全模型），
-- 但完全是独立的一张表——用户和管理员任何时候都不能共用同一套 session/权限判断。

CREATE TABLE "User" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "passwordHash" TEXT NOT NULL,
    "failedAttempts" INTEGER NOT NULL DEFAULT 0,
    "lockedUntil" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- 3) Album <-> User 的私密相册授权关系（隐式多对多，跟 Tag<->Album 是同一个套路） -----

CREATE TABLE "_AlbumToUser" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL
);

CREATE UNIQUE INDEX "_AlbumToUser_AB_unique" ON "_AlbumToUser"("A", "B");
CREATE INDEX "_AlbumToUser_B_index" ON "_AlbumToUser"("B");

-- 两边都是 CASCADE：删掉一个相册或者删掉一个用户，对应的授权关系行自动跟着清掉，
-- 不会留下指向已删除记录的孤儿关系行
ALTER TABLE "_AlbumToUser" ADD CONSTRAINT "_AlbumToUser_A_fkey"
    FOREIGN KEY ("A") REFERENCES "Album"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "_AlbumToUser" ADD CONSTRAINT "_AlbumToUser_B_fkey"
    FOREIGN KEY ("B") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
