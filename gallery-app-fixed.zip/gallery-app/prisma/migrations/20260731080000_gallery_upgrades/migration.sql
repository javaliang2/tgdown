-- 这一轮是几个独立的功能升级凑在一起提的一次迁移，互不依赖，合起来提交省一次迁移文件：
-- 1) Photo 加 EXIF 字段（拍摄时间/相机/镜头/光圈/快门/ISO），拿不到就留空，不回填历史数据
-- 2) Album 加 featured（首页置顶）和 scheduledPublishAt（定时发布）
-- 3) 新增 ShareLink：私密相册的免注册分享链接
-- 4) 新增 AlbumViewDaily：按天分桶的浏览量明细，给后台趋势图用
--
-- 都是新增字段/新增表，不改变任何现有数据和现有行为。

-- 1) Photo 的 EXIF 字段 --------------------------------------------------------
-- 全部可为空、不设默认值：老照片没有这些数据，新照片如果原图本身没带 EXIF（截图、
-- 转过一手丢了元数据的图很常见）也拿不到，都用 NULL 表示"没有"，不用占位值糊弄。

ALTER TABLE "Photo" ADD COLUMN "takenAt" TIMESTAMP(3);
ALTER TABLE "Photo" ADD COLUMN "cameraMake" TEXT;
ALTER TABLE "Photo" ADD COLUMN "cameraModel" TEXT;
ALTER TABLE "Photo" ADD COLUMN "lensModel" TEXT;
ALTER TABLE "Photo" ADD COLUMN "focalLength" TEXT;
ALTER TABLE "Photo" ADD COLUMN "aperture" TEXT;
ALTER TABLE "Photo" ADD COLUMN "shutterSpeed" TEXT;
ALTER TABLE "Photo" ADD COLUMN "iso" INTEGER;

-- 2) Album 加置顶 + 定时发布 ----------------------------------------------------

ALTER TABLE "Album" ADD COLUMN "featured" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Album" ADD COLUMN "scheduledPublishAt" TIMESTAMP(3);

-- 首页"置顶优先，同类再按发布时间"排序用得上这个索引
CREATE INDEX "Album_status_visibility_featured_publishedAt_idx"
    ON "Album"("status", "visibility", "featured", "publishedAt");

-- scripts/publish-scheduled.ts 定期扫描到期的定时发布图集
CREATE INDEX "Album_status_scheduledPublishAt_idx" ON "Album"("status", "scheduledPublishAt");

-- 3) ShareLink：私密相册的免注册分享链接 -----------------------------------------

CREATE TABLE "ShareLink" (
    "id" TEXT NOT NULL,
    "token" TEXT NOT NULL,
    "albumId" TEXT NOT NULL,
    "label" TEXT,
    "expiresAt" TIMESTAMP(3),
    "revokedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ShareLink_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "ShareLink_token_key" ON "ShareLink"("token");
CREATE INDEX "ShareLink_albumId_idx" ON "ShareLink"("albumId");

ALTER TABLE "ShareLink" ADD CONSTRAINT "ShareLink_albumId_fkey"
    FOREIGN KEY ("albumId") REFERENCES "Album"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- 4) AlbumViewDaily：按天分桶的浏览量明细 ----------------------------------------

CREATE TABLE "AlbumViewDaily" (
    "id" TEXT NOT NULL,
    "albumId" TEXT NOT NULL,
    "date" DATE NOT NULL,
    "count" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "AlbumViewDaily_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "AlbumViewDaily_albumId_date_key" ON "AlbumViewDaily"("albumId", "date");
CREATE INDEX "AlbumViewDaily_date_idx" ON "AlbumViewDaily"("date");

ALTER TABLE "AlbumViewDaily" ADD CONSTRAINT "AlbumViewDaily_albumId_fkey"
    FOREIGN KEY ("albumId") REFERENCES "Album"("id") ON DELETE CASCADE ON UPDATE CASCADE;
