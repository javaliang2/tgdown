-- 拼音搜索：给 Album 加一列存"标题的拼音搜索串"（全拼 + 首字母，见 lib/pinyin.ts），
-- 跟 title/description 用同一套 pg_trgm 索引方案（迁移 20260723000000_search_perf 已经
-- CREATE EXTENSION IF NOT EXISTS pg_trgm，这里不用重复建）。
--
-- 默认值给空字符串而不是 NULL：现有行迁移后这一列先是空的，ILIKE 查询遇到空字符串
-- 只是匹配不到，不会像 NULL 那样让某些查询逻辑意外变复杂；后面跑一次性脚本
-- prisma/backfill-title-pinyin.ts 把所有现有图集的这一列补上实际拼音值。
ALTER TABLE "Album" ADD COLUMN "titlePinyin" TEXT NOT NULL DEFAULT '';

CREATE INDEX IF NOT EXISTS "Album_titlePinyin_trgm_idx" ON "Album" USING GIN ("titlePinyin" gin_trgm_ops);
