import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import { getAuthSecretBytes } from '@/lib/auth-secret';

const secret = getAuthSecretBytes();
const COOKIE_NAME = 'admin_session';

// Secure cookie 只有在 HTTPS 下浏览器才会保留，用 http://IP:端口 测试时会被浏览器悄悄丢弃，
// 导致登录看起来成功、但下一个请求就被当成没登录。正式环境配好 HTTPS 后一定要把
// COOKIE_INSECURE 从 .env 里删掉或者设成 false，不然生产环境的登录 cookie 会用不加密的方式传输。
const useSecureCookie = process.env.NODE_ENV === 'production' && process.env.COOKIE_INSECURE !== 'true';

export async function createSession(userId: string) {
  const token = await new SignJWT({ userId })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(secret);

  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: useSecureCookie,
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function getSession() {
  const cookieStore = await cookies();
  const token = cookieStore.get(COOKIE_NAME)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret);
    return payload as { userId: string };
  } catch {
    return null;
  }
}

export async function clearSession() {
  const cookieStore = await cookies();
  cookieStore.delete(COOKIE_NAME);
}
