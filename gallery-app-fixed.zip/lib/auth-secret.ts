// 单独拆出来是因为 proxy.ts 跑在 Edge runtime 里，不能引入 next/headers 之类的 Node API，
// 但两边都要在启动/首次执行时校验 AUTH_SECRET 是否配置好，且要算出同一把密钥。
//
// 没配 AUTH_SECRET 时，process.env.AUTH_SECRET! 会把字符串 "undefined" 当密钥用——
// 登录签发和 proxy.ts 校验用的是同一个错误的默认值，两边刚好能对上，看起来"正常工作"，
// 但实际上任何人只要知道这个默认值就能伪造管理员登录 cookie。必须直接抛错拒绝启动。
export function getAuthSecretBytes(): Uint8Array {
  const value = process.env.AUTH_SECRET;
  if (!value || value.length < 16) {
    throw new Error(
      'AUTH_SECRET 未设置或长度不足 16 位。请在 .env 中配置一个足够长的随机字符串（例如 openssl rand -base64 32）。',
    );
  }
  return new TextEncoder().encode(value);
}
