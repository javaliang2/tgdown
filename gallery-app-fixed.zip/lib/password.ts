const MIN_LENGTH = 10;

/**
 * 密码强度规则：至少 10 位，同时包含字母和数字。
 * 没有强制要求特殊字符——太严格的规则容易逼人把密码写在便签纸上，
 * 长度本身对抗暴力破解的效果已经比"加个感叹号"更明显。
 */
export function validatePasswordStrength(password: string): { valid: boolean; message?: string } {
  if (!password || password.length < MIN_LENGTH) {
    return { valid: false, message: `密码至少需要 ${MIN_LENGTH} 位` };
  }
  if (!/[a-zA-Z]/.test(password)) {
    return { valid: false, message: '密码需要包含至少一个字母' };
  }
  if (!/[0-9]/.test(password)) {
    return { valid: false, message: '密码需要包含至少一个数字' };
  }
  // 常见弱密码兜底检查
  const common = ['password', '12345678', 'qwerty123', 'admin1234'];
  if (common.includes(password.toLowerCase())) {
    return { valid: false, message: '这个密码太常见了，换一个' };
  }
  return { valid: true };
}
