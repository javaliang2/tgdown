import { prisma } from '@/lib/db';

export type NavLinkItem = {
  id: string;
  label: string;
  url: string;
  newTab: boolean;
};

export async function getNavLinks(): Promise<NavLinkItem[]> {
  try {
    const links = await prisma.navLink.findMany({
      orderBy: { sortOrder: 'asc' },
      select: {
        id: true,
        label: true,
        url: true,
        newTab: true,
        category: { select: { slug: true } },
      },
    });
    return links.map((link) => ({
      id: link.id,
      label: link.label,
      // 关联了分类的话，链接跟着分类走，不用手动维护；不然就用自己填的 url
      url: link.category ? `/?category=${link.category.slug}` : link.url ?? '#',
      newTab: link.newTab,
    }));
  } catch {
    // 数据库还没跑迁移，或者查询失败时兜底为空菜单，不影响页面渲染
    return [];
  }
}
