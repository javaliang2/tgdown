import { prisma } from '@/lib/db';

export type CategoryNode = {
  id: string;
  name: string;
  slug: string;
  parentId: string | null;
  children: CategoryNode[];
};

/** 获取两级分类树（顶级分类 + 各自的子分类） */
export async function getCategoryTree(): Promise<CategoryNode[]> {
  const all = await prisma.category.findMany({
    orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
    select: { id: true, name: true, slug: true, parentId: true },
  });

  const nodes = new Map<string, CategoryNode>(all.map((c) => [c.id, { ...c, children: [] }]));
  const roots: CategoryNode[] = [];

  for (const c of all) {
    const node = nodes.get(c.id)!;
    if (c.parentId && nodes.has(c.parentId)) {
      nodes.get(c.parentId)!.children.push(node);
    } else {
      roots.push(node);
    }
  }

  return roots;
}

/** 给定一个分类 slug，找出它在树里对应的节点，以及它的顶级祖先（用于导航高亮） */
export function findCategoryContext(tree: CategoryNode[], slug: string) {
  for (const root of tree) {
    if (root.slug === slug) {
      return { current: root, top: root, siblings: tree };
    }
    for (const child of root.children) {
      if (child.slug === slug) {
        return { current: child, top: root, siblings: root.children };
      }
    }
  }
  return null;
}

/** 一个分类下所有能查到图集的分类 id：包含自己，如果有子分类，也包含所有子分类的 id */
export function categoryIdsForFilter(node: CategoryNode): string[] {
  return [node.id, ...node.children.map((c) => c.id)];
}
