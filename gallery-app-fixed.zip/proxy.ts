import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { jwtVerify } from 'jose';
import { getAuthSecretBytes } from '@/lib/auth-secret';

const secret = getAuthSecretBytes();

export async function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // 登录页和登录接口本身不拦截
  if (pathname === '/admin/login' || pathname === '/api/admin/login') {
    return NextResponse.next();
  }

  if (pathname.startsWith('/admin') || pathname.startsWith('/api/admin')) {
    const token = req.cookies.get('admin_session')?.value;
    if (!token) {
      return redirectToLogin(req);
    }
    try {
      await jwtVerify(token, secret);
      return NextResponse.next();
    } catch {
      return redirectToLogin(req);
    }
  }

  return NextResponse.next();
}

function redirectToLogin(req: NextRequest) {
  if (req.nextUrl.pathname.startsWith('/api/')) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const loginUrl = new URL('/admin/login', req.url);
  return NextResponse.redirect(loginUrl);
}

export const config = {
  matcher: ['/admin/:path*', '/api/admin/:path*'],
};
