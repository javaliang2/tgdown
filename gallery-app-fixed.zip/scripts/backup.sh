#!/bin/bash
# 独立的数据库备份脚本，跟部署解耦，可以手动跑，也可以配 cron 定时跑。
# 本地保留最近 N 份；如果装了 aws-cli 并且 .env 里配好了 R2，还会顺手传一份到 R2 做异地备份。
#
# 用法：./scripts/backup.sh
set -e

cd "$(dirname "$0")/.."  # 确保在项目根目录执行，不管从哪调用这个脚本

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}!${NC} $1"; }
err()  { echo -e "${RED}✗${NC} $1"; }

LOCAL_KEEP=14  # 本地保留最近多少份

mkdir -p backups
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_FILE="backups/backup-${TIMESTAMP}.sql.gz"

# ---- 1. 本地备份 ----
if ! docker compose exec -T postgres pg_dump -U gallery gallery | gzip > "$BACKUP_FILE"; then
  err "备份失败，容器可能还没起来（docker compose ps 检查一下）"
  rm -f "$BACKUP_FILE"
  exit 1
fi
SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
ok "本地备份完成: ${BACKUP_FILE}（${SIZE}）"

# 只留最近 N 份，避免把 VPS 磁盘占满
ls -t backups/backup-*.sql.gz 2>/dev/null | tail -n +$((LOCAL_KEEP + 1)) | xargs -r rm --

# ---- 2. 异地备份到 R2（可选，条件不满足就跳过，不影响本地备份的结果） ----
if [ -f .env ]; then
  # shellcheck disable=SC1091
  set -a; source .env; set +a
fi

if ! command -v aws &> /dev/null; then
  warn "没装 aws-cli，跳过异地备份。想要异地备份的话装一下："
  echo "    sudo apt install -y awscli   # 或 pip install awscli"
  exit 0
fi

if [ -z "$R2_ENDPOINT" ] || [ -z "$R2_ACCESS_KEY_ID" ] || [ -z "$R2_SECRET_ACCESS_KEY" ] || [ -z "$R2_BUCKET" ]; then
  warn ".env 里 R2 相关变量没配全，跳过异地备份"
  exit 0
fi

export AWS_ACCESS_KEY_ID="$R2_ACCESS_KEY_ID"
export AWS_SECRET_ACCESS_KEY="$R2_SECRET_ACCESS_KEY"

if aws s3 cp "$BACKUP_FILE" "s3://${R2_BUCKET}/db-backups/$(basename "$BACKUP_FILE")" \
    --endpoint-url "$R2_ENDPOINT" --only-show-errors; then
  ok "异地备份已上传到 R2: db-backups/$(basename "$BACKUP_FILE")"
  echo "  建议在 Cloudflare R2 控制台给 db-backups/ 这个前缀设一条生命周期规则，"
  echo "  比如「90 天后自动删除」，省得手动清理远端旧备份"
else
  warn "上传到 R2 失败，本地备份还在，不影响这次备份结果"
fi
