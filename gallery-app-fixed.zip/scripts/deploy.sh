#!/bin/bash
# 日常更新用：拉最新代码 -> 备份数据库 -> 重新构建 -> 重启
# 用法：在项目根目录下执行 ./scripts/deploy.sh
set -e

BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${BLUE}▸${NC} $1"; }
ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}!${NC} $1"; }
err()  { echo -e "${RED}✗${NC} $1"; }

if [ ! -f docker-compose.yml ]; then
  err "当前目录下没有 docker-compose.yml，请先 cd 到项目根目录"
  exit 1
fi

# ---- 1. 检查有没有本地未提交的改动 ----
if [ -d .git ] && ! git diff --quiet 2>/dev/null; then
  warn "检测到本地有未提交的改动，git pull 可能会冲突"
  read -rp "要不要先看一下改了什么？(y/N) " -n 1 REPLY
  echo
  if [[ $REPLY =~ ^[Yy]$ ]]; then
    git status
    exit 1
  fi
fi

# ---- 2. 拉最新代码 ----
if [ -d .git ]; then
  log "拉取最新代码…"
  git pull
else
  warn "这不是一个 git 仓库，跳过拉代码这步（你可能是手动传的压缩包，自己覆盖好文件再跑这个脚本）"
fi

# ---- 3. 部署前备份数据库 ----
log "部署前备份数据库…"
if ./scripts/backup.sh; then
  ok "备份完成"
else
  warn "备份失败（可能是第一次部署，容器还没起来），继续往下走"
fi

# ---- 4. 重新构建并启动 ----
log "重新构建镜像…"
docker compose build

log "启动新版本（会自动跑数据库迁移）…"
docker compose up -d

# ---- 5. 健康检查 ----
log "等待应用就绪…"
sleep 3
READY=false
for i in $(seq 1 10); do
  if docker compose exec -T web node -e "
    require('http').get('http://localhost:3000', res => {
      process.exit(res.statusCode === 200 ? 0 : 1);
    }).on('error', () => process.exit(1));
  " 2>/dev/null; then
    READY=true
    break
  fi
  sleep 3
done

if [ "$READY" = true ]; then
  ok "部署成功，应用已经能响应了"
else
  err "应用没能在预期时间内就绪，去看日志排查："
  echo "  docker compose logs -f web"
  echo "回滚数据库用刚才的备份（backups/ 目录下最新那份）："
  echo "  ./scripts/restore.sh backups/$(ls -t backups/backup-*.sql.gz 2>/dev/null | head -1 | xargs -r basename)"
  exit 1
fi

# ---- 6. 清理旧镜像，省磁盘 ----
log "清理没用到的旧镜像…"
docker image prune -f > /dev/null

ok "全部完成"
