-- AlterTable
ALTER TABLE "SiteSetting" ADD COLUMN     "icpNumber" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "contactInfo" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "aboutContent" TEXT NOT NULL DEFAULT '';

-- CreateTable
CREATE TABLE "NavLink" (
    "id" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "newTab" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "NavLink_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "NavLink_sortOrder_idx" ON "NavLink"("sortOrder");
