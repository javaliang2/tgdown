#!/bin/bash
# 首次在新 VPS 上部署，从零到能访问网站。
# 用法：在项目根目录下执行 ./scripts/first-deploy.sh
set -e

BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${BLUE}▸${NC} $1"; }
ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}!${NC} $1"; }
err()  { echo -e "${RED}✗${NC} $1"; }

# ---- 1. 检查/安装 Docker ----
if ! command -v docker &> /dev/null; then
  log "没检测到 Docker，开始安装…"
  curl -fsSL https://get.docker.com | sh
  sudo usermod -aG docker "$USER"
  warn "Docker 组权限刚加上，如果下面的命令报权限错误，请退出重新 SSH 登录一次再重跑这个脚本"
else
  ok "Docker 已安装"
fi

if ! docker compose version &> /dev/null; then
  err "docker compose 插件不可用，请手动检查 Docker 安装（较新版本一般自带）"
  exit 1
fi
ok "docker compose 可用"

# ---- 2. 准备 .env ----
if [ ! -f .env ]; then
  log "没有 .env，从 .env.example 创建一份"
  cp .env.example .env

  # 自动生成两个随机密钥，省得手动跑 openssl
  PG_PASS=$(openssl rand -hex 16)
  AUTH_SECRET=$(openssl rand -base64 32)
  sed -i.bak "s#^POSTGRES_PASSWORD=.*#POSTGRES_PASSWORD=${PG_PASS}#" .env
  sed -i.bak "s#^DATABASE_URL=.*#DATABASE_URL=postgresql://gallery:${PG_PASS}@localhost:5432/gallery#" .env
  sed -i.bak "s#^AUTH_SECRET=.*#AUTH_SECRET=${AUTH_SECRET}#" .env
  rm -f .env.bak
  ok "已自动生成数据库密码和会话密钥"

  # ---- R2 配置，交互式输入 ----
  echo
  log "接下来配置 Cloudflare R2（去 Cloudflare Dashboard → R2 → 管理 API 令牌 拿这几项）"
  echo "  不确定的话可以先留空，回车跳过，之后自己手动编辑 .env 再补上"
  echo

  read -rp "R2_ENDPOINT (形如 https://<account-id>.r2.cloudflarestorage.com): " R2_ENDPOINT_INPUT
  read -rp "R2_ACCESS_KEY_ID: " R2_ACCESS_KEY_INPUT
  read -rsp "R2_SECRET_ACCESS_KEY（输入时不会显示，正常粘贴/打字后回车即可）: " R2_SECRET_KEY_INPUT
  echo
  read -rp "R2_BUCKET (bucket 名称): " R2_BUCKET_INPUT
  read -rp "R2_PUBLIC_URL (公开访问域名，形如 https://images.yourdomain.com): " R2_PUBLIC_URL_INPUT

  # 只有实际输入了内容才写进 .env，避免把已有的占位符值清空成空字符串
  [ -n "$R2_ENDPOINT_INPUT" ] && sed -i.bak "s#^R2_ENDPOINT=.*#R2_ENDPOINT=${R2_ENDPOINT_INPUT}#" .env
  [ -n "$R2_ACCESS_KEY_INPUT" ] && sed -i.bak "s#^R2_ACCESS_KEY_ID=.*#R2_ACCESS_KEY_ID=${R2_ACCESS_KEY_INPUT}#" .env
  [ -n "$R2_SECRET_KEY_INPUT" ] && sed -i.bak "s#^R2_SECRET_ACCESS_KEY=.*#R2_SECRET_ACCESS_KEY=${R2_SECRET_KEY_INPUT}#" .env
  [ -n "$R2_BUCKET_INPUT" ] && sed -i.bak "s#^R2_BUCKET=.*#R2_BUCKET=${R2_BUCKET_INPUT}#" .env
  if [ -n "$R2_PUBLIC_URL_INPUT" ]; then
    sed -i.bak "s#^R2_PUBLIC_URL=.*#R2_PUBLIC_URL=${R2_PUBLIC_URL_INPUT}#" .env
    # next.config.js 用这个校验图片域名，自动从 URL 里把域名部分抠出来
    R2_HOSTNAME=$(echo "$R2_PUBLIC_URL_INPUT" | sed -E 's#^https?://##' | cut -d'/' -f1)
    sed -i.bak "s#^R2_PUBLIC_HOSTNAME=.*#R2_PUBLIC_HOSTNAME=${R2_HOSTNAME}#" .env
  fi
  rm -f .env.bak

  if [ -z "$R2_ENDPOINT_INPUT" ] || [ -z "$R2_ACCESS_KEY_INPUT" ] || [ -z "$R2_SECRET_KEY_INPUT" ] || [ -z "$R2_BUCKET_INPUT" ]; then
    warn "R2 配置不完整，图片上传功能现在用不了。之后想起来了手动编辑 .env 补上，改完记得跑："
    echo "    docker compose up -d --build"
  else
    ok "R2 配置已写入 .env"
  fi
else
  ok ".env 已存在，跳过生成"
fi

# ---- 3. 构建并启动 ----
log "构建镜像并启动服务（第一次会比较慢，耐心等下）…"
docker compose up -d --build

log "等待数据库和应用就绪…"
sleep 5
for i in $(seq 1 12); do
  if docker compose exec -T web node -e "
    require('http').get('http://localhost:3000', res => {
      process.exit(res.statusCode === 200 ? 0 : 1);
    }).on('error', () => process.exit(1));
  " 2>/dev/null; then
    ok "应用已经能响应了"
    break
  fi
  if [ "$i" -eq 12 ]; then
    warn "等了一分钟还没就绪，去看看日志：docker compose logs -f web"
  fi
  sleep 5
done

# ---- 4. 创建管理员账号 ----
echo
log "接下来创建管理员账号"
read -rp "管理员邮箱: " ADMIN_EMAIL
read -rsp "管理员密码（至少10位，包含字母和数字；输入时不会显示，正常打字后回车即可）: " ADMIN_PASS
echo

if docker compose exec -T web node prisma/create-admin.cjs "$ADMIN_EMAIL" "$ADMIN_PASS"; then
  ok "管理员账号创建成功"
else
  err "创建失败，密码可能不满足强度要求，重跑一次："
  echo "  docker compose exec web node prisma/create-admin.cjs <email> <password>"
fi

# ---- 5. 完成 ----
SERVER_IP=$(curl -s -4 ifconfig.me || echo "你的服务器IP")
echo
ok "部署完成！"
echo "  前台：http://${SERVER_IP}:3000"
echo "  后台：http://${SERVER_IP}:3000/admin/login"
echo
warn "3000 端口现在是直接对外开放的，只适合先测试。正式使用前记得："
echo "  1. 配置域名 + Caddy/Nginx 反代和 HTTPS"
echo "  2. 用 ufw 只放行 22/80/443，把 3000 收回去"
