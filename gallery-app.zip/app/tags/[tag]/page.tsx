import { prisma } from '@/lib/db';
import { publicUrl } from '@/lib/r2';
import Link from 'next/link';
import Image from 'next/image';
import type { Metadata } from 'next';
import Pagination from '@/app/components/Pagination';
import { getPageParams, getTotalPages } from '@/lib/pagination';
import { getSiteSettings } from '@/lib/settings';
import { siteUrl } from '@/lib/site-url';

export const revalidate = 3600;

export async function generateMetadata({
  params,
  searchParams,
}: {
  params: Promise<{ tag: string }>;
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}): Promise<Metadata> {
  const { tag } = await params;
  const { page } = getPageParams(await searchParams);
  const [settings, sample] = await Promise.all([
    getSiteSettings(),
    // 拿这个标签下最新的一张封面图当分享预览图，比用兜底的站点默认图更相关
    prisma.album.findFirst({
      where: { status: 'PUBLISHED', tags: { has: tag } },
      orderBy: { publishedAt: 'desc' },
      select: { coverKey: true },
    }),
  ]);

  const title = `标签：${tag}`;
  const description = `${settings.siteTitle}中标记为「${tag}」的图集`;
  const url = `${siteUrl()}/tags/${encodeURIComponent(tag)}`;
  const image = sample?.coverKey ? publicUrl(sample.coverKey) : undefined;

  return {
    title,
    description,
    alternates: { canonical: url },
    // 翻页页面（第 2 页起）跟第 1 页内容重复度高，不值得单独索引
    ...(page > 1 ? { robots: { index: false, follow: true } } : {}),
    openGraph: {
      title,
      description,
      url,
      type: 'website',
      images: image ? [{ url: image }] : undefined,
    },
    twitter: {
      card: image ? 'summary_large_image' : 'summary',
      title,
      description,
      images: image ? [image] : undefined,
    },
  };
}

export default async function TagPage({
  params,
  searchParams,
}: {
  params: Promise<{ tag: string }>;
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const { tag } = await params;
  const sp = await searchParams;
  const { page, skip, take } = getPageParams(sp);

  const where = { status: 'PUBLISHED' as const, tags: { has: tag } };

  const [albums, totalCount] = await Promise.all([
    prisma.album.findMany({
      where,
      orderBy: { publishedAt: 'desc' },
      skip,
      take,
      select: { title: true, slug: true, coverKey: true, coverBlurDataURL: true },
    }),
    prisma.album.count({ where }),
  ]);

  const totalPages = getTotalPages(totalCount);

  return (
    <div>
      <div className="flex items-center justify-between gap-2 px-4 py-4">
        <h1 className="text-lg text-[var(--fg-80)]">
          标签：<span className="text-[var(--text-color)]">{tag}</span>
        </h1>
        <Link href="/tags" className="text-sm text-[var(--fg-50)] hover:text-[var(--text-color)]">
          全部标签
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-x-1 gap-y-3 p-1 sm:grid-cols-3 md:grid-cols-4">
        {albums.map((album, index) => (
          <Link key={album.slug} href={`/albums/${album.slug}`} className="group block">
            <div className="relative aspect-square overflow-hidden bg-[var(--fg-5)]">
              {album.coverKey && (
                <Image
                  src={publicUrl(album.coverKey)}
                  alt={album.title}
                  fill
                  sizes="(max-width: 768px) 50vw, 25vw"
                  className="object-cover transition duration-500 group-hover:scale-105"
                  priority={index === 0}
                  loading={index === 0 ? undefined : 'lazy'}
                  {...(album.coverBlurDataURL
                    ? { placeholder: 'blur' as const, blurDataURL: album.coverBlurDataURL }
                    : {})}
                />
              )}
            </div>
            <p className="mt-1.5 truncate px-0.5 text-base text-[var(--fg-80)] group-hover:text-[var(--text-color)]">
              {album.title}
            </p>
          </Link>
        ))}
        {albums.length === 0 && (
          <p className="col-span-full p-8 text-center text-[var(--fg-50)]">这个标签下暂时没有图集</p>
        )}
      </div>

      <Pagination currentPage={page} totalPages={totalPages} basePath={`/tags/${encodeURIComponent(tag)}`} />
    </div>
  );
}
