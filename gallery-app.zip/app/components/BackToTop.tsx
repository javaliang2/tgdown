'use client';

import { useEffect, useState } from 'react';

// 划过多少像素才显示按钮，太小的话页面刚有点内容就冒出来，反而碍事
const SHOW_AFTER_PX = 400;

export default function BackToTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    function onScroll() {
      setVisible(window.scrollY > SHOW_AFTER_PX);
    }
    // passive: true 让浏览器不用等这个监听器执行完就能继续处理滚动，减少卡顿
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll(); // 首次挂载时校正一次，避免刷新时页面本来就在下面却要等一次滚动才出现
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <button
      type="button"
      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      aria-label="返回顶部"
      title="返回顶部"
      className={`fixed bottom-6 right-6 z-40 flex h-11 w-11 items-center justify-center rounded-full
        bg-[var(--accent-color)] text-[var(--accent-contrast)] shadow-lg transition-all duration-300
        hover:opacity-90
        ${visible ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-3 opacity-0'}`}
    >
      <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
        <path
          d="M9 14.5V3.5M9 3.5L4 8.5M9 3.5L14 8.5"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </button>
  );
}
