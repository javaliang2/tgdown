import { ImageResponse } from 'next/og';
import { getSiteSettings } from '@/lib/settings';
import { getContrastTextColor } from '@/lib/color';

export const runtime = 'nodejs';
export const revalidate = 3600;

export const size = { width: 180, height: 180 };
export const contentType = 'image/png';

export default async function AppleIcon() {
  const settings = await getSiteSettings();
  const letter = (settings.siteTitle?.trim()?.[0] || '图').toUpperCase();
  const textColor = getContrastTextColor(settings.accentColor);

  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: settings.accentColor,
          color: textColor,
          fontSize: 96,
          fontWeight: 600,
        }}
      >
        {letter}
      </div>
    ),
    { ...size },
  );
}
