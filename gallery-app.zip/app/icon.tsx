import { ImageResponse } from 'next/og';
import { getSiteSettings } from '@/lib/settings';
import { getContrastTextColor } from '@/lib/color';

// 需要查数据库拿站点设置，Prisma 不支持 Edge runtime，这里显式声明跑在 Node 上
export const runtime = 'nodejs';
export const revalidate = 3600; // 跟站点设置改动的生效速度比，浏览器请求 favicon 更频繁，缓存一下避免每次都查库

export const size = { width: 32, height: 32 };
export const contentType = 'image/png';

export default async function Icon() {
  const settings = await getSiteSettings();
  const letter = (settings.siteTitle?.trim()?.[0] || '图').toUpperCase();
  const textColor = getContrastTextColor(settings.accentColor);

  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: settings.accentColor,
          color: textColor,
          fontSize: 20,
          fontWeight: 600,
          borderRadius: 6,
        }}
      >
        {letter}
      </div>
    ),
    { ...size },
  );
}
