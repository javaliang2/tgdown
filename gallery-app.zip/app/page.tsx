import { prisma } from '@/lib/db';
import { publicUrl } from '@/lib/r2';
import Link from 'next/link';
import Image from 'next/image';
import Pagination from './components/Pagination';
import { getPageParams, getTotalPages } from '@/lib/pagination';
import { getCategoryTree, findCategoryContext, categoryIdsForFilter } from '@/lib/categories';

export const revalidate = 3600; // 每小时重新生成一次

export default async function HomePage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const params = await searchParams;
  const categorySlug = typeof params.category === 'string' ? params.category : undefined;
  const { page, skip, take } = getPageParams(params);

  const tree = await getCategoryTree();
  const context = categorySlug ? findCategoryContext(tree, categorySlug) : null;

  const where = {
    status: 'PUBLISHED' as const,
    ...(context ? { categoryId: { in: categoryIdsForFilter(context.current) } } : {}),
  };

  const [albums, totalCount] = await Promise.all([
    prisma.album.findMany({
      where,
      orderBy: { publishedAt: 'desc' },
      skip,
      take,
      select: { title: true, slug: true, coverKey: true },
    }),
    prisma.album.count({ where }),
  ]);

  const totalPages = getTotalPages(totalCount);

  return (
    <div>
      {tree.length > 0 && (
        <div className="space-y-2 px-4 py-4">
          {/* 第一行：大类 */}
          <div className="flex flex-wrap gap-2 text-sm">
            <Link
              href="/"
              style={!categorySlug ? { backgroundColor: 'var(--accent-color)' } : undefined}
              className={`rounded-full px-3 py-1 ${!categorySlug ? 'text-[var(--accent-contrast)]' : 'bg-[var(--fg-10)] text-[var(--fg-70)]'}`}
            >
              全部
            </Link>
            {tree.map((top) => {
              const active = context?.top.id === top.id;
              return (
                <Link
                  key={top.slug}
                  href={`/?category=${top.slug}`}
                  style={active ? { backgroundColor: 'var(--accent-color)' } : undefined}
                  className={`rounded-full px-3 py-1 ${active ? 'text-[var(--accent-contrast)]' : 'bg-[var(--fg-10)] text-[var(--fg-70)]'}`}
                >
                  {top.name}
                </Link>
              );
            })}
          </div>

          {/* 第二行：选中大类下的子分类（城市） */}
          {context && context.top.children.length > 0 && (
            <div className="flex flex-wrap gap-2 text-xs">
              <Link
                href={`/?category=${context.top.slug}`}
                style={context.current.id === context.top.id ? { backgroundColor: 'var(--accent-color)', opacity: 0.8 } : undefined}
                className={`rounded-full px-3 py-1 ${
                  context.current.id === context.top.id ? 'text-[var(--accent-contrast)]' : 'bg-[var(--fg-5)] text-[var(--fg-50)]'
                }`}
              >
                {context.top.name}全部
              </Link>
              {context.top.children.map((child) => (
                <Link
                  key={child.slug}
                  href={`/?category=${child.slug}`}
                  style={context.current.slug === child.slug ? { backgroundColor: 'var(--accent-color)', opacity: 0.8 } : undefined}
                  className={`rounded-full px-3 py-1 ${
                    context.current.slug === child.slug ? 'text-[var(--accent-contrast)]' : 'bg-[var(--fg-5)] text-[var(--fg-50)]'
                  }`}
                >
                  {child.name}
                </Link>
              ))}
            </div>
          )}
        </div>
      )}

      <div className="grid grid-cols-2 gap-x-1 gap-y-3 p-1 sm:grid-cols-3 md:grid-cols-4">
        {albums.map((album, index) => (
          <Link key={album.slug} href={`/albums/${album.slug}`} className="group block">
            <div className="relative aspect-square overflow-hidden bg-[var(--fg-5)]">
              {album.coverKey && (
                <Image
                  src={publicUrl(album.coverKey)}
                  alt={album.title}
                  fill
                  sizes="(max-width: 768px) 50vw, 25vw"
                  className="object-cover transition duration-500 group-hover:scale-105"
                  priority={index === 0}
                  loading={index === 0 ? undefined : 'lazy'}
                />
              )}
            </div>
            <p className="mt-1.5 truncate px-0.5 text-sm text-[var(--fg-80)] group-hover:text-[var(--text-color)]">
              {album.title}
            </p>
          </Link>
        ))}
        {albums.length === 0 && (
          <p className="col-span-full p-8 text-center text-[var(--fg-50)]">
            {categorySlug ? '这个分类下暂无图集' : '还没有发布任何图集'}
          </p>
        )}
      </div>

      <Pagination currentPage={page} totalPages={totalPages} basePath="/" categorySlug={categorySlug} />
    </div>
  );
}
