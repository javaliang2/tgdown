import { prisma } from '@/lib/db';
import { publicUrl } from '@/lib/r2';
import Link from 'next/link';
import Image from 'next/image';
import type { Metadata } from 'next';
import Pagination from './components/Pagination';
import HeroCarousel from './components/HeroCarousel';
import { getPageParams, getTotalPages } from '@/lib/pagination';
import { getCategoryTree, findCategoryContext, categoryIdsForFilter } from '@/lib/categories';

export const revalidate = 3600; // 每小时重新生成一次

type SearchParams = Promise<{ [key: string]: string | string[] | undefined }>;

export async function generateMetadata({ searchParams }: { searchParams: SearchParams }): Promise<Metadata> {
  const params = await searchParams;
  const { page } = getPageParams(params);

  // 第 2 页及以后内容跟第 1 页高度重复（只是翻页），搜索引擎索引这些页面价值很低，
  // 加 noindex 避免"薄内容"拖累整站质量分；follow 保留，链接权重照样往后传递
  if (page > 1) {
    return { robots: { index: false, follow: true } };
  }
  return {};
}

export default async function HomePage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const params = await searchParams;
  const categorySlug = typeof params.category === 'string' ? params.category : undefined;
  const { page, skip, take } = getPageParams(params);

  const tree = await getCategoryTree();
  const context = categorySlug ? findCategoryContext(tree, categorySlug) : null;

  const where = {
    status: 'PUBLISHED' as const,
    ...(context ? { categoryId: { in: categoryIdsForFilter(context.current) } } : {}),
  };

  const [albums, totalCount] = await Promise.all([
    prisma.album.findMany({
      where,
      orderBy: { publishedAt: 'desc' },
      skip,
      take,
      select: { title: true, slug: true, coverKey: true, coverBlurDataURL: true },
    }),
    prisma.album.count({ where }),
  ]);

  const totalPages = getTotalPages(totalCount);

  // 轮播只在首页第一页、没有按分类筛选时显示（分类页/翻页再放一个大轮播意义不大，
  // 也省得每次翻页/切分类都多查两次库）
  const showCarousel = page === 1 && !categorySlug;
  const [popularAlbums, latestAlbums] = showCarousel
    ? await Promise.all([
        prisma.album.findMany({
          where: { status: 'PUBLISHED' },
          orderBy: { viewCount: 'desc' },
          take: 6,
          select: { title: true, slug: true, coverKey: true, coverBlurDataURL: true },
        }),
        prisma.album.findMany({
          where: { status: 'PUBLISHED' },
          orderBy: { publishedAt: 'desc' },
          take: 6,
          select: { title: true, slug: true, coverKey: true, coverBlurDataURL: true },
        }),
      ])
    : [[], []];

  return (
    <div>
      {showCarousel && <HeroCarousel popular={popularAlbums} latest={latestAlbums} />}

      {tree.length > 0 && (
        <div className="space-y-2 px-4 py-4">
          {/* 第一行：大类 */}
          <div className="flex flex-wrap gap-2 text-sm">
            <Link
              href="/"
              style={!categorySlug ? { backgroundColor: 'var(--accent-color)' } : undefined}
              className={`flex min-h-8 items-center rounded-full px-3.5 ${!categorySlug ? 'text-[var(--accent-contrast)]' : 'bg-[var(--fg-10)] text-[var(--fg-70)]'}`}
            >
              全部
            </Link>
            {tree.map((top) => {
              const active = context?.top.id === top.id;
              return (
                <Link
                  key={top.slug}
                  href={`/?category=${top.slug}`}
                  style={active ? { backgroundColor: 'var(--accent-color)' } : undefined}
                  className={`flex min-h-8 items-center rounded-full px-3.5 ${active ? 'text-[var(--accent-contrast)]' : 'bg-[var(--fg-10)] text-[var(--fg-70)]'}`}
                >
                  {top.name}
                </Link>
              );
            })}
          </div>

          {/* 第二行：选中大类下的子分类（城市） */}
          {context && context.top.children.length > 0 && (
            <div className="flex flex-wrap gap-2 text-xs">
              <Link
                href={`/?category=${context.top.slug}`}
                style={context.current.id === context.top.id ? { backgroundColor: 'var(--accent-color)', opacity: 0.8 } : undefined}
                className={`flex min-h-8 items-center rounded-full px-3 ${
                  context.current.id === context.top.id ? 'text-[var(--accent-contrast)]' : 'bg-[var(--fg-5)] text-[var(--fg-50)]'
                }`}
              >
                {context.top.name}全部
              </Link>
              {context.top.children.map((child) => (
                <Link
                  key={child.slug}
                  href={`/?category=${child.slug}`}
                  style={context.current.slug === child.slug ? { backgroundColor: 'var(--accent-color)', opacity: 0.8 } : undefined}
                  className={`flex min-h-8 items-center rounded-full px-3 ${
                    context.current.slug === child.slug ? 'text-[var(--accent-contrast)]' : 'bg-[var(--fg-5)] text-[var(--fg-50)]'
                  }`}
                >
                  {child.name}
                </Link>
              ))}
            </div>
          )}
        </div>
      )}

      <div className="grid grid-cols-2 gap-x-1 gap-y-3 p-1 sm:grid-cols-3 md:grid-cols-4">
        {albums.map((album, index) => (
          <Link key={album.slug} href={`/albums/${album.slug}`} className="group block">
            <div className="relative aspect-square overflow-hidden bg-[var(--fg-5)]">
              {album.coverKey && (
                <Image
                  src={publicUrl(album.coverKey)}
                  alt={album.title}
                  fill
                  sizes="(max-width: 768px) 50vw, 25vw"
                  className="object-cover transition duration-500 group-hover:scale-105"
                  priority={index === 0 && !showCarousel}
                  loading={index === 0 && !showCarousel ? undefined : 'lazy'}
                  {...(album.coverBlurDataURL
                    ? { placeholder: 'blur' as const, blurDataURL: album.coverBlurDataURL }
                    : {})}
                />
              )}
            </div>
            <p className="mt-1.5 truncate px-0.5 text-base text-[var(--fg-80)] group-hover:text-[var(--text-color)]">
              {album.title}
            </p>
          </Link>
        ))}
        {albums.length === 0 && (
          <p className="col-span-full p-8 text-center text-[var(--fg-50)]">
            {categorySlug ? '这个分类下暂无图集' : '还没有发布任何图集'}
          </p>
        )}
      </div>

      <Pagination currentPage={page} totalPages={totalPages} basePath="/" extraParams={{ category: categorySlug }} />
    </div>
  );
}
