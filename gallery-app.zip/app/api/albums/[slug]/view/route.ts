import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

// 简单直接写库，量级不大完全够用；量大了再考虑 Redis 累加 + 定时同步

const VIEWED_COOKIE = 'viewed_albums';
const VIEWED_COOKIE_MAX_AGE = 60 * 60 * 24; // 24 小时内同一浏览器对同一图集只计一次
const RATE_LIMIT_WINDOW_MS = 60 * 1000; // 每个 IP 每分钟最多这么多次上报（跨所有图集）
const RATE_LIMIT_MAX = 20;
const PRUNE_INTERVAL_MS = 10 * 60 * 1000; // 每 10 分钟扫一次，清掉过期的 IP 记录

// 注意：这是单实例进程内的内存计数器，够用来挡住简单的刷量脚本；
// 如果以后 web 服务横向扩容成多实例，这里要换成 Redis 之类的共享存储。
const ipHits = new Map<string, { count: number; resetAt: number }>();
let lastPruneAt = 0;

function pruneExpiredHits(now: number) {
  if (now - lastPruneAt < PRUNE_INTERVAL_MS) return;
  lastPruneAt = now;
  for (const [ip, entry] of ipHits) {
    if (now > entry.resetAt) ipHits.delete(ip);
  }
}

function isRateLimited(ip: string): boolean {
  const now = Date.now();
  pruneExpiredHits(now);

  const entry = ipHits.get(ip);
  if (!entry || now > entry.resetAt) {
    ipHits.set(ip, { count: 1, resetAt: now + RATE_LIMIT_WINDOW_MS });
    return false;
  }
  entry.count += 1;
  return entry.count > RATE_LIMIT_MAX;
}

function getClientIp(req: NextRequest): string {
  return req.headers.get('x-real-ip') || req.headers.get('x-forwarded-for')?.split(',')[0].trim() || 'unknown';
}

function isSameOriginRequest(req: NextRequest): boolean {
  // 用请求自带的 Host 头做基准，而不是依赖 SITE_URL 有没有配置对——
  // 万一 SITE_URL 忘了配或者临时用 http://IP:端口 测试，用 SITE_URL 当基准会把正常请求也拦掉。
  const allowedHost = req.headers.get('host');
  if (!allowedHost) return false;

  const origin = req.headers.get('origin');
  const referer = req.headers.get('referer');

  // 埋点脚本是同源 fetch，正常请求一定带 Origin 或 Referer 中的一个，且 host 得和当前请求一致。
  // 没带这两个头的（比如脚本直接拿 curl 打）也一律当作非法请求拒绝。
  try {
    if (origin) return new URL(origin).host === allowedHost;
    if (referer) return new URL(referer).host === allowedHost;
  } catch {
    return false;
  }
  return false;
}

function parseViewedSlugs(raw: string | undefined): Set<string> {
  if (!raw) return new Set();
  try {
    const arr = JSON.parse(raw);
    return new Set(Array.isArray(arr) ? arr : []);
  } catch {
    return new Set();
  }
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;

  if (!isSameOriginRequest(req)) {
    return NextResponse.json({ ok: false, reason: 'forbidden' }, { status: 403 });
  }

  // 先查 cookie 去重，24 小时内已经计过的请求直接放行、不占用 IP 限流额度。
  // 这样同一个 IP 后面挂着很多人的场景（公司网络、学校、NAT）里，大家反复访问
  // 已经看过的图集不会互相占用限流名额；限流只用来挡"确实在持续制造新增计数"的刷量。
  const viewedSlugs = parseViewedSlugs(req.cookies.get(VIEWED_COOKIE)?.value);
  if (viewedSlugs.has(slug)) {
    return NextResponse.json({ ok: true, counted: false });
  }

  const ip = getClientIp(req);
  if (isRateLimited(ip)) {
    return NextResponse.json({ ok: false, reason: 'rate_limited' }, { status: 429 });
  }

  try {
    await prisma.album.update({
      where: { slug },
      data: { viewCount: { increment: 1 } },
    });

    viewedSlugs.add(slug);
    const res = NextResponse.json({ ok: true, counted: true });
    res.cookies.set(VIEWED_COOKIE, JSON.stringify([...viewedSlugs]), {
      httpOnly: true,
      sameSite: 'lax',
      path: '/',
      maxAge: VIEWED_COOKIE_MAX_AGE,
    });
    return res;
  } catch {
    return NextResponse.json({ ok: false }, { status: 404 });
  }
}
