#!/bin/bash
# 日常更新用：拉最新代码 -> 备份数据库 -> 重新构建 -> 重启
# 用法：在项目根目录下执行 ./scripts/deploy.sh
set -e

BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${BLUE}▸${NC} $1"; }
ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}!${NC} $1"; }
err()  { echo -e "${RED}✗${NC} $1"; }

if [ ! -f docker-compose.yml ]; then
  err "当前目录下没有 docker-compose.yml，请先 cd 到项目根目录"
  exit 1
fi

# ---- 1. 检查有没有本地未提交的改动 ----
if [ -d .git ] && ! git diff --quiet 2>/dev/null; then
  warn "检测到本地有未提交的改动，git pull 可能会冲突"
  read -rp "要不要先看一下改了什么？(y/N) " -n 1 REPLY
  echo
  if [[ $REPLY =~ ^[Yy]$ ]]; then
    git status
    exit 1
  fi
fi

# ---- 2. 拉最新代码 ----
if [ -d .git ]; then
  log "拉取最新代码…"
  git pull
else
  warn "这不是一个 git 仓库，跳过拉代码这步（你可能是手动传的压缩包，自己覆盖好文件再跑这个脚本）"
fi

# ---- 3. 部署前备份数据库 ----
log "部署前备份数据库…"
if ./scripts/backup.sh; then
  ok "备份完成"
else
  warn "备份失败（可能是第一次部署，容器还没起来），继续往下走"
fi

# ---- 4. 构建前先跑新迁移 ----
# npm run build 阶段会预渲染页面、直接查库，如果这次更新加了新表/新字段，
# 得先把迁移跑了，不然构建会因为 "table/column does not exist" 报错退出
# （跟 entrypoint 里启动时跑的那次 migrate deploy 是两回事，那次已经晚了）
log "跑一遍新迁移（如果有的话）…"
docker build --target deps -t gallery-app:deps . > /dev/null
DEPLOY_DB_URL=$(grep '^DATABASE_URL=' .env | cut -d'=' -f2-)
docker run --rm --network host \
  -v "$(pwd)/prisma:/app/prisma:ro" \
  -w /app \
  -e DATABASE_URL="${DEPLOY_DB_URL}" \
  gallery-app:deps sh -c "apk add --no-cache openssl >/dev/null 2>&1; npx prisma migrate deploy"

# ---- 4.5 清一下 Redis 里缓存的旧结构数据 ----
# getSiteSettings / getNavLinks / getCategoryTree 都会把查库结果缓存进 Redis（TTL 5 分钟）。
# 如果这次更新改了这几张表的字段结构（比如加了新列），缓存里躺着的还是旧结构的 JSON，
# 新代码起来后一读到就可能因为缺字段报错，得等缓存自然过期（最多 5 分钟）才会恢复正常。
# 这里在迁移跑完、新容器起来之前主动清掉这几个 key，新代码第一次读到的就是查库的新鲜数据，
# 不用干等。Redis 没配置（DEPLOY_REDIS_URL 为空）就跳过，不影响单节点部署。
DEPLOY_REDIS_URL=$(grep '^REDIS_URL=' .env | cut -d'=' -f2-)
if [ -n "$DEPLOY_REDIS_URL" ]; then
  log "清理 Redis 里的旧缓存（settings / navlinks / categorytree）…"
  if docker run --rm --network host \
    -e REDIS_URL="${DEPLOY_REDIS_URL}" \
    gallery-app:deps node -e "
      const Redis = require('ioredis');
      const r = new Redis(process.env.REDIS_URL, { lazyConnect: true, maxRetriesPerRequest: 1 });
      r.connect()
        .then(() => r.del('gallery:settings', 'gallery:navlinks', 'gallery:categorytree'))
        .then(() => { r.disconnect(); process.exit(0); })
        .catch((err) => { console.error(err.message); process.exit(1); });
    " > /dev/null 2>&1; then
    ok "缓存清理完成"
  else
    warn "缓存清理失败（Redis 连不上？），不影响本次部署，最多等 5 分钟旧缓存自然过期"
  fi
fi

# ---- 5. 重新构建并启动 ----
log "重新构建镜像…"
docker compose build

log "启动新版本（会自动跑数据库迁移）…"
docker compose up -d

# ---- 6. 健康检查 ----
log "等待应用就绪…"
sleep 3
READY=false
for i in $(seq 1 10); do
  if docker compose exec -T web node -e "
    require('http').get('http://localhost:3000', res => {
      process.exit(res.statusCode === 200 ? 0 : 1);
    }).on('error', () => process.exit(1));
  " 2>/dev/null; then
    READY=true
    break
  fi
  sleep 3
done

if [ "$READY" = true ]; then
  ok "部署成功，应用已经能响应了"
else
  err "应用没能在预期时间内就绪，去看日志排查："
  echo "  docker compose logs -f web"
  echo "回滚数据库用刚才的备份（backups/ 目录下最新那份）："
  echo "  ./scripts/restore.sh backups/$(ls -t backups/backup-*.sql.gz 2>/dev/null | head -1 | xargs -r basename)"
  exit 1
fi

# ---- 7. 清理旧镜像，省磁盘 ----
log "清理没用到的旧镜像…"
docker image prune -f > /dev/null

ok "全部完成"
