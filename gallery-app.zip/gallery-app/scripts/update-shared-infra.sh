#!/bin/bash
# 修改 .env 里的部署配置（数据库/Redis 连接、密钥、对象存储、Turnstile 等），
# 改完根据改动的变量自动决定是重启还是重新构建镜像。
#
# 用法：
#   ./scripts/update-shared-infra.sh              交互菜单
#   ./scripts/update-shared-infra.sh set KEY VAL   非交互直接设置单个变量（脚本化用）
#   ./scripts/update-shared-infra.sh get KEY       打印当前值（敏感变量会打码）
set -euo pipefail

BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${BLUE}▸${NC} $1"; }
ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}!${NC} $1"; }
err()  { echo -e "${RED}✗${NC} $1"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_EDIT="python3 ${SCRIPT_DIR}/lib/env_edit.py"
ENV_FILE=".env"

if [ ! -f "$ENV_FILE" ]; then
  err "当前目录下没有 .env，请先 cd 到项目根目录"
  exit 1
fi
if ! command -v python3 &>/dev/null; then
  err "需要 python3（用来安全读写 .env，避免 sed 遇到密码里的特殊字符把文件写坏），但没找到"
  exit 1
fi

# 这几个变量是 docker-compose.yml 里的 build arg / RUN 阶段用到的 secret，
# 会在镜像构建时就写死进产物（图片域名白名单、前端 JS 里的 Turnstile site key、
# 预渲染页面查库用的连接串）。改了这几个，只 up -d 不够，必须重新 build。
# 具体原因见 Dockerfile 里对应位置的注释。
BUILD_ARG_KEYS=(DATABASE_URL S3_PUBLIC_URL S3_PUBLIC_HOSTNAME NEXT_PUBLIC_TURNSTILE_SITE_KEY)

# 本次运行改过的变量名，用来在最后决定"要不要重新 build"以及"值有没有变化"。
declare -a CHANGED_KEYS=()

env_get() { $ENV_EDIT get "$ENV_FILE" "$1" 2>/dev/null || true; }
env_mask() { $ENV_EDIT mask "$ENV_FILE" "$1"; }

# 设置一个变量；只有值真的变了才记录进 CHANGED_KEYS（避免"回车跳过"也被当成改动）
env_set_if_changed() {
  local key="$1" new_value="$2"
  local cur_value
  cur_value="$(env_get "$key")"
  if [ "$new_value" == "$cur_value" ]; then
    return 1
  fi
  $ENV_EDIT set "$ENV_FILE" "$key" "$new_value"
  CHANGED_KEYS+=("$key")
  ok "${key} 已更新"
  return 0
}

# 提示输入一个变量的新值。敏感变量用静默输入（不回显），非敏感变量正常回显。
# 回车留空 = 不改，保留原值。
prompt_and_set() {
  local key="$1" label="$2" secret="${3:-false}"
  local cur_display new_value
  if [ "$secret" == true ]; then
    cur_display="$(env_mask "$key")"
  else
    cur_display="$(env_get "$key")"
    [ -z "$cur_display" ] && cur_display="(未设置)"
  fi
  echo
  log "${label}  当前：${cur_display}"
  if [ "$secret" == true ]; then
    read -rsp "新值（回车 = 不改）： " new_value
    echo
  else
    read -rp "新值（回车 = 不改）： " new_value
  fi
  [ -z "$new_value" ] && { log "跳过"; return; }
  env_set_if_changed "$key" "$new_value" || true
}

# ---- 数据库 / Redis 迁移向导（原有逻辑，保留连通性测试，只是改成调用 env_edit.py）----
reconfigure_db_redis() {
  local cur_db_url db_user db_pass db_host db_port db_name
  cur_db_url="$(env_get DATABASE_URL)"
  if [ -z "$cur_db_url" ]; then
    err "没能从 .env 读到 DATABASE_URL，检查一下这是不是正确的项目目录"
    return 1
  fi

  db_user=$(echo "$cur_db_url" | sed -E 's#postgresql://([^:]+):.*#\1#')
  db_pass=$(echo "$cur_db_url" | sed -E 's#postgresql://[^:]+:([^@]+)@.*#\1#')
  db_host=$(echo "$cur_db_url" | sed -E 's#.*@([^:/]+):[0-9]+/.*#\1#')
  db_port=$(echo "$cur_db_url" | sed -E 's#.*@[^:/]+:([0-9]+)/.*#\1#')
  db_name=$(echo "$cur_db_url" | sed -E 's#.*/([^/?]+)(\?.*)?$#\1#')

  echo
  log "当前数据库：用户=${db_user}  地址=${db_host}:${db_port}  库名=${db_name}"
  read -rp "共享库新的 WireGuard IP（回车 = 不改，仍是 ${db_host}）: " new_db_host
  read -rsp "数据库密码是否也变了？变了就输入新密码，没变直接回车: " new_db_pass
  echo

  local final_db_host="${new_db_host:-$db_host}"
  local final_db_pass="${new_db_pass:-$db_pass}"
  local new_database_url="postgresql://${db_user}:${final_db_pass}@${final_db_host}:${db_port}/${db_name}"

  if [ "$new_database_url" != "$cur_db_url" ]; then
    # 连通性测试要用得到 final_db_host/final_db_pass，测试通过之后再真正写 .env——
    # 跟原来的行为顺序不一样（原来是先写再测），这样万一连不上，.env 还是干净的旧值，
    # 不会出现"连不上但 .env 已经改了"的中间状态
    if command -v psql &>/dev/null; then
      echo
      log "测试新的数据库连接…"
      if ! PGPASSWORD="$final_db_pass" psql "postgresql://${db_user}@${final_db_host}:${db_port}/${db_name}" -c '\q' 2>/dev/null; then
        err "连不上新地址，.env 未修改。检查一下：WireGuard mesh 是否已连通、IP/密码是否正确、"
        echo "  共享库那台机器是否已经用 pg-redis-shared.sh 起好了服务"
        return 1
      fi
      ok "数据库连接成功"
    else
      warn "没检测到 psql，跳过连通性测试"
    fi
    $ENV_EDIT set "$ENV_FILE" DATABASE_URL "$new_database_url"
    CHANGED_KEYS+=(DATABASE_URL)
    ok "DATABASE_URL 已更新"
  else
    log "DATABASE_URL 没有变化"
  fi

  echo
  local cur_redis_url redis_host redis_port redis_pass
  cur_redis_url="$(env_get REDIS_URL)"
  if [ -n "$cur_redis_url" ]; then
    redis_pass=$(echo "$cur_redis_url" | sed -E 's#redis://:([^@]*)@.*#\1#')
    redis_host=$(echo "$cur_redis_url" | sed -E 's#.*@([^:/]+):[0-9]+$#\1#')
    redis_port=$(echo "$cur_redis_url" | sed -E 's#.*:([0-9]+)$#\1#')

    log "当前 Redis：地址=${redis_host}:${redis_port}"
    read -rp "Redis 新的 WireGuard IP（回车 = 不改，仍是 ${redis_host}；通常跟数据库同一台，可直接填 ${final_db_host}）: " new_redis_host
    read -rsp "Redis 密码是否也变了？变了就输入新密码，没变直接回车: " new_redis_pass
    echo

    local final_redis_host="${new_redis_host:-$redis_host}"
    local final_redis_pass="${new_redis_pass:-$redis_pass}"
    local new_redis_url="redis://:${final_redis_pass}@${final_redis_host}:${redis_port}"

    if [ "$new_redis_url" != "$cur_redis_url" ]; then
      $ENV_EDIT set "$ENV_FILE" REDIS_URL "$new_redis_url"
      CHANGED_KEYS+=(REDIS_URL)
      ok "REDIS_URL 已更新"
    else
      log "REDIS_URL 没有变化"
    fi
  else
    warn "当前没有启用 REDIS_URL（单节点部署，或还没配 Redis）。要现在配置的话，去主菜单选「其他/自定义变量」手动填"
  fi
}

reconfigure_secrets() {
  echo
  log "会话密钥建议用随机值，不要手打——直接回车会跳过，想生成新密钥的话输入 gen 会自动生成"
  local key label new
  for key in AUTH_SECRET USER_AUTH_SECRET PROXY_TRUST_SECRET; do
    case "$key" in
      AUTH_SECRET) label="后台管理员会话密钥" ;;
      USER_AUTH_SECRET) label="前台用户会话密钥" ;;
      PROXY_TRUST_SECRET) label="反代信任密钥" ;;
    esac
    echo
    log "${label}（${key}）  当前：$(env_mask "$key")"
    read -rp "新值（回车 = 不改，输入 gen = 自动生成随机值）： " new
    if [ "$new" == "gen" ]; then
      new="$(openssl rand -base64 32)"
      log "已生成新的随机值"
    fi
    [ -z "$new" ] && { log "跳过"; continue; }
    env_set_if_changed "$key" "$new" || true
  done
  warn "改了 AUTH_SECRET/USER_AUTH_SECRET 之后，所有人（含你自己）现有的登录状态会失效，需要重新登录"
}

reconfigure_turnstile() {
  prompt_and_set NEXT_PUBLIC_TURNSTILE_SITE_KEY "Turnstile site key（公开值，会打进前端 JS）" false
  prompt_and_set TURNSTILE_SECRET_KEY "Turnstile secret key（保密）" true
}

reconfigure_storage() {
  prompt_and_set S3_ENDPOINT "对象存储 endpoint" false
  prompt_and_set S3_ACCESS_KEY_ID "对象存储 Access Key ID" true
  prompt_and_set S3_SECRET_ACCESS_KEY "对象存储 Secret Access Key" true
  prompt_and_set S3_BUCKET "对象存储 bucket 名" false
  prompt_and_set S3_PUBLIC_URL "对象存储公开访问 URL（含协议，如 https://images.xxx.com）" false
  prompt_and_set S3_PUBLIC_HOSTNAME "对象存储公开访问域名（不含协议，如 images.xxx.com）" false
}

reconfigure_misc() {
  prompt_and_set SITE_URL "站点公开访问地址" false
  echo
  log "自定义变量：想改的变量名不在上面几个分类里？直接在这里输入"
  read -rp "变量名（回车跳过）： " custom_key
  [ -z "$custom_key" ] && return
  prompt_and_set "$custom_key" "$custom_key" false
}

# ---- 应用改动：根据 CHANGED_KEYS 决定重启还是重新 build ----
apply_changes() {
  if [ "${#CHANGED_KEYS[@]}" -eq 0 ]; then
    echo
    ok "没有改动，退出"
    return 0
  fi

  echo
  log "本次改动的变量：${CHANGED_KEYS[*]}"

  local need_build=false
  local key build_key
  for key in "${CHANGED_KEYS[@]}"; do
    for build_key in "${BUILD_ARG_KEYS[@]}"; do
      if [ "$key" == "$build_key" ]; then
        need_build=true
      fi
    done
  done

  if [ "$need_build" == true ]; then
    log "改动包含构建期变量（${BUILD_ARG_KEYS[*]}），需要重新构建镜像…"
    docker compose build
  else
    log "改动的都是运行时变量，跳过构建，直接重启容器读取新的 .env…"
  fi

  log "重启服务…"
  docker compose up -d

  echo
  ok "完成，新配置已生效"
  if [[ " ${CHANGED_KEYS[*]} " == *" DATABASE_URL "* || " ${CHANGED_KEYS[*]} " == *" REDIS_URL "* ]]; then
    warn "建议再跑一次 ./scripts/backup.sh 确认备份脚本也能连上新地址"
  fi
  if [[ " ${CHANGED_KEYS[*]} " == *" AUTH_SECRET "* || " ${CHANGED_KEYS[*]} " == *" USER_AUTH_SECRET "* ]]; then
    warn "会话密钥变了，所有登录状态已失效，需要重新登录"
  fi
}

show_menu() {
  echo
  echo "=== 修改部署配置 ==="
  echo "1) 共享数据库 / Redis 连接迁移（换机器/换 IP，带连通性测试）"
  echo "2) 会话密钥（AUTH_SECRET / USER_AUTH_SECRET / PROXY_TRUST_SECRET）"
  echo "3) Cloudflare Turnstile 人机验证"
  echo "4) 对象存储（S3/R2 endpoint、密钥、bucket、公开访问域名）"
  echo "5) 站点地址 / 其他自定义变量"
  echo "0) 完成，应用改动并退出"
  echo
  read -rp "选择: " choice
  case "$choice" in
    1) reconfigure_db_redis ;;
    2) reconfigure_secrets ;;
    3) reconfigure_turnstile ;;
    4) reconfigure_storage ;;
    5) reconfigure_misc ;;
    0) return 1 ;;
    *) warn "无效选项" ;;
  esac
  return 0
}

# ---- 入口：支持直接 CLI 子命令，也支持不带参数进交互菜单 ----
case "${1:-}" in
  get)
    [ -z "${2:-}" ] && { err "用法：$0 get KEY"; exit 1; }
    value="$(env_get "$2")"
    if [ -z "$value" ]; then
      warn "${2} 未设置"
      exit 1
    fi
    echo "$value"
    exit 0
    ;;
  set)
    if [ -z "${2:-}" ] || [ -z "${3:-}" ]; then
      err "用法：$0 set KEY VALUE"
      exit 1
    fi
    env_set_if_changed "$2" "$3" || { log "值没有变化，未修改"; exit 0; }
    apply_changes
    exit 0
    ;;
  "")
    while show_menu; do :; done
    apply_changes
    ;;
  *)
    err "未知参数：$1（支持：不带参数进菜单 / get KEY / set KEY VALUE）"
    exit 1
    ;;
esac
