import { S3Client, PutObjectCommand, DeleteObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { redis } from '@/lib/redis';

// 任意 S3 兼容对象存储都可以接（Cloudflare R2、阿里云 OSS、腾讯云 COS、
// Backblaze B2、MinIO、AWS S3 本身等），只要支持 SigV4 签名 + 预签名 URL，
// 换存储商只需要改 .env 里的 S3_* 变量，不用改这里的代码。
export const s3 = new S3Client({
  region: 'auto',
  endpoint: process.env.S3_ENDPOINT!,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY_ID!,
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY!,
  },
});

const BUCKET = process.env.S3_BUCKET!;

/**
 * 生成一个用于前端直传的预签名 URL，有效期默认 5 分钟。
 *
 * contentLength 可选：传了的话会把 Content-Length 也签进请求里，S3/R2 会要求
 * 实际 PUT 请求的 Content-Length 跟这个值完全一致，不一致直接拒绝。
 * 用途是防止"报小传大"——调用方（app/api/monkey/upload-url/route.ts）会先校验
 * 客户端声明的文件大小不超过上限，再把这个大小签进 URL 里；单纯不传 contentLength
 * 只能挡"声明超过上限"这一种情况，签进去之后连"先报一个很小的值骗过校验、
 * 实际传一个大文件"这种绕过方式也一并挡掉，因为 URL 本身就锁死了大小。
 */
export async function createUploadUrl(
  key: string,
  contentType: string,
  expiresIn = 300,
  contentLength?: number,
) {
  const command = new PutObjectCommand({
    Bucket: BUCKET,
    Key: key,
    ContentType: contentType,
    ...(typeof contentLength === 'number' ? { ContentLength: contentLength } : {}),
  });
  return getSignedUrl(s3, command, { expiresIn });
}

export async function deleteObject(key: string) {
  await s3.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: key }));
  // 对象已经从存储删了，缓存里如果还留着这个 key 的签名 URL，会在 TTL 到期前
  // 一直指向一个不存在的对象（访问变成 404，不算安全问题，但体验上是"图集里
  // 突然裂图"）。删除时顺手清掉缓存，让下次请求老老实实发现"这张已经没了"。
  //
  // 用精确 key 而不是 redis.keys() 模式匹配删除——KEYS 命令会遍历整个 Redis
  // 实例的 keyspace，共享 Redis 实例上跑一次就是一次全局阻塞，量大了容易拖慢
  // 别的业务。createPrivatePhotoUrl 目前全项目只有一处调用且从不传自定义
  // expiresIn，所以精确拼出默认参数对应的那一个 key 就够覆盖实际场景。
  if (redis) {
    try {
      await redis.del(`gallery:signedurl:${key}:${PRIVATE_URL_DEFAULT_EXPIRES_IN}`);
    } catch (err) {
      console.error(`[storage] redis cache invalidation failed for deleted key "${key}":`, err);
    }
  }
}

/** 拼出公开访问 URL（需要在存储桶开启公开访问，或绑定自定义域名 / CDN） */
export function publicUrl(key: string) {
  const base = process.env.S3_PUBLIC_URL!; // 例如 https://images.yourdomain.com
  return `${base.replace(/\/$/, '')}/${key}`;
}

// 缓存提前量：签名 URL 里 X-Amz-Date + X-Amz-Expires 在签的那一刻就写死了过期时间点，
// 缓存的副本必须比这个时间点更早失效，否则会出现"Redis 里存的还没删，但存储端已经拒绝访问"
// 的空窗——所以缓存 TTL 永远比 expiresIn 少留出这个 buffer，宁可提前重签也不晚退。
const PRIVATE_URL_CACHE_BUFFER_SEC = 120;
const PRIVATE_URL_DEFAULT_EXPIRES_IN = 1800;

/**
 * 私密相册专用：生成一个带签名、限时有效的原图访问 URL，默认 30 分钟。
 *
 * 跟 publicUrl() 的区别：publicUrl() 拼出的是长期有效的公开地址，只要 URL 泄露
 * 出去（分享链接、浏览器历史、代理日志……）任何人都能一直访问，跟"私密"这个
 * 定位是矛盾的——哪怕页面本身做了登录态校验，图片地址一旦被拿到就绕过了那层校验。
 * 这个函数走 S3 GetObject 预签名，URL 里带时效和签名校验，过期后存储端会直接拒绝，
 * 不依赖也不信任应用层是否还记得要不要给这张图鉴权。
 *
 * 30 分钟是权衡后的默认值：足够看完一个相册（包括中途切换 tab 回来），
 * 又不会长到跟公开链接没区别。真要更短/更长可以传 expiresIn 覆盖。
 *
 * 加了一层 Redis 缓存：相册照片多的时候，每次打开相册都要对每张照片重新签一次名，
 * 签名开销跟着照片数线性增长；同一张照片在有效期内被多个用户/多次请求命中的情况
 * 也很常见（分享链接转发给好几个人、同一个人来回切页面）。缓存住之后同一个 key
 * 在 buffer 时间内只签一次，之后都是直接读缓存。
 */
export async function createPrivatePhotoUrl(key: string, expiresIn = PRIVATE_URL_DEFAULT_EXPIRES_IN) {
  // 签名本身不依赖"是谁在请求"——同一个 key + 同样的有效期，签出来的 URL 对任何
  // 已经通过上层权限校验的访问者都一样有效，所以可以跨用户共用同一份缓存。
  // 权限判断永远发生在调用方（route 里查 allowedUsers / shareLink）拿到 key 之前，
  // 这里缓存的只是"已经确认能看"之后的签名结果，不会绕过任何授权检查。
  const cacheKey = `gallery:signedurl:${key}:${expiresIn}`;

  if (redis) {
    try {
      const cached = await redis.get(cacheKey);
      if (cached) return cached;
    } catch (err) {
      // Redis 读失败就当没缓存，走下面正常签名，不影响功能
      console.error(`[storage] redis get failed for signed url cache "${key}":`, err);
    }
  }

  const command = new GetObjectCommand({ Bucket: BUCKET, Key: key });
  const url = await getSignedUrl(s3, command, { expiresIn });

  if (redis) {
    // buffer 比 expiresIn 还大的极端情况（有人传了个很小的 expiresIn）兜个底，
    // 至少缓存 30 秒，不然 buffer 一减可能变成负数或 0，Redis EX 会报错
    const cacheTtl = Math.max(expiresIn - PRIVATE_URL_CACHE_BUFFER_SEC, 30);
    try {
      await redis.set(cacheKey, url, 'EX', cacheTtl);
    } catch (err) {
      // 缓存写失败不影响本次响应，下次请求会重新走签名+重试缓存
      console.error(`[storage] redis set failed for signed url cache "${key}":`, err);
    }
  }

  return url;
}
