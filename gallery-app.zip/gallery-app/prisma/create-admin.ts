// 用法（本地开发）: npx tsx prisma/create-admin.ts admin@example.com yourpassword
// 生产环境（Docker）里跑的其实是构建时编译出来的 prisma/create-admin.cjs，
// 见 Dockerfile 里 esbuild 那一步，运行时容器不装 tsx，改这个文件不用管编译产物，
// 重新 build 镜像时会自动重新编译。
//
// 这个脚本只用来创建/重置"最高权限"的超级管理员（SUPER_ADMIN），一般就是
// 首次部署时跑一次。日常要新增权限受限的子管理员，登录后台后去
// /monkey/admins 页面创建，不要用这个脚本——这个脚本没有权限勾选的概念，
// 建出来的账号永远是拥有全部权限的超级管理员。
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { validatePasswordStrength } from '../lib/password';

const prisma = new PrismaClient();

async function main() {
  const [email, password] = process.argv.slice(2);
  if (!email || !password) {
    console.error('用法: npx tsx prisma/create-admin.ts <email> <password>');
    process.exit(1);
  }

  const strength = validatePasswordStrength(password);
  if (!strength.valid) {
    console.error(`密码强度不够：${strength.message}`);
    process.exit(1);
  }

  // 跟 app/api/monkey/login/route.ts 保持一致，做 trim + 小写归一化，
  // 避免创建时的大小写跟登录时不一致导致查不到账号。
  const normalizedEmail = email.trim().toLowerCase();

  const passwordHash = await bcrypt.hash(password, 10);
  const user = await prisma.adminUser.upsert({
    where: { email: normalizedEmail },
    update: { passwordHash, failedAttempts: 0, lockedUntil: null, role: 'SUPER_ADMIN' },
    create: { email: normalizedEmail, passwordHash, role: 'SUPER_ADMIN' },
  });

  console.log('超级管理员账号已创建/更新:', user.email);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
