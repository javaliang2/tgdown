-- 上一个迁移（20260804020000_site_ad_code）加的是"5 个广告位共用一份"的单字段，
-- 这次改成 5 个广告位各自独立。已经保存过的那份代码不丢——迁移到广告位 1，
-- 你之前贴的代码之后还在，只是现在只会出现在第一个广告位，另外 4 个要另外贴。

ALTER TABLE "SiteSetting" ADD COLUMN "adCode1" TEXT NOT NULL DEFAULT '';
ALTER TABLE "SiteSetting" ADD COLUMN "adCode2" TEXT NOT NULL DEFAULT '';
ALTER TABLE "SiteSetting" ADD COLUMN "adCode3" TEXT NOT NULL DEFAULT '';
ALTER TABLE "SiteSetting" ADD COLUMN "adCode4" TEXT NOT NULL DEFAULT '';
ALTER TABLE "SiteSetting" ADD COLUMN "adCode5" TEXT NOT NULL DEFAULT '';

UPDATE "SiteSetting" SET "adCode1" = "adCode";

ALTER TABLE "SiteSetting" DROP COLUMN "adCode";
