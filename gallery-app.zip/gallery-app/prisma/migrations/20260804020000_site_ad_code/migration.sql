-- 侧栏广告位的嵌入代码，后台可编辑，5 个广告位共用同一份。默认空字符串，
-- 空的时候前台走占位块（见 lib/settings.ts 和 app/components/AdSidebar.tsx）。
ALTER TABLE "SiteSetting" ADD COLUMN "adCode" TEXT NOT NULL DEFAULT '';
