'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

type Admin = {
  id: string;
  email: string;
  role: 'SUPER_ADMIN' | 'ADMIN';
  canManageContent: boolean;
  canManageUsers: boolean;
  canManageSettings: boolean;
  createdAt: string;
  lockedUntil: string | null;
};

const PERMISSION_LABELS: { key: 'canManageContent' | 'canManageUsers' | 'canManageSettings'; label: string }[] = [
  { key: 'canManageContent', label: '内容管理（相册/标签/分类/导航）' },
  { key: 'canManageUsers', label: '前台用户管理' },
  { key: 'canManageSettings', label: '网站外观设置' },
];

export default function AdminsPanel({ admins }: { admins: Admin[] }) {
  return (
    <div className="space-y-6">
      <CreateAdminForm />
      <div className="divide-y divide-[var(--fg-10)] border-t border-[var(--fg-10)]">
        {admins.map((admin) => (
          <AdminRow key={admin.id} admin={admin} />
        ))}
      </div>
    </div>
  );
}

function CreateAdminForm() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [perms, setPerms] = useState({ canManageContent: false, canManageUsers: false, canManageSettings: false });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  async function handleCreate() {
    setSaving(true);
    setError('');
    const res = await fetch('/api/monkey/admins', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, ...perms }),
    });
    setSaving(false);
    if (res.ok) {
      setEmail('');
      setPassword('');
      setPerms({ canManageContent: false, canManageUsers: false, canManageSettings: false });
      setOpen(false);
      router.refresh();
    } else {
      const data = await res.json().catch(() => null);
      setError(data?.error || '创建失败，重试一下');
    }
  }

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        style={{ backgroundColor: 'var(--accent-color)' }}
        className="rounded px-3 py-1.5 text-sm text-[var(--accent-contrast)]"
      >
        + 新建子管理员
      </button>
    );
  }

  return (
    <div className="rounded border border-[var(--fg-10)] bg-[var(--fg-5)] p-4">
      <div className="grid gap-3 sm:grid-cols-2">
        <input
          type="email"
          placeholder="邮箱"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="rounded border border-[var(--fg-15)] bg-transparent px-2.5 py-1.5 text-sm outline-none"
        />
        <input
          type="password"
          placeholder="初始密码（至少 10 位，含字母和数字）"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="rounded border border-[var(--fg-15)] bg-transparent px-2.5 py-1.5 text-sm outline-none"
        />
      </div>

      <div className="mt-3 space-y-1.5">
        {PERMISSION_LABELS.map(({ key, label }) => (
          <label key={key} className="flex cursor-pointer items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={perms[key]}
              onChange={(e) => setPerms((p) => ({ ...p, [key]: e.target.checked }))}
              className="h-4 w-4"
            />
            {label}
          </label>
        ))}
      </div>

      {error && <p className="mt-2 text-sm text-red-400">{error}</p>}

      <div className="mt-3 flex gap-2">
        <button
          type="button"
          onClick={handleCreate}
          disabled={saving || !email || !password}
          style={{ backgroundColor: 'var(--accent-color)' }}
          className="rounded px-3 py-1.5 text-sm text-[var(--accent-contrast)] disabled:cursor-default disabled:bg-[var(--fg-10)] disabled:text-[var(--fg-40)]"
        >
          {saving ? '创建中…' : '创建'}
        </button>
        <button
          type="button"
          onClick={() => setOpen(false)}
          className="rounded px-3 py-1.5 text-sm text-[var(--fg-60)] hover:bg-[var(--fg-10)]"
        >
          取消
        </button>
      </div>
    </div>
  );
}

function AdminRow({ admin }: { admin: Admin }) {
  const router = useRouter();
  const [expanded, setExpanded] = useState(false);
  const [perms, setPerms] = useState({
    canManageContent: admin.canManageContent,
    canManageUsers: admin.canManageUsers,
    canManageSettings: admin.canManageSettings,
  });
  const [newPassword, setNewPassword] = useState('');
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState('');

  const dirty =
    perms.canManageContent !== admin.canManageContent ||
    perms.canManageUsers !== admin.canManageUsers ||
    perms.canManageSettings !== admin.canManageSettings ||
    newPassword.length > 0;

  async function handleSave() {
    setSaving(true);
    setError('');
    const body: Record<string, unknown> = { ...perms };
    if (newPassword) body.newPassword = newPassword;

    const res = await fetch(`/api/monkey/admins/${admin.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    setSaving(false);
    if (res.ok) {
      setNewPassword('');
      router.refresh();
    } else {
      const data = await res.json().catch(() => null);
      setError(data?.error || '保存失败，重试一下');
    }
  }

  async function handleDelete() {
    if (!confirm(`确定要删除管理员 ${admin.email} 吗？这个操作不可撤销，对方会立刻登出。`)) {
      return;
    }
    setDeleting(true);
    const res = await fetch(`/api/monkey/admins/${admin.id}`, { method: 'DELETE' });
    setDeleting(false);
    if (res.ok) {
      router.refresh();
    } else {
      alert('删除失败，重试一下');
    }
  }

  const isSuper = admin.role === 'SUPER_ADMIN';
  const grantedCount = [admin.canManageContent, admin.canManageUsers, admin.canManageSettings].filter(Boolean).length;

  return (
    <div className="py-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <p className="text-sm">
            {admin.email}
            {isSuper && (
              <span
                style={{ backgroundColor: 'var(--accent-color)', color: 'var(--accent-contrast)' }}
                className="ml-2 rounded px-1.5 py-0.5 text-xs"
              >
                超级管理员
              </span>
            )}
          </p>
          <p className="text-xs text-[var(--fg-40)]">
            {new Date(admin.createdAt).toLocaleDateString('zh-CN')} 创建
            {!isSuper && ` · 已授权 ${grantedCount}/3 个模块`}
            {admin.lockedUntil && new Date(admin.lockedUntil) > new Date() && (
              <span className="text-red-400"> · 因登录失败次数过多已被锁定</span>
            )}
          </p>
        </div>
        {!isSuper && (
          <div className="flex items-center gap-3 text-sm">
            <button
              type="button"
              onClick={() => setExpanded((v) => !v)}
              className="text-[var(--fg-60)] hover:text-[var(--accent-color)]"
            >
              {expanded ? '收起' : '编辑'}
            </button>
            <button
              type="button"
              onClick={handleDelete}
              disabled={deleting}
              className="text-red-400 hover:text-red-300 disabled:opacity-50"
            >
              {deleting ? '删除中…' : '删除'}
            </button>
          </div>
        )}
      </div>

      {expanded && !isSuper && (
        <div className="mt-3 rounded border border-[var(--fg-10)] bg-[var(--fg-5)] p-3">
          <div className="space-y-1.5">
            {PERMISSION_LABELS.map(({ key, label }) => (
              <label key={key} className="flex cursor-pointer items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={perms[key]}
                  onChange={(e) => setPerms((p) => ({ ...p, [key]: e.target.checked }))}
                  className="h-4 w-4"
                />
                {label}
              </label>
            ))}
          </div>

          <div className="mt-3 border-t border-[var(--fg-10)] pt-3">
            <label className="mb-1 block text-xs text-[var(--fg-50)]">重置密码（留空 = 不改）</label>
            <input
              type="password"
              placeholder="新密码"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full rounded border border-[var(--fg-15)] bg-transparent px-2.5 py-1.5 text-sm outline-none sm:w-64"
            />
          </div>

          {error && <p className="mt-2 text-sm text-red-400">{error}</p>}

          <button
            type="button"
            onClick={handleSave}
            disabled={!dirty || saving}
            style={dirty ? { backgroundColor: 'var(--accent-color)' } : undefined}
            className="mt-3 rounded px-3 py-1.5 text-sm text-[var(--accent-contrast)] disabled:cursor-default disabled:bg-[var(--fg-10)] disabled:text-[var(--fg-40)]"
          >
            {saving ? '保存中…' : dirty ? '保存修改' : '没有改动'}
          </button>
        </div>
      )}
    </div>
  );
}
