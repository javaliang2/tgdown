import Link from 'next/link';
import LogoutButton from './LogoutButton';
import { requireAdminPage, getCurrentAdmin } from '@/lib/auth';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  // 第二道防线：proxy.ts 已经在网络边界拦过一次未登录访问，这里在渲染路径上再查一次
  // session，没有就直接 redirect 到登录页。就算 proxy.ts 那层因为改动/配置疏漏失效，
  // 这里也不会把任何后台数据渲染出去。详见 lib/auth.ts 里 requireAdminPage 的注释。
  await requireAdminPage();

  // 导航栏本身只是"看不看得见入口"这一层——真正的权限拦截在每个页面/接口自己
  // 那一层（页面用 requireSuperAdminPage，接口用 requirePermissionApi /
  // requireSuperAdminApi）。这里就算漏判、放出了一个不该出现的链接，点进去
  // 也会在下一层被拦下，不构成安全边界，只影响体验好不好看。
  const admin = await getCurrentAdmin();
  const isSuper = admin?.role === 'SUPER_ADMIN';
  const canContent = isSuper || admin?.canManageContent;
  const canUsers = isSuper || admin?.canManageUsers;
  const canSettings = isSuper || admin?.canManageSettings;

  return (
    <div>
      <nav className="border-b border-[var(--fg-10)] bg-[var(--fg-5)]">
        <div className="mx-auto flex max-w-4xl flex-wrap items-center gap-x-1 gap-y-2 px-4 py-3 text-sm">
          {canContent && (
            <>
              <Link href="/monkey" className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]">
                图集管理
              </Link>
              <Link
                href="/monkey/categories"
                className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
              >
                分类管理
              </Link>
              <Link
                href="/monkey/tags"
                className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
              >
                标签管理
              </Link>
              <Link
                href="/monkey/menu"
                className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
              >
                导航菜单
              </Link>
            </>
          )}
          {canUsers && (
            <Link
              href="/monkey/users"
              className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
            >
              用户管理
            </Link>
          )}
          {canSettings && (
            <Link
              href="/monkey/settings"
              className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
            >
              外观设置
            </Link>
          )}
          {isSuper && (
            <Link
              href="/monkey/admins"
              className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
            >
              管理员管理
            </Link>
          )}

          <div className="ml-auto flex items-center gap-1">
            <Link
              href="/monkey/account"
              className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
            >
              账号
            </Link>
            <a
              href="/"
              target="_blank"
              rel="noopener noreferrer"
              className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
            >
              查看前台 ↗
            </a>
            <LogoutButton />
          </div>
        </div>
      </nav>
      {children}
    </div>
  );
}
