// 图片压缩 + 上传到 R2 的共享逻辑，新建图集页、编辑图集页都用这一份。
// 只能在浏览器端用（用到了 createImageBitmap / canvas / document），
// 只允许被 'use client' 组件 import。

import exifr from 'exifr';
import { formatExifFromRaw } from '@/lib/exif-format';

// 超过这个体积（字节）才压缩原图，没超过就原样上传，不瞎折腾
export const COMPRESS_THRESHOLD_BYTES = 5 * 1024 * 1024; // 5MB
// 压缩时长边最多缩到这么大（像素），保持宽高比
export const COMPRESS_MAX_DIMENSION = 2560;
// 压缩输出质量（webp，0~1）
export const COMPRESS_QUALITY = 0.85;
// 缩略图必须比"要上传的原图"小到这个比例以下，单独传一份缩略图才划算；
// 达不到就说明原图本来就够小（比如手机截图、已经被压过的图），
// 再传一份"缩略图"其实是净增一次上传 + 一份几乎等大的冗余存储，不如直接复用原图。
export const THUMB_MIN_SAVINGS_RATIO = 0.5; // 缩略图体积 <= 原图 * 0.5 才值得单独传
// LQIP 模糊占位图的长边（像素）：故意压得很小，肉眼看不出细节，
// 只用来在真图加载完成前撑个色块过渡，体积够小才能直接内嵌进页面 HTML 里
const BLUR_PLACEHOLDER_MAX_DIMENSION = 16;
const BLUR_PLACEHOLDER_QUALITY = 0.5;

// 用 canvas 把图片缩放到指定长边、按给定格式/质量重新编码
async function drawToBlob(
  img: ImageBitmap,
  maxSize: number,
  type: string,
  quality: number,
): Promise<{ blob: Blob; width: number; height: number }> {
  const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
  const w = Math.round(img.width * scale);
  const h = Math.round(img.height * scale);
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  ctx.drawImage(img, 0, 0, w, h);
  const blob: Blob = await new Promise((resolve) => canvas.toBlob((b) => resolve(b!), type, quality));
  return { blob, width: w, height: h };
}

// 生成一张几像素大小的模糊占位图，直接编码成 base64 data URI（不用传 R2，体积小到可以内嵌）
async function drawBlurDataURL(img: ImageBitmap): Promise<string> {
  const scale = Math.min(1, BLUR_PLACEHOLDER_MAX_DIMENSION / Math.max(img.width, img.height));
  const w = Math.max(1, Math.round(img.width * scale));
  const h = Math.max(1, Math.round(img.height * scale));
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  ctx.drawImage(img, 0, 0, w, h);
  return canvas.toDataURL('image/jpeg', BLUR_PLACEHOLDER_QUALITY);
}

// 一次性把一张源文件处理成「缩略图」+「要上传的原图」：
// - 缩略图固定压到 600px webp，给首页封面/网格用；
// - "原图"默认就是用户选的文件本身，不动；只有体积超过 COMPRESS_THRESHOLD_BYTES
//   才会走跟缩略图一样的 canvas 缩放+重新编码流程（长边压到 COMPRESS_MAX_DIMENSION）。
//   注意压缩后实际尺寸会变，返回的 width/height 是最终真正上传的那份图的尺寸，
//   不是原始源文件的尺寸——这样详情页用这个尺寸做布局占位才不会跟真实图片对不上。
//
// 缩略图不是无脑生成就传：如果原图本来就小（几百 K 甚至更小、尺寸本来就不大），
// 重新编码出来的"缩略图"体积跟原图差不了多少，这时候单独传一份纯属浪费一次上传 +
// 一份几乎重复的存储。所以这里会比较缩略图体积和最终要上传的原图体积，
// 只有缩略图确实小出一个有意义的比例（见 THUMB_MIN_SAVINGS_RATIO）才返回它，
// 否则 thumbBlob 为 null，调用方应该直接复用原图当缩略图。
export async function processImage(file: File): Promise<{
  thumbBlob: Blob | null;
  blurDataURL: string;
  original: { blob: Blob; width: number; height: number; filename: string; contentType: string };
}> {
  const img = await createImageBitmap(file);
  const thumb = await drawToBlob(img, 600, 'image/webp', 0.85);
  const blurDataURL = await drawBlurDataURL(img);

  const original =
    file.size > COMPRESS_THRESHOLD_BYTES
      ? (async () => {
          const compressed = await drawToBlob(img, COMPRESS_MAX_DIMENSION, 'image/webp', COMPRESS_QUALITY);
          return {
            blob: compressed.blob,
            width: compressed.width,
            height: compressed.height,
            filename: file.name.replace(/\.\w+$/, '.webp'),
            contentType: 'image/webp',
          };
        })()
      : Promise.resolve({
          blob: file as Blob,
          width: img.width,
          height: img.height,
          filename: file.name,
          contentType: file.type,
        });

  const resolvedOriginal = await original;

  // 缩略图体积没比"最终原图"小出有意义的比例，就不值得单独传一份
  const worthSeparateThumb = thumb.blob.size <= resolvedOriginal.blob.size * THUMB_MIN_SAVINGS_RATIO;

  return {
    thumbBlob: worthSeparateThumb ? thumb.blob : null,
    blurDataURL,
    original: resolvedOriginal,
  };
}

export async function uploadToR2(file: Blob, filename: string, contentType: string, kind: 'original' | 'thumb') {
  const res = await fetch('/api/monkey/upload-url', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ filename, contentType, kind, fileSize: file.size }),
  });
  if (!res.ok) {
    const { error } = await res.json().catch(() => ({ error: '获取上传地址失败' }));
    throw new Error(error || '获取上传地址失败');
  }
  const { uploadUrl, key } = await res.json();
  await fetch(uploadUrl, { method: 'PUT', headers: { 'Content-Type': contentType }, body: file });
  return key as string;
}

// 上传一整张图（压缩+原图+缩略图都传好），返回可以直接塞进 photos 数组的对象
export async function uploadPhoto(file: File, altText: string) {
  const { thumbBlob, blurDataURL, original } = await processImage(file);
  // EXIF 必须从用户选的原始 file 上提取，不能从压缩后的 blob 上提取——
  // canvas drawImage + toBlob 这套重新编码流程本身就不保留 EXIF，压缩过的 blob 里已经没有了。
  // 拿不到（截图、没有 EXIF 的图很常见）就是 exifr.parse 返回 undefined/抛错，两种情况都当作"没有"处理，
  // 不能因为解析失败就把整次上传搞挂。
  const exif = await exifr.parse(file, {
    pick: ['Make', 'Model', 'LensModel', 'FocalLength', 'FNumber', 'ExposureTime', 'ISO', 'DateTimeOriginal', 'CreateDate'],
  }).then(formatExifFromRaw).catch(() => ({}));

  // thumbBlob 为 null 说明原图本来就够小，缩略图不值得单独传一份，
  // 直接把原图的 key 当 thumbKey 用（详情页/列表页都从同一份文件读）。
  const [r2Key, thumbKey] = thumbBlob
    ? await Promise.all([
        uploadToR2(original.blob, original.filename, original.contentType, 'original'),
        uploadToR2(thumbBlob, file.name.replace(/\.\w+$/, '.webp'), 'image/webp', 'thumb'),
      ])
    : await uploadToR2(original.blob, original.filename, original.contentType, 'original').then((key) => [key, key]);
  return { r2Key, thumbKey, width: original.width, height: original.height, altText, blurDataURL, ...exif };
}
