import { prisma } from '@/lib/db';
import { publicUrl } from '@/lib/storage';
import { notFound } from 'next/navigation';
import EditAlbumForm from './EditAlbumForm';
import { requirePermissionPage } from '@/lib/auth';

export const dynamic = 'force-dynamic'; // 后台不缓存，实时看最新数据

export default async function EditAlbumPage({ params }: { params: Promise<{ id: string }> }) {
  await requirePermissionPage('content');
  const { id } = await params;

  const album = await prisma.album.findUnique({
    where: { id },
    include: {
      photos: { orderBy: { sortOrder: 'asc' } },
      category: { select: { id: true, parentId: true } },
      tags: { select: { name: true } },
    },
  });
  if (!album) notFound();

  const categories = await prisma.category.findMany({
    orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
    select: { id: true, name: true, parentId: true },
  });

  // 二级分类下拉框需要的两个值：
  // - 分类是顶级分类：parentCategoryId = 分类自己的 id，categoryId 留空（"不选子分类"）
  // - 分类是子分类：parentCategoryId = 它的父级 id，categoryId = 它自己
  const cat = album.category;
  const parentCategoryId = cat ? (cat.parentId ?? cat.id) : '';
  const categoryId = cat && cat.parentId ? cat.id : '';

  const photos = album.photos.map((p) => ({
    id: p.id,
    thumbUrl: publicUrl(p.thumbKey),
    thumbKey: p.thumbKey,
    width: p.width,
    height: p.height,
    takenAt: p.takenAt ? p.takenAt.toISOString() : null,
    cameraMake: p.cameraMake,
    cameraModel: p.cameraModel,
    lensModel: p.lensModel,
    focalLength: p.focalLength,
    aperture: p.aperture,
    shutterSpeed: p.shutterSpeed,
    iso: p.iso,
  }));

  return (
    <EditAlbumForm
      album={{
        id: album.id,
        slug: album.slug,
        title: album.title,
        description: album.description ?? '',
        tags: album.tags.map((t) => t.name),
        status: album.status,
        visibility: album.visibility,
        categoryId,
        parentCategoryId,
        coverKey: album.coverKey ?? '',
        featured: album.featured,
        scheduledPublishAt: album.scheduledPublishAt ? album.scheduledPublishAt.toISOString() : null,
      }}
      categories={categories}
      initialPhotos={photos}
    />
  );
}
