import { prisma } from '@/lib/db';
import { getCategoryTree } from '@/lib/categories';
import NavLinkForm from './NavLinkForm';
import DeleteNavLinkButton from './DeleteNavLinkButton';
import { requirePermissionPage } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export default async function MenuPage() {
  await requirePermissionPage('content');
  const [links, tree] = await Promise.all([
    prisma.navLink.findMany({
      orderBy: { sortOrder: 'asc' },
      include: { category: { select: { name: true } } },
    }),
    getCategoryTree(),
  ]);

  // 拍平成一维列表给表单的下拉框用，子分类前面加个符号表示层级
  const categoryOptions = tree.flatMap((top) => [
    { id: top.id, label: top.name },
    ...top.children.map((child) => ({ id: child.id, label: `　└ ${child.name}` })),
  ]);

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="mb-2 text-xl">导航菜单</h1>
      <p className="mb-6 text-sm text-[var(--fg-50)]">
        显示在页头右侧。可以关联一个分类（自动生成筛选链接，改分类名不用来改这里），
        也可以自己填链接——站内路径（比如 <code className="rounded bg-[var(--fg-10)] px-1">/about</code>）或完整外部网址都行。数字越小排越前面。
      </p>

      <NavLinkForm categoryOptions={categoryOptions} />

      <ul className="mt-8 divide-y divide-[var(--fg-10)]">
        {links.map((link) => (
          <li key={link.id} className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm">
            <div>
              <span className="font-medium">{link.label}</span>
              <span className="ml-2 text-[var(--fg-50)]">
                {link.category ? `分类：${link.category.name}` : link.url}
              </span>
              {link.newTab && <span className="ml-2 text-xs text-[var(--fg-30)]">（新窗口打开）</span>}
            </div>
            <div className="flex items-center gap-3 text-[var(--fg-50)]">
              <span>排序 {link.sortOrder}</span>
              <DeleteNavLinkButton id={link.id} />
            </div>
          </li>
        ))}
      </ul>

      {links.length === 0 && (
        <p className="py-8 text-center text-[var(--fg-50)]">还没有菜单项，先在上面新建一个吧</p>
      )}
    </div>
  );
}
