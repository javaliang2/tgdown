import SettingsForm from './SettingsForm';
import { getSiteSettings } from '@/lib/settings';
import { publicUrl } from '@/lib/storage';
import { requirePermissionPage } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export default async function SettingsPage() {
  await requirePermissionPage('settings');
  const settings = await getSiteSettings();
  const logoUrl = settings.logoKey ? publicUrl(settings.logoKey) : null;

  return (
    <div className="mx-auto max-w-xl px-4 py-8">
      <h1 className="mb-6 text-xl">网站外观设置</h1>
      <SettingsForm initial={settings} initialLogoUrl={logoUrl} />
    </div>
  );
}
