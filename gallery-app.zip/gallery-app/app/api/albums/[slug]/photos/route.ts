import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { publicUrl, createPrivatePhotoUrl } from '@/lib/storage';
import { getCurrentUser } from '@/lib/user-auth';
import { isRateLimited } from '@/lib/rate-limit';
import { getClientIp } from '@/lib/client-ip';

// 显式声明绝不缓存——这个接口的返回结果因人而异（取决于当前登录用户是否被授权），
// 不能有任何一层缓存把某个用户的授权结果套用到另一个用户身上。不依赖 Next.js
// Route Handler 默认是不是动态的，显式写出来更保险，也更清楚地表达"这里不能缓存"的意图。
export const dynamic = 'force-dynamic';

// 这个接口一次调用就能拿到整本相册的照片列表（私密相册是签名 URL），
// 还兼职验证分享链接 token，是批量工具/token 暴力枚举天然的目标——
// 图片字节本身走 R2 域名不经过这里（那层由 CDN 的限流规则挡），但"拿到链接列表"
// 这个动作只在这里能拦。阈值给得比页面浏览通用限流（60/10s）严不少：
// 正常用户打开一个私密相册/点一个分享链接，10 秒内不可能重复调用这么多次。
const PHOTOS_LIST_WINDOW_MS = 10_000;
const PHOTOS_LIST_MAX = 8;

// 私密相册的照片数据故意不放进 /[slug] 页面本身的服务端渲染结果——那个页面是
// export const revalidate = 3600 的 ISR 静态页，同一份 HTML 会被所有访客共用，
// 如果照片 URL 直接写进页面源码/JSON-LD，就算前端"不显示"，任何人查看源码
// 都能看到，等于没锁。所以私密相册的照片单独放在这个接口后面，每次请求都
// 实时查数据库判断"这个登录用户到底有没有被授权"，权限判断永远不会被缓存。
export async function GET(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const ip = getClientIp(req);
  if (ip !== 'unknown' && (await isRateLimited('albums-photos', ip, { windowMs: PHOTOS_LIST_WINDOW_MS, max: PHOTOS_LIST_MAX }))) {
    return NextResponse.json({ error: '请求过于频繁，请稍后再试' }, { status: 429 });
  }

  const { slug } = await params;
  const token = new URL(req.url).searchParams.get('token');

  const album = await prisma.album.findUnique({
    where: { slug, status: 'PUBLISHED' },
    select: {
      id: true,
      title: true,
      visibility: true,
      photos: {
        orderBy: { sortOrder: 'asc' },
        select: {
          id: true,
          r2Key: true,
          width: true,
          height: true,
          altText: true,
          blurDataURL: true,
          takenAt: true,
          cameraMake: true,
          cameraModel: true,
          lensModel: true,
          focalLength: true,
          aperture: true,
          shutterSpeed: true,
          iso: true,
        },
      },
      allowedUsers: { select: { id: true } },
    },
  });

  if (!album) {
    return NextResponse.json({ error: '相册不存在' }, { status: 404 });
  }

  // 公开相册照理说不会走这个接口（前端直接从页面渲染拿），但万一有人直接调用，
  // 也没必要拒绝——反正本来就是公开内容
  if (album.visibility === 'PUBLIC') {
    return NextResponse.json({ photos: album.photos.map(toPhotoDto) });
  }

  // 分享链接和账号授权是两条独立的放行路径，任一成立就行：
  // 账号授权靠"当前登录用户在 allowedUsers 里"，分享链接靠"带着一个有效、没过期、
  // 没被撤销、且确实属于这个相册的 token"。先查 token 这条路径，因为它不需要
  // 查当前登录用户，命中的话能省一次 getCurrentUser() 里的 JWT 校验。
  if (token) {
    const shareLink = await prisma.shareLink.findUnique({ where: { token } });
    const valid =
      shareLink &&
      shareLink.albumId === album.id &&
      !shareLink.revokedAt &&
      (!shareLink.expiresAt || shareLink.expiresAt > new Date());
    if (valid) {
      const photos = await Promise.all(album.photos.map(toPrivatePhotoDto));
      return NextResponse.json({ photos });
    }
    // token 存在但无效（过期/撤销/不属于这个相册）不直接拒绝——继续往下走账号授权这条路径，
    // 万一这个人凑巧自己也有账号授权呢。只有两条路径都不通才真的拒绝。
  }

  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: '需要登录', code: 'UNAUTHENTICATED' }, { status: 401 });
  }

  const authorized = album.allowedUsers.some((u) => u.id === user.id);
  if (!authorized) {
    return NextResponse.json({ error: '没有访问权限', code: 'FORBIDDEN' }, { status: 403 });
  }

  // 私密相册通过验证后也不能直接给 publicUrl()——那是长期有效的公开地址，
  // URL 一旦被截图、转发、缓存在代理/浏览器历史里，就等于绕过了上面的权限校验。
  // 改成每张图单独签一个 30 分钟有效的临时地址，过期后存储端直接拒绝访问，
  // 权限时效跟着签名走，不依赖前端"记得"要不要展示。
  const photos = await Promise.all(album.photos.map(toPrivatePhotoDto));
  return NextResponse.json({ photos });
}

type PhotoWithExif = {
  id: string;
  r2Key: string;
  width: number;
  height: number;
  altText: string | null;
  blurDataURL: string | null;
  takenAt: Date | null;
  cameraMake: string | null;
  cameraModel: string | null;
  lensModel: string | null;
  focalLength: string | null;
  aperture: string | null;
  shutterSpeed: string | null;
  iso: number | null;
};

function exifFields(photo: PhotoWithExif) {
  return {
    takenAt: photo.takenAt ? photo.takenAt.toISOString() : undefined,
    cameraMake: photo.cameraMake || undefined,
    cameraModel: photo.cameraModel || undefined,
    lensModel: photo.lensModel || undefined,
    focalLength: photo.focalLength || undefined,
    aperture: photo.aperture || undefined,
    shutterSpeed: photo.shutterSpeed || undefined,
    iso: photo.iso || undefined,
  };
}

function toPhotoDto(photo: PhotoWithExif) {
  return {
    id: photo.id,
    url: publicUrl(photo.r2Key),
    width: photo.width,
    height: photo.height,
    alt: photo.altText || undefined,
    blurDataURL: photo.blurDataURL || undefined,
    ...exifFields(photo),
  };
}

// 私密相册故意不带 EXIF 字段——公开相册的访客本来就等于是主人愿意公开展示的内容，
// 拍摄时间/设备信息随便看没关系；私密相册的访问方式里有一种是免注册的分享链接
// （见 ShareLink），链接可能被转发给不完全信任的人，这种场景下拍摄时间、设备型号
// 这类元数据没必要跟着一起暴露，干脆私密相册整体都不下发这些字段，不用区分
// "这次访问到底是账号授权还是分享链接"这两条路径分别决定给不给。
async function toPrivatePhotoDto(photo: PhotoWithExif) {
  return {
    id: photo.id,
    url: await createPrivatePhotoUrl(photo.r2Key),
    width: photo.width,
    height: photo.height,
    alt: photo.altText || undefined,
    blurDataURL: photo.blurDataURL || undefined,
  };
}
