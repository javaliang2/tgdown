import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { requirePermissionApi } from '@/lib/auth';

// DELETE: 撤销一条分享链接。不是真的删记录——保留"这条链接曾经存在过、什么时候被收回"
// 的痕迹（跟被撤销之前是不是真的有人用过这条链接这类审计信息一起留着），
// 单纯把 revokedAt 打上时间戳，判断有效性时看这个字段就行。
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string; linkId: string }> },
) {
  const auth = await requirePermissionApi('content');
  if ('response' in auth) return auth.response;

  const { id, linkId } = await params;
  const link = await prisma.shareLink.findUnique({ where: { id: linkId } });
  if (!link || link.albumId !== id) {
    return NextResponse.json({ error: '分享链接不存在' }, { status: 404 });
  }

  const updated = await prisma.shareLink.update({ where: { id: linkId }, data: { revokedAt: new Date() } });
  return NextResponse.json(updated);
}
