import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { deleteObject } from '@/lib/storage';
import { revalidatePath } from 'next/cache';
import { broadcastCacheInvalidation } from '@/lib/cache-broadcast';
import { findConflictingTag } from '@/lib/slug';
import { toTitlePinyin } from '@/lib/pinyin';
import { requirePermissionApi } from '@/lib/auth';

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requirePermissionApi('content');
  if ('response' in auth) return auth.response;

  const { id } = await params;
  const album = await prisma.album.findUnique({
    where: { id },
    include: { photos: true },
  });
  if (!album) {
    return NextResponse.json({ error: '图集不存在' }, { status: 404 });
  }

  // 先删数据库记录（级联删除 photos），再清理 R2 上的文件。
  // 反过来做的话，一旦 R2 那一步中途失败，会出现"数据库还在、图片已经没了"的悬空图集，
  // 前台直接裂图；现在这个顺序最坏情况只是 R2 上留几个没清干净的孤儿文件，不影响线上展示。
  await prisma.album.delete({ where: { id } });
  // 删除图集连带的关系行会自动级联删除，但这可能让某些标签变成"没有任何图集在用"的孤儿行，一并清理
  await prisma.tag.deleteMany({ where: { albums: { none: {} } } });

  const results = await Promise.allSettled(
    album.photos.flatMap((p) => [deleteObject(p.r2Key), deleteObject(p.thumbKey)])
  );
  const failedCount = results.filter((r) => r.status === 'rejected').length;
  if (failedCount > 0) {
    console.error(`删除图集 ${album.slug} 时，有 ${failedCount} 个 R2 文件清理失败，需要手动检查`);
  }

  revalidatePath('/');
  revalidatePath(`/${album.slug}`);
  await broadcastCacheInvalidation([{ path: '/' }, { path: `/${album.slug}` }]);

  return NextResponse.json({ ok: true, r2CleanupFailed: failedCount });
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requirePermissionApi('content');
  if ('response' in auth) return auth.response;

  const { id } = await params;
  const body = await req.json();

  // 判断这次改动算不算"发布"动作，要跟改之前的状态比较，所以先查一遍现状。
  // 只查这几个用得上的字段，不用整行 select *
  const existing = await prisma.album.findUnique({
    where: { id },
    select: { status: true, publishedAt: true },
  });
  if (!existing) {
    return NextResponse.json({ error: '图集不存在' }, { status: 404 });
  }

  // 触发"记一下是谁发布的"的两种情况：
  // 1. 这次改动把 status 明确设成了 PUBLISHED（不管之前是草稿转正还是已发布图集
  //    重新编辑保存——后者也算，"最近一次点发布/保存发布状态的人"覆盖掉旧记录是
  //    合理的，账号是谁改的封面角标就该显示谁）
  // 2. 这次改动新设置了 scheduledPublishAt（定时发布）——见 Album.publishedById
  //    字段注释，设置定时这一刻就算发布动作，不等到 cron 脚本真正执行状态转换
  const willPublishNow = body.status === 'PUBLISHED';
  const willSchedule = 'scheduledPublishAt' in body && !!body.scheduledPublishAt;
  const shouldStampPublisher = willPublishNow || willSchedule;

  // publishedAt 只在"第一次从草稿变已发布"时补一个时间戳，已经发布过的图集
  // 重新编辑不应该把 publishedAt 往后推——不然首页"最新"排序会因为随手改了个
  // 错别字就把老图集顶到最前面，这不是用户想要的效果
  const shouldStampPublishedAt = willPublishNow && !existing.publishedAt;

  // 手动切换封面时，客户端只传了 coverKey（也就是某张 Photo 的 thumbKey），
  // coverBlurDataURL 要跟着查出来一起存，不然封面模糊占位图会跟实际封面对不上。
  let coverBlurDataURL: string | null | undefined = undefined;
  if ('coverKey' in body) {
    if (body.coverKey) {
      const coverPhoto = await prisma.photo.findFirst({
        where: { albumId: id, thumbKey: body.coverKey },
        select: { blurDataURL: true },
      });
      coverBlurDataURL = coverPhoto?.blurDataURL ?? null;
    } else {
      coverBlurDataURL = null;
    }
  }

  if (Array.isArray(body.tags)) {
    const tagConflict = await findConflictingTag(body.tags, id);
    if (tagConflict) {
      return NextResponse.json(
        { error: `标签名"${tagConflict}"和站点固定路径或已有图集地址重名，换一个名字` },
        { status: 400 },
      );
    }
  }

  const album = await prisma.album.update({
    where: { id },
    data: {
      title: body.title,
      // 跟 title 一样，body.title 没传时 toTitlePinyin(undefined as any) 不会被调用，
      // titlePinyin 字段整体是 undefined，Prisma 按"不更新这一列"处理，不会被空字符串覆盖掉
      titlePinyin: typeof body.title === 'string' ? toTitlePinyin(body.title) : undefined,
      description: body.description,
      tags: Array.isArray(body.tags)
        ? {
            // set: [] 先清空这个图集原来关联的所有标签，再按提交的名字列表重新连接；
            // connectOrCreate 保证名字不存在时会顺手建一个新 Tag 行，不用先查一遍再决定建不建
            set: [],
            connectOrCreate: Array.from(new Set(body.tags as string[])).map((name) => ({
              where: { name },
              create: { name },
            })),
          }
        : undefined,
      status: body.status,
      publishedAt: shouldStampPublishedAt ? new Date() : undefined,
      publishedById: shouldStampPublisher ? auth.session.userId : undefined,
      visibility: body.visibility === 'PRIVATE' || body.visibility === 'PUBLIC' ? body.visibility : undefined,
      categoryId: 'categoryId' in body ? body.categoryId : undefined,
      coverKey: 'coverKey' in body ? body.coverKey : undefined,
      coverBlurDataURL,
      featured: typeof body.featured === 'boolean' ? body.featured : undefined,
      // scheduledPublishAt 传 null 表示手动清空定时发布（比如想立刻手动发布，或者不想定时了）；
      // 传字符串就设成对应时间；两者都没传（键都不在 body 里）就是 undefined，不动这个字段
      scheduledPublishAt:
        'scheduledPublishAt' in body
          ? body.scheduledPublishAt
            ? new Date(body.scheduledPublishAt)
            : null
          : undefined,
    },
  });

  // 上面 set: [] 可能会让某些标签变成"没有任何图集在用"的孤儿行，清理掉，
  // 不然后台标签管理页面会一直显示一个 0 个图集的空标签
  if (Array.isArray(body.tags)) {
    await prisma.tag.deleteMany({ where: { albums: { none: {} } } });
  }

  revalidatePath('/');
  revalidatePath(`/${album.slug}`);
  await broadcastCacheInvalidation([{ path: '/' }, { path: `/${album.slug}` }]);

  return NextResponse.json(album);
}
