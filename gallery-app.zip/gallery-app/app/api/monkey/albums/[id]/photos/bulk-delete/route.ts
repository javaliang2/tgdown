import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { deleteObject } from '@/lib/storage';
import { revalidatePath } from 'next/cache';
import { broadcastCacheInvalidation } from '@/lib/cache-broadcast';
import { requirePermissionApi } from '@/lib/auth';

// body: { photoIds: string[] }
//
// 跟单张删除（[photoId]/route.ts）的区别只在于"一次处理多个 id"，删除逻辑本身
// 完全一致：先删数据库记录，再清 R2，封面被删中了就换下一张。放单独一个路由
// 而不是让 [photoId]/route.ts 的 DELETE 兼容数组，是因为一个是单资源 DELETE、
// 一个是批量动作，语义上不一样，混在一起 REST 语义会很别扭（这点也是参考
// albums/bulk/route.ts 里的取舍）。
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requirePermissionApi('content');
  if ('response' in auth) return auth.response;

  const { id } = await params;
  const { photoIds } = await req.json().catch(() => ({}));

  if (!Array.isArray(photoIds) || photoIds.length === 0 || typeof photoIds[0] !== 'string') {
    return NextResponse.json({ error: '缺少要删除的图片 id 列表' }, { status: 400 });
  }
  // 跟 albums/bulk 一样给个上限，正常相册详情页一页顶多几十张图，
  // 不会有人一次选几千张
  if (photoIds.length > 200) {
    return NextResponse.json({ error: '一次最多删除 200 张图片' }, { status: 400 });
  }

  const album = await prisma.album.findUnique({ where: { id }, select: { slug: true, coverKey: true } });
  if (!album) {
    return NextResponse.json({ error: '图集不存在' }, { status: 404 });
  }

  // 只查属于这个相册的照片——即使前端传了别的相册的 id 进来（篡改请求体），
  // 这里过滤掉之后也不会删到别的相册的图，photos 数组里只会剩下真正合法的部分
  const photos = await prisma.photo.findMany({ where: { id: { in: photoIds }, albumId: id } });
  if (photos.length === 0) {
    return NextResponse.json({ error: '没有找到对应的图片' }, { status: 404 });
  }

  await prisma.photo.deleteMany({ where: { id: { in: photos.map((p) => p.id) } } });

  const results = await Promise.allSettled(photos.flatMap((p) => [deleteObject(p.r2Key), deleteObject(p.thumbKey)]));
  const r2CleanupFailed = results.filter((r) => r.status === 'rejected').length;
  if (r2CleanupFailed > 0) {
    console.error(`批量删除图集 ${album.slug} 的图片时，有 ${r2CleanupFailed} 个 R2 文件清理失败，需要手动检查`);
  }

  // 封面在这批被删的照片里 → 换成剩下第一张；一张都不剩就置空。
  // 跟单张删除的逻辑保持一致
  if (photos.some((p) => p.thumbKey === album.coverKey)) {
    const next = await prisma.photo.findFirst({
      where: { albumId: id },
      orderBy: { sortOrder: 'asc' },
      select: { thumbKey: true, blurDataURL: true },
    });
    await prisma.album.update({
      where: { id },
      data: { coverKey: next?.thumbKey ?? null, coverBlurDataURL: next?.blurDataURL ?? null },
    });
  }

  revalidatePath('/');
  revalidatePath(`/${album.slug}`);
  await broadcastCacheInvalidation([{ path: '/' }, { path: `/${album.slug}` }]);

  return NextResponse.json({ ok: true, deleted: photos.length, r2CleanupFailed });
}
