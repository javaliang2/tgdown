import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/db';
import { requireSuperAdminApi } from '@/lib/auth';
import { validatePasswordStrength } from '@/lib/password';

export async function GET() {
  const auth = await requireSuperAdminApi();
  if ('response' in auth) return auth.response;

  const admins = await prisma.adminUser.findMany({
    orderBy: { createdAt: 'asc' },
    select: {
      id: true,
      email: true,
      role: true,
      canManageContent: true,
      canManageUsers: true,
      canManageSettings: true,
      createdAt: true,
      lockedUntil: true,
    },
  });

  return NextResponse.json(admins);
}

export async function POST(req: NextRequest) {
  const auth = await requireSuperAdminApi();
  if ('response' in auth) return auth.response;

  const body = await req.json().catch(() => null);
  const email = typeof body?.email === 'string' ? body.email.trim().toLowerCase() : '';
  const password = typeof body?.password === 'string' ? body.password : '';
  const canManageContent = body?.canManageContent === true;
  const canManageUsers = body?.canManageUsers === true;
  const canManageSettings = body?.canManageSettings === true;

  if (!email || !email.includes('@')) {
    return NextResponse.json({ error: '邮箱格式不对' }, { status: 400 });
  }

  const strength = validatePasswordStrength(password);
  if (!strength.valid) {
    return NextResponse.json({ error: strength.message }, { status: 400 });
  }

  const existing = await prisma.adminUser.findUnique({ where: { email } });
  if (existing) {
    return NextResponse.json({ error: '这个邮箱已经是管理员了' }, { status: 409 });
  }

  // 新建的子管理员一个模块权限都没勾也允许创建成功（虽然这样的账号登录进去
  // 后台基本什么都干不了），不在这里强制"至少勾一个"——超级管理员可能就是
  // 想先建好账号，权限稍后再补，不应该被这种业务规则卡住
  const passwordHash = await bcrypt.hash(password, 10);
  const admin = await prisma.adminUser.create({
    data: {
      email,
      passwordHash,
      role: 'ADMIN',
      canManageContent,
      canManageUsers,
      canManageSettings,
    },
    select: {
      id: true,
      email: true,
      role: true,
      canManageContent: true,
      canManageUsers: true,
      canManageSettings: true,
      createdAt: true,
    },
  });

  return NextResponse.json(admin, { status: 201 });
}
