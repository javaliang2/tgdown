import { prisma } from '@/lib/db';
import Link from 'next/link';
import type { Metadata } from 'next';
import Pagination from './components/Pagination';
import AlbumCard from './components/AlbumCard';
import AdSidebar from './components/AdSidebar';
import { getPageParams, getTotalPages } from '@/lib/pagination';
import { getCategoryTree, findCategoryContext, categoryIdsForFilter } from '@/lib/categories';
import { getTagCounts } from '@/lib/tags';
import { tagBadgeStyle } from '@/lib/tag-color';
import { seededShuffle, currentHourSeed } from '@/lib/seeded-shuffle';
import { publisherBadgeLabel } from '@/lib/publisher-badge';

// 首页标签云只挑热度最高的一批，全部标签太多会把页头下面这块区域撑得很长，
// 想看完整列表引导去 /tags（那边是按热度做字号的完整标签云）
const HOME_TAG_LIMIT = 24;

export const revalidate = 3600; // 每小时重新生成一次

const ALBUM_CARD_SELECT = {
  id: true,
  title: true,
  slug: true,
  coverKey: true,
  coverBlurDataURL: true,
  visibility: true,
  tags: { select: { name: true } },
  publishedBy: { select: { role: true, email: true } },
} as const;

type SortOption = 'new' | 'views' | 'random';
const SORT_LABELS: Record<SortOption, string> = { new: '最新', views: '最热', random: '随机' };

type SearchParams = Promise<{ [key: string]: string | string[] | undefined }>;

export async function generateMetadata({ searchParams }: { searchParams: SearchParams }): Promise<Metadata> {
  const params = await searchParams;
  const { page } = getPageParams(params);

  // 第 2 页及以后内容跟第 1 页高度重复（只是翻页），搜索引擎索引这些页面价值很低，
  // 加 noindex 避免"薄内容"拖累整站质量分；follow 保留，链接权重照样往后传递
  if (page > 1) {
    return { robots: { index: false, follow: true } };
  }
  return {};
}

export default async function HomePage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const params = await searchParams;
  const categorySlug = typeof params.category === 'string' ? params.category : undefined;
  const sort: SortOption = params.sort === 'views' || params.sort === 'random' ? params.sort : 'new';
  const { page, skip, take } = getPageParams(params);

  const tree = await getCategoryTree();
  const context = categorySlug ? findCategoryContext(tree, categorySlug) : null;

  const where = {
    status: 'PUBLISHED' as const,
    ...(context ? { categoryId: { in: categoryIdsForFilter(context.current) } } : {}),
  };

  let albumCards: {
    id: string;
    title: string;
    slug: string;
    coverKey: string | null;
    coverBlurDataURL: string | null;
    visibility: 'PUBLIC' | 'PRIVATE';
    tags: string[];
    publisherLabel: string | null;
  }[];
  let totalCount: number;

  if (sort === 'random') {
    // 先只查 id 排序用，等洗牌切出这一页要展示的那一小撮之后，再单独查这几条的完整字段——
    // 不然要么把全部符合条件的图集完整数据都查出来（数据量大了浪费），要么没法在数据库层面
    // 实现"这一批 id 的乱序"（Prisma 的 `in` 查询不保证返回顺序跟传入数组顺序一致）
    const allIds = await prisma.album.findMany({ where, select: { id: true }, orderBy: { publishedAt: 'desc' } });
    totalCount = allIds.length;
    const hourSeed = currentHourSeed();
    const shuffledIds = seededShuffle(allIds.map((a) => a.id), hourSeed);
    const pageIds = shuffledIds.slice(skip, skip + take);

    const rows = await prisma.album.findMany({ where: { id: { in: pageIds } }, select: ALBUM_CARD_SELECT });
    const byId = new Map(rows.map((r) => [r.id, r]));
    albumCards = pageIds
      .map((id) => byId.get(id))
      .filter((r): r is NonNullable<typeof r> => !!r)
      .map((a) => ({ ...a, tags: a.tags.map((t) => t.name), publisherLabel: publisherBadgeLabel(a.publishedBy) }));
  } else {
    const orderBy = sort === 'views' ? ({ viewCount: 'desc' } as const) : ({ publishedAt: 'desc' } as const);
    const [rows, count] = await Promise.all([
      prisma.album.findMany({ where, orderBy, skip, take, select: ALBUM_CARD_SELECT }),
      prisma.album.count({ where }),
    ]);
    albumCards = rows.map((a) => ({ ...a, tags: a.tags.map((t) => t.name), publisherLabel: publisherBadgeLabel(a.publishedBy) }));
    totalCount = count;
  }

  const tagCounts = await getTagCounts(true);
  const totalPages = getTotalPages(totalCount);
  const topTags = tagCounts.slice(0, HOME_TAG_LIMIT);

  // 排序切换链接要保留当前的分类筛选，但要把页码重置回第 1 页——
  // 换一种排序之后"第 3 页"这个位置对应的内容完全变了，停在原来的页码上没有意义
  function sortLink(target: SortOption) {
    const qs = new URLSearchParams();
    if (categorySlug) qs.set('category', categorySlug);
    if (target !== 'new') qs.set('sort', target);
    const query = qs.toString();
    return query ? `/?${query}` : '/';
  }

  return (
    <div>
      {(context || topTags.length > 0) && (
        <div className="space-y-2 px-4 py-4">
          {/* 分类筛选已经挪到页头导航菜单里去了（导航项可以直接关联分类，见后台"导航菜单"管理）。
              这里不再重复渲染一遍分类列表，只在真的通过分类链接进来时提示一下当前筛选状态，
              把这块地方让给标签——比分类列表更适合放在首页，点了就能直接跳转看图。 */}
          {context && (
            <div className="flex flex-wrap items-center gap-2 text-sm text-[var(--fg-60)]">
              <span>
                当前分类：
                <span className="text-[var(--text-color)]">
                  {context.top.name}
                  {context.current.id !== context.top.id ? ` / ${context.current.name}` : ''}
                </span>
              </span>
              <Link href="/" className="text-xs underline hover:text-[var(--text-color)]">
                清除筛选
              </Link>
            </div>
          )}

          {topTags.length > 0 && (
            <div className="flex flex-wrap gap-2 text-xs">
              {topTags.map(({ tag }) => (
                <Link
                  key={tag}
                  href={`/${encodeURIComponent(tag)}`}
                  style={tagBadgeStyle(tag)}
                  className="rounded-full px-3 py-1.5 transition hover:opacity-80"
                >
                  {tag}
                </Link>
              ))}
              <Link
                href="/tags"
                className="flex items-center rounded-full px-3 py-1.5 text-[var(--fg-50)] hover:text-[var(--text-color)]"
              >
                全部标签 →
              </Link>
            </div>
          )}
        </div>
      )}

      <div className="flex justify-end gap-1 px-4 pt-2 text-xs">
        {(Object.keys(SORT_LABELS) as SortOption[]).map((option) => (
          <Link
            key={option}
            href={sortLink(option)}
            aria-current={sort === option}
            className={
              sort === option
                ? 'rounded-full px-3 py-1 text-[var(--accent-contrast)]'
                : 'rounded-full px-3 py-1 text-[var(--fg-50)] hover:text-[var(--text-color)]'
            }
            style={sort === option ? { backgroundColor: 'var(--accent-color)' } : undefined}
          >
            {SORT_LABELS[option]}
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6 px-1 lg:grid-cols-[4fr_1fr] lg:px-4">
        <div>
          <div className="grid grid-cols-2 gap-x-1 gap-y-3 p-1 sm:grid-cols-3 md:grid-cols-4">
            {albumCards.map((album, index) => (
              <AlbumCard key={album.slug} album={album} priority={index === 0} />
            ))}
            {albumCards.length === 0 && (
              <p className="col-span-full p-8 text-center text-[var(--fg-50)]">
                {categorySlug ? '这个分类下暂无图集' : '还没有发布任何图集'}
              </p>
            )}
          </div>

          <Pagination
            currentPage={page}
            totalPages={totalPages}
            basePath="/"
            extraParams={{ category: categorySlug, sort: sort !== 'new' ? sort : undefined }}
          />
        </div>

        <AdSidebar />
      </div>
    </div>
  );
}
