'use client';

import { useEffect, useState } from 'react';

// 跟 layout.tsx <head> 里那段防闪屏脚本共用同一个 key，两边必须保持一致。
const STORAGE_KEY = 'gallery-theme'; // 'dark' | 'light' | 'glass'

type Theme = 'dark' | 'light' | 'glass';

// 循环顺序：夜间 → 日间 → 玻璃 → 夜间……图标顺序对应月亮→太阳→水滴。
// 现在默认主题是玻璃，但循环顺序本身不用跟着默认值变——不管从哪个主题开始点，
// 三档轮流切换的相对顺序保持不变，用户更容易记住"再点一下是什么"。
const NEXT: Record<Theme, Theme> = { dark: 'light', light: 'glass', glass: 'dark' };

function applyTheme(theme: Theme) {
  document.documentElement.classList.toggle('dark-mode', theme === 'dark');
  document.documentElement.classList.toggle('glass-mode', theme === 'glass');
}

export default function ThemeToggle() {
  // 初始值先假设 glass（现在默认是玻璃主题），挂载后立刻用 <html> 上的实际 class 校正一次——
  // 这个 class 是防闪屏脚本在 hydration 之前就加好的，所以这里只是把 React state 对齐上去。
  const [theme, setTheme] = useState<Theme>('glass');

  useEffect(() => {
    const el = document.documentElement;
    if (el.classList.contains('glass-mode')) setTheme('glass');
    else if (el.classList.contains('dark-mode')) setTheme('dark');
    else setTheme('light');
  }, []);

  function toggle() {
    const next = NEXT[theme];
    setTheme(next);
    applyTheme(next);
    try {
      localStorage.setItem(STORAGE_KEY, next);
    } catch {
      // 隐私模式下 localStorage 可能不可用，切换本身仍然生效，只是刷新后记不住，不影响使用
    }
  }

  const label = theme === 'dark' ? '夜间模式' : theme === 'light' ? '日间模式' : '玻璃模式';
  const nextLabel = theme === 'dark' ? '日间模式' : theme === 'light' ? '玻璃模式' : '夜间模式';

  return (
    <button
      type="button"
      onClick={toggle}
      aria-label={`当前${label}，切换到${nextLabel}`}
      title={`${label}（点击切换到${nextLabel}）`}
      className="flex h-11 w-11 items-center justify-center rounded-md transition hover:bg-white/10 hover:text-[var(--accent-color)]"
    >
      {theme === 'dark' ? (
        // 当前是夜间：显示太阳，点一下切到日间
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
          <circle cx="9" cy="9" r="3.2" stroke="currentColor" strokeWidth="1.6" />
          <line x1="9" y1="1.5" x2="9" y2="3.3" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <line x1="9" y1="14.7" x2="9" y2="16.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <line x1="1.5" y1="9" x2="3.3" y2="9" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <line x1="14.7" y1="9" x2="16.5" y2="9" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <line x1="3.7" y1="3.7" x2="5" y2="5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <line x1="13" y1="13" x2="14.3" y2="14.3" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <line x1="3.7" y1="14.3" x2="5" y2="13" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <line x1="13" y1="5" x2="14.3" y2="3.7" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      ) : theme === 'light' ? (
        // 当前是日间：显示水滴（玻璃/水），点一下切到玻璃主题
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
          <path
            d="M9 2.25c2.2 3.1 4.75 6.4 4.75 9.15a4.75 4.75 0 1 1-9.5 0c0-2.75 2.55-6.05 4.75-9.15z"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
          <path d="M6.6 12.4a2.4 2.4 0 0 0 2.1 2.4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
        </svg>
      ) : (
        // 当前是玻璃：显示月亮，点一下切回夜间
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
          <path
            d="M15.75 9.59A6.75 6.75 0 1 1 8.41 2.25 5.25 5.25 0 0 0 15.75 9.59z"
            fill="currentColor"
          />
        </svg>
      )}
    </button>
  );
}
