import Link from 'next/link';
import Image from 'next/image';
import { publicUrl } from '@/lib/storage';
import { tagTextColor } from '@/lib/tag-color';

type AlbumCardData = {
  title: string;
  slug: string;
  coverKey: string | null;
  coverBlurDataURL: string | null;
  tags: string[];
  visibility?: 'PUBLIC' | 'PRIVATE';
  publisherLabel?: string | null;
};

// 标签最多显示 3 个，太多的话卡片高度参差不齐、网格看着会很乱；
// 多出来的用一个 "+N" 提示一下就好，不用挨个列出来
const MAX_VISIBLE_TAGS = 3;

export default function AlbumCard({ album, priority }: { album: AlbumCardData; priority: boolean }) {
  const visibleTags = album.tags.slice(0, MAX_VISIBLE_TAGS);
  const remaining = album.tags.length - visibleTags.length;

  return (
    <div className="group">
      <Link href={`/${album.slug}`} className="block">
        <div className="relative aspect-square overflow-hidden bg-[var(--fg-5)]">
          {album.coverKey && (
            <Image
              src={publicUrl(album.coverKey)}
              alt={album.title}
              fill
              sizes="(max-width: 768px) 50vw, 25vw"
              className="object-cover transition duration-500 group-hover:scale-105"
              priority={priority}
              loading={priority ? undefined : 'lazy'}
              {...(album.coverBlurDataURL
                ? { placeholder: 'blur' as const, blurDataURL: album.coverBlurDataURL }
                : {})}
            />
          )}
          {album.visibility === 'PRIVATE' && (
            // 私密相册的角标：封面照样露出来，只是提前告诉你点进去内容是锁着的，
            // 不用点进详情页才发现需要授权
            <div
              className="absolute right-1.5 top-1.5 flex items-center gap-1 rounded-full bg-black/55 px-2 py-1 text-[10px] text-white backdrop-blur-sm"
              title="需要授权访问"
            >
              <svg width="10" height="10" viewBox="0 0 18 18" fill="none" aria-hidden="true">
                <rect x="4" y="8" width="10" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.6" />
                <path d="M6.5 8V5.5a2.5 2.5 0 0 1 5 0V8" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
              </svg>
              私密
            </div>
          )}
          {album.publisherLabel && (
            // 发布者角标放左上角，跟右上角的"私密"角标错开，两个同时出现也不会挤在一起
            <div className="absolute left-1.5 top-1.5 rounded-full bg-black/55 px-2 py-1 text-[10px] text-white backdrop-blur-sm">
              {album.publisherLabel}
            </div>
          )}
        </div>
        <p className="mt-1.5 truncate px-0.5 text-base text-[var(--fg-80)] group-hover:text-[var(--text-color)]">
          {album.title}
        </p>
      </Link>

      {/* 标签是单独的链接（跳到 /tags/[tag]），不能嵌套在上面 <Link> 的 <a> 里面，
          所以放在外层 div 下面当兄弟节点，视觉上依然紧贴在标题下方 */}
      {visibleTags.length > 0 && (
        <div className="mt-1 flex flex-wrap items-center gap-x-1.5 gap-y-0.5 px-0.5">
          {visibleTags.map((tag) => (
            <Link
              key={tag}
              href={`/${encodeURIComponent(tag)}`}
              style={tagTextColor(tag)}
              className="truncate text-xs transition hover:opacity-75"
            >
              #{tag}
            </Link>
          ))}
          {remaining > 0 && <span className="text-xs text-[var(--fg-30)]">+{remaining}</span>}
        </div>
      )}
    </div>
  );
}
